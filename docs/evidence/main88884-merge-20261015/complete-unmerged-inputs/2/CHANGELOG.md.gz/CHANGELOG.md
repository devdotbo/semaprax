<!-- Source-only #833: invocation-owned identifier census scratch reuse across
     distinct cold callers; full old receiver retained; qualification pending. -->
# Changelog

- Bind fresh application plan/activation reads (#837) to the existing no-follow bounded held regular-file owner, closing inspection/open symlink and FIFO replacement races. Add deterministic pre-open swap controls and small independent typed native-test selector owners. Source-only correction; execution remains pending.

- Author fresh application assembly (#837) from existing replayed codec plans and explicit command profiles through the original held-parent scaffold publisher. Bind canonical source/generation receipts and exact native routes; add an explicit pure typed v31 native-test successor while preserving old profile refusals. Full ShiftSim15/selected-file CLI49 and hostile-publication scenarios are authored; all executable qualification and the source-capacity dependency remain pending.

- Author the ordinary lexical return-operand inventory (#832) on fallible paid AVL backing with borrowed identities, exact caller/facts/budget/ledger binding and certificate-boundary authentication. Preserve complete old callers and original verification charges; new directory work is additional. Rust qualification remains pending.

- Author selected call-local refusal custody (#781): nineteen fixed reasons and the exact unknown-callee handle reach the paid engine through selected block replay; retain complete old receivers and prepaid success/failure controls. Source-only checkpoint; Rust qualification and whole-issue closure remain pending.
- Author allocation-free final canonical-comment comparison for cold workspace
  admission (#835), retaining the complete old String formatter and preflight
  receiver. Placement scratch and reservations remain unchanged; focused
  executable qualification and physical measurements are pending.

- Qualify the closed named String-transfer v1 scope with all 15 exact a417 owning controls and the five 27ae regenerated-pin/source controls; retain unrelated application-budget failures and frozen public profiles.

- Add bounded authoring-card keyword/identity discovery from the existing route and card inventory, preserving library-only search. Executable qualification and live efficiency measurement remain pending.
- Author authenticated numeric cleanup-closure memo chunks and reuse immutable
  single-epsilon child backing (#830), retaining every logical work charge and
  the complete original receivers. Add prepaid static local Session refusals
  (#781), retaining original Owned controls and the actual paid-report boundary.
  The combined focused runtime/Clippy campaign is pending; no application-fit
  or live token/cost improvement is claimed.

- Author narrowly scoped immutable byte-to-byte nesting (#780), with exact
  outer-entry views, a function-bound borrowed HIR census and complete ancestor
  freezes. Keep full v1 receivers, mixed source nesting restrictions and actual
  manual-loop/backend/refusal/Drop controls; execution qualification is pending.

- Reuse the already paid status-source directory between ordinary cleanup
  validation passes, retaining membership work and complete original receivers.
  Bind the retained token to its function, replay payer and active ledger;
  focused work/refusal/Drop qualification and full retry recovery remain pending.

- Author immutable paid nominal payloads and one invocation-owned base-prelude
  bundle through workspace fresh, borrowed and selective resolution (#827,
  #828). Preserve complete declaration maps, wire projections and old receivers;
  add explicit work/refusal custody, rollback, Drop and hostile-mutation controls.
  Focused executable qualification is pending; public/final-linker/cache paths
  and application fit remain open, with unchanged caps and forecast correction.

- Carry the exact borrowed generic-template origin into public signature
  recovery (#799), preserving independent profile diagnostics and complete
  six-field refusal authentication. Add an enclosing canonical-loan preparation
  stage label (#829) without changing reservation layouts or quotas. Both source
  changes await the next combined focused qualification.

- Author a paid 16-entry borrowed lifecycle active path with the unchanged
  paid tree spill. Keep complete prior collectors and authored cycle/effect
  order; add differential, physical refusal/Drop and source-custody controls.
  Runtime qualification and application fit remain pending.

- Avoid constructing an unused validator result scope for functions without
  postconditions, while retaining all result/body checks and sticky funding
  authentication. Complete original and receiving controls await qualification.
- Author paid immutable weighted payload sharing at the ordinary and selected
  lexical factored canonical receivers. Preserve complete original algebra,
  work debits and full source-custody controls; add physical backing, refusal
  and destruction controls. Runtime qualification and application fit remain
  pending; no ceiling changes.
- Author the missing unconditional Option/Result retained-declaration term in
  workspace forecasts (#286), using borrowed producer schema metadata
  and existing checked layout factors. Preserve complete historical receipts,
  complete original receivers, unchanged carrier gates and physical Drop
  controls. Executable qualification and current-source fit remain pending.

- Author additive paid streaming constructor preflight and shared exact-program
  function-directory custody (#824), preserving complete independent originals,
  diagnostic ordering and unchanged whole receiver controls. Qualification is
  pending; other constructor owners and application fit remain unproved.

- Keep small Program teardown frontiers inline without changing original AST
  destruction order or source/custody identities. Preserve the complete original
  destructor/deep owner and add receiving/free-order controls; wider ordinary
  spill remains unpriced and current qualification is pending.

- Author current parsed-source custody and deferred checked cache keys (#796).
  Reuse actual restored source owners for Project linking, validate full key/path
  associations before publication, and retain metadata separately from ASTs.
  Original receivers and cold/warm checks remain; qualification is pending.

- Author a streaming paid ordinary cleanup-inventory summary (#814) at the real
  schema caller. Keep complete original producers/schema/receiving controls and
  compatibility admission; prepay backing and cumulative work from the existing
  budget. Sixty exact source-bound controls await consolidated qualification;
  no application fit or aggregate schema funding is claimed.
- Author paid compatibility canonical-loan preparation and shared custody
  (#824), keeping complete original receivers and the unchanged whole observer.
  Carrier backing uses the same captured owner; qualification is pending.

- Remove the standalone validator's unpriced per-function permit-set collection
  through borrowed exact membership. Keep the complete original receiver and
  error-order controls; author allocation and phase-isolation controls. Runtime
  qualification and attribution to the outstanding eight-byte deficit remain
  pending.

- Author bounded transcript-refusal call, loop and genuine-cycle witnesses
  (#821), preserving primary diagnostics and complete independent model controls.
  Optional help uses the existing payer; the separate model harness forwards
  only a reservation operation through a hidden library facade. Focused runtime
  qualification and diagnostic-pin production remain pending.

- Author funded borrowed inline scratch for ordinary HIR iterator, renewal and
  unsafe preflight scans (#817), retaining full independent original receivers
  and their distinct child/error order. Spill backing and authorization nodes
  are prepaid; fixed semantic errors retain identical static diagnostic bytes.
  Exact physical/refusal/Drop controls are authored, with execution pending.

- Author a paid online expression-fact AVL arena for ordinary cleanup replay and
  selected callers (#813). Retain complete original BTree producers/receivers,
  exact payloads and immediate duplicate order; prepay full overlapping backing
  and caller work without changing caps. Full semantic/allocation/Drop controls
  and source joins are authored; focused execution and application gains remain
  unqualified.

- Restore the original common diagnostic help shortlist by ranking the explicit
  fused-profile F130 advice after ordinary diagnostic advice. Exact profile help
  and the complete inventory stay available; both old exact CLI owners remain
  unchanged. Focused controller regression is authored; execution is pending.

- Fix cleanup capacity telemetry feeding a previous construction aggregate into
  the next invocation. Separate standalone/local/persistent component maxima,
  restore local scopes on refusal, and retain complete staged/attached terms.
  Count omitted held ordinary directories, conditional flow and string-move
  ownership. Preserve the full original model/feedback and receiving-Drop
  controls. Source-only; physical attribution, existing pin regeneration and
  focused qualification remain pending.

- Record the recovery constructor funding design and source-authored executable
  boundaries for real unpaid acquisition/work, zero/exact-observed/one-short
  limits, sticky refusal and complete receiving Drop. Preserve ordinary
  six-field diagnostics and independent original receivers. Payment remains
  unimplemented: its failure needs a separate result through the source verifier.
  No runtime qualification or admission-budget change is claimed.

- Author caller-paid late Agent identity producers in both resolver passes,
  preserving the full carrier and separate semantic/refusal channels. Borrow
  held ARC/scoped lookup keys and same-pass function owner identities. Complete
  frozen receivers, literal compatibility, exact/short/sticky/Drop controls and
  receiving source joins remain connected. Source-only; focused qualification
  and complete dynamic producer migration remain pending.

- Author paid borrowed executable text/collection profiles and an exact immutable
  declaration-index observation directory shared across primary validator clones.
  Preserve complete independent original receivers, substitutions, structural
  limits, diagnostic order and sticky refusal; author cold/warm and real Drop
  controls. Source-only; focused qualification, total funding and application fit
  remain pending.

- Source-authored borrowed-root HIR scopes defer complete binding-map copies until
  actual scope mutation, preserving full map fields, sibling isolation and owned
  publication. The complete frozen nonrecursive receiver and helper/frame bodies
  remain an independent control. Actual empty-root carrier overhead and physical
  allocation/Drop controls are explicit; focused qualification and measured
  resolution-deficit improvement remain pending.

- Author prepaid function collection traversal and lifecycle effect backing,
  borrowing complete type/identity/effect keys and avoiding discarded invariant
  identities. Preserve full independent original receivers, structural bounds,
  diagnostics and sticky refusal controls; add actual allocation-through-Drop
  definitions and complete source joins. Source-only; combined focused runtime
  qualification and application fit remain pending.

- Source-authored HIR final-validation scratch batch removes discarded native
  result trees, small generic frame vectors and nominal key copies, projects
  Array/scalar callable flag misses, and constructs paid classifier Storage only
  on actual miss/fallback. Full original receivers and exact sticky budgets stay
  preserved; combined focused qualification and application fit remain pending.

- Author root-first caller-paid cleanup droppability: classify the borrowed root
  once before outer traversal storage, retaining hostile cache precedence, exact
  semantic errors and complete nominal traversal. Preserve the full prior paid
  receiver verbatim and the independent ordinary callback; add focused root and
  nominal exact/short/zero/sticky/physical Drop controls. Source-only; no runtime
  qualification, broader funding repair or G171/application-fit claim.

- Author borrowed logarithmic field/case lookup on unchanged DeclarationIndex
  tuple BTree keys. Preserve exact DeclarationId/name ordering and returned
  references; retain independent full old lookups and hostile/real-owner
  allocation-through-Drop controls. Source-only; runtime qualification pending.

- Source-authored annotation recovery retains actual type/ownership/loan metadata
  and carries a separate expected-type refusal view. Independent expected types,
  fixed-result checks and ownership boundaries remain selected. Focused
  qualification is pending; no Cargo or full gate ran in the implementation lane.

- Author additive bounded-nested-response.v2 for primitive String vectors using
  existing named borrowed slot views, complete preflight and the original writer.
  Preserve the independently callable v1 receiver and refusal controls, ordinary
  caps and request policy. Add complete request/response, exact-wire, replay and
  actual allocation/Drop definitions; executable qualification remains pending.

- Author allocation-free ordinary substitution for structurally nonrecursive
  roots, preserving generic owner/name priority, exact diagnostics and cloned
  compound results. Avoid nonnominal nested-record classifier root carriers
  while keeping original profile refusals. Preserve full frozen substituters
  and current/original classifier controls; add real caller boundary/Drop
  gates. Source-only; no whole-resolver funding or G171 claim.

- Extend the paid outer droppability source corpus with isolated zero-budget
  helper-allocation controls over real parsed declaration IDs, owned-record and
  owned-leaf Vec signatures, concrete generic records and refused variants.
  Independently inspect declaration clone sharing and owned Diagnostic receiving;
  pair each full receiver with exact/short/zero/sticky and actual Drop controls.
  Source audit found only borrowed metadata and inline helper state on these
  routes; executable allocation qualification remains pending.

- Author caller-paid outer cleanup droppability construction on the existing
  replay type-fact payer: borrowed root and complete owned pending/visited
  payloads, substitution, original raw/capped diagnostic keys, semantic text
  and final replay diagnostics. Preserve independent full old receivers and
  exact cache/diagnostic precedence; add success/hostile, logical-floor,
  exact/short/zero/sticky and receiving/unwind/Drop controls. Absent visited keys
  acquire conservative BTree node bounds, separate from actual allocations.
  Source-only; executable qualification and broader funding claims remain pending.

- Author a constructor-local paid ordered HIR identity directory. Stage shared
  or weak AVL suffixes before changing unique prefixes, retaining duplicate
  priority, canonical merge order and complete original BTree receivers. Add
  full rotation, snapshot, ordered cursor, every-byte refusal and physical Drop
  controls. Source-only; qualification and allocation effects remain pending.
- Author scoped refused-binding diagnostic recovery (OPT806/#799): retain lexical declaration frontiers, original ownership and independent closure/match-coverage errors, complete saved receiving bodies and the 60-case old/current corpus. Annotation neutralization is limited to cleanup-inert real values; ordinary recovery directory storage remains unpaid. Execution and qualification are pending under [Scoped diagnostic recovery v1](docs/SCOPED-DIAGNOSTIC-RECOVERY-V1.md).

- Author constructor-local HIR closure funding for capture and nested-body identity
  insertions, canonical identity/result backing, parameter names/types, and the
  recursively admitted body payload. Construct the body root directly, retaining
  the complete original public product and receiver as independent references.
  Preserve shape checks and canonical plan work/order; those constructors and a
  complete legacy fallback remain explicit unpaid residuals. Add full-state,
  diagnostic, exact/short/sticky, actual payload Drop and unwind controls.
  Source-only; no measured allocation improvement or application-fit claim.

- Add exact `help language detail:<slug>` retrieval for six complete profile
  appendix sections, preserving their original paragraph bytes and all 17
  existing topic routes. Topic cards name one actionable detail lookup; unknown,
  stale or oversized details fail without truncation. Author exact source and CLI
  projection controls; executable qualification remains pending.

- Keep all 17 exact language help topics within their existing bounds by moving
  complete detailed profile rules verbatim to the full-reference appendix.
  Preserve every canonical example, diagnostic marker, full-card rule and route;
  concise topic guidance links to the full constraints. Static source review
  only; compiler and CLI qualification remains pending.

- Author caller-paid declaration fact-cache misses on actual cleanup replay
  routes, removing discarded admission trees and child-fact directories while
  funding retained classifier keys, layouts, ordered maps and scratch backing.
  Preserve complete original classifiers, cache precedence, work/error order,
  and logical reserved-floor/partial-output behavior. Add full old/current and
  actual allocation/debit/receiving-Drop/refusal controls. Source-only; outer
  droppability scratch, semantic diagnostic text and synthetic providers remain
  explicit residuals, and execution/whole-replay funding evidence stays open.

- Author persistent HIR contract baselines that inspect every current freshness
  flag, share unchanged roots and bindings, and pay complete true-flag payloads
  plus changed node constructors before returning a staged root. Retain the full
  original copy receiver and complete function/control corpora, with new rich
  sharing, every-byte refusal, clause isolation, Drop and unwind owners.
  Source-only; executable allocation/work/application-fit evidence remains open.

- Author source-verifier constructor removal: lend the existing immutable type
  table across generic passes, borrow requires entry state, and scan declared
  fields in reverse to preserve last duplicate winners without secondary indexes.
  Keep namespace/inheritance storage and cycle function-map construction; retain
  complete old program/function/table receivers, the full original source corpus,
  public/private diagnostic JSON and allocation/Drop owners. Source-only; observed
  allocation, ledger and application-fit evidence remains pending.

- Author direct ordinary cleanup-inventory replay with paid borrowed ordinal
  indexing, deferred full-frontier comparisons, one reused actual 1028-frame
  cursor, and paid direct shape/type reconstruction. Preserve complete original
  owned receivers, duplicate selection, work/depth limits and error ordering;
  add original-corpus and real allocation/debit/Drop/refusal controls. Source-only;
  classifier fact-cache misses and synthetic parameter backing remain unpaid
  residuals, and qualification and whole-replay funding remain open.

- Author constructor-local HIR identity B-tree payment and focused owner
  corrections: retain the complete allocation/debit bound, catch and drop real
  owned unwind payloads without harness hook capture, compare rich hostile
  contract diagnostics with the complete old oracle before an admitted transfer
  case, and preserve both span-drift rejection and equal-width generic reuse.
  Full fixtures, saved pass bodies and 64 MiB budgets remain; execution pending.

- Author transactional paid HIR scope insertion: stage a shared suffix with exact
  owning node carrier/initializer payments, then commit the unique prefix without
  fallible work or allocation. Preserve the complete coarse receiving policy and
  all original corpora; add full-field rotation, replacement, snapshot, weak,
  every-paid-boundary and Drop comparisons. Source-only; physical request counts
  may remain the same, and consolidated qualification/application fit remain open.

- Author direct paid persistent HIR function scopes across parameters, requires,
  body, result and ensures through a sealed owner of the mutable scope borrow.
  Preserve complete saved map function/expression/
  contract drivers, original publication restoration and conservative insertion
  payments. Add full-chain diagnostics, hostile payload, allocation/debit/Drop,
  exact/short/sticky and unwind owners; correct only the contradictory freshness
  expectation in the unchanged rich refusal fixture. Repair inadmitted I64
  literal suffixes in the generic reuse fixture with the same default-I64 values.
  Source-only; consolidated qualification and OPT795 remain open.

- Acquire real caller-paid import declaration directories at construction and transfer their exact backing once at semantic cache publication, retaining standalone key receivers and full raw-graph controls. Preserve type-before-function failure order and generated view lengths; AST-only passes avoid discarded keys. Ordinary/warm spare storage is an explicit tradeoff. Add source-only zero/exact/short/sticky, detached/pointer, complete projection and constructor-through-Drop controls; qualification and whole application funding remain pending.

- Complete private paid loan-plan seed/live propagation, traversal allowed identities and nominal predicate cycle directories. Retain default public BTree drafts and complete old call/predicate/materialization receivers; preserve full canonical plans, first diagnostics and checked-work equations. Prepay two-reference zero-heap ordered cursors and use sticky allocation-free AVL removal, with explicit O(n log n) borrowed traversal tradeoff. Author literal allocation/debit/Drop, exact/short/denied-mutation and full late-error controls through 4096 entries. Source-only, qualification and full application-fit evidence pending.

- Extend the private caller-paid loan planner directories through candidate ownership/alias discovery, native parent bindings, nonconsuming/terminal roots and borrowed cycle sets. Preserve complete pre-change funded BTree receivers and public fallback, full plan/work/error order, and author whole allocation/debit/Drop plus exact/short/sticky controls. Shared draft seed/live propagation and semantic diagnostic funding remain explicit residuals; source-only, consolidated qualification pending.
- Author an additive affine workspace report failure and typed source-only preflight, retaining each selected replay invocation's initial refusal or original paid slot/text, failed ledger and receipt through both schema receiving passes. Preserve complete legacy preflight and filesystem receivers, exact diagnostics and authority order. Full dynamic directory/TLS attribution and filesystem typed error propagation remain explicit OPT781 residuals; source-only, qualification pending.

- Author Rust embedding facade major 3 for the source-incompatible `Diagnostic.message: Cow<'static, str>` migration. Preserve public dynamic constructor ownership and prepaid pointer/capacity, full diagnostic JSON/Display bytes and historical major-2 negotiation controls; current facade negotiation reports major 3. Fixed validation refusal literals need no message allocation at zero allowance. Original oracles and new whole receiving/clone/Drop controls remain; source-only, qualification and remaining report/output funding are pending.

- Author paid persistent ordered generic-template environments, sharing immutable current-HIR types and untouched checkpoint roots. Unique insertion paths prepay their leaf before mutation; shared path/rotation nodes publish only after complete payment and construction. Retain complete original borrowed-map and owned-map receiver policies and exact caller frontiers. Source-only OPT795 followup; allocation/debit tradeoffs, full application funding and executable qualification remain unassessed.

- Compare replay call-commit ordinals through borrowed signature/transfer receivers, removing two discarded scratch vectors while retaining the complete fallible classification pass and diagnostic priority. Preserve the full vector oracle and author hostile ordinal, later-type-error, actual allocation/Drop and unchanged-debit exact/one-short controls. All parameter fallbacks remain; source-only, consolidated qualification pending.

- Consume newly owned replay observation prefixes when freezing a local extension, removing only the second head-tail clone buffer and its reservation. Preserve borrowed suffix copies, original moved-storage funding, work/node/ordinal/destruction order and complete saved extension oracles. Author full result/error and actual allocation/debit/Drop plus exact/one-short controls; original parameter, union/merge and application controls remain. Source-only; consolidated qualification pending.
- Author one inline current-member cleanup-validation row with consumed completion and mutable advancement. Release member helper/family backing after canonical comparison, retaining phase proof/census/memo state and cumulative physical debits. Preserve the full unindexed oracle, ten existing controls and large-member whole-phase observations; add foreign/stale/repeated advancement and actual row-Drop/no-refund controls. Source-only followup; executable qualification remains pending.

- Resolve body-dependent byte-helper callers afresh under function reuse, using the exact shared source proof signature frontier and complete nested call traversal. Current transitive proofs, diagnostics, proof failure and reservations remain; ordinary scalar generic callers still reuse. Author full fresh/error, prior Agent authority, metadata drift and actual allocation/Drop with exact funding controls. Source-only; execution pending.

- Harden complete function reuse signatures with exact yields/follows clause equality and full fresh/nonreuse AST-mutation verdict controls. Make owned-text substitution identity leaves exhaustive so future type variants require review; saved old traversal remains unchanged. Source-only and unqualified.

- Author exact generic-environment selective reuse of unchanged monomorphic function HIR. Complete ordered generic signatures and an exact-current source capability replace the blanket generic exclusion; current templates and the full derived instance closure are still rebuilt independently, with previous generic payloads excluded. Full fresh-owned, stale binding, body/closure/argument drift and actual paid allocation/Drop controls are authored; the genuine Vec/Box reuse assertion remains. Source-only and unqualified, with no generic-instance caching or efficiency claim.

- Author ordered deferred cleanup validation over sealed exact current members, lazily reused census/proof storage and stable ordinary-family cells. Preserve original lexical global-owner priority, canonical compare order, Boolean proof refusal and complete independent final replay. Retain the full saved validator and source-author hostile, exact/short and whole allocation/debit/Drop controls; executable qualification is pending.

- Author exact borrowed reserved-record-invariant lookup in the existing declaration map, preserving arbitrary stored declaration presence and complete UTF-8 byte order. Retain the owned suffix-key oracle and author hostile identities, literal zero-query-allocation and complete Drop controls. Source-only followup; executable qualification remains pending.

- Author inline HIR type-admission frames, lazy generic classifiers, and borrowed owned-text record traversal. Presence/ownership queries retain exact arbitrary-cache-first flags; compound substitutions, cycle/depth/field/leaf bounds and diagnostic order remain. Complete pre-change eager and owned traversals plus hostile, boundary and actual allocation/Drop controls are retained. Source-only tranche; coordinated execution and application-efficiency evidence remain pending.

- Keep resolver capacity observations allocation-free while retaining the complete saved HashSet census outside the production allocation observation. Exact highwater, duplicate scope and nested continuation controls remain. This corrects test harness contamination and does not represent a production allocation or live agent token reduction.

- Borrow exact generic-template binding types while retaining ordered scope snapshots, substitutions, duplicate diagnostics and the full owned-map oracle. Compose current finite record-discard Graph v84 only after independent source/HIR/loan/capacity/cleanup replay; preserve frozen, detached and native-import refusals. Repair the checked native allocator zero-clause join without removing existing authority checks, and use the actual ordinary interpreter engine for its private provider controls. Paid scope checkpoints, fixed initial loan-plan staging and cached flag-only queries retain complete owning controls. Consolidated focused execution and scoped Clippy are pending; these compiler changes do not establish live agent token savings.

- Reuse exact initial loan-plan funding in linked workspace metadata, borrow complete authored/instance HIR for provenance, and avoid declaration-index Drop scratch for leaf roots. Preserve full derivation, diagnostic order, canonical replay and iterative nested disposal; independent old-path allocation and hostile controls await current-source execution.

- Fund initial authored and concrete-instance loan-plan construction through one captured existing CFG owner (OPT792). Preserve the original group publication/error order, full independent later rebuild, exact limits and original whole-pipeline observers. Add complete legacy attachment and actual planner backing through Drop controls; current-source execution remains pending.

- Author a selective explicit CopyDiscard statement and the finite owned-record loop profile for OPT779. Source and HIR independently retain the no-result boundary and exact counter shape; canonical cleanup, all three engines, Graph v84 and checked-HIR cache v10 are joined. The original lifetime fixture and allocation limits remain unchanged. Source-only controls and qualification are pending.

- Author named-only explicit `string_take` ownership forwarding (OPT790), preserving default clones, full source/HIR and independent canonical cleanup checks, and frozen public profiles. Initial native/interpreter/private Wasm and hostile gates are authored; qualification and complete acceptance remain pending.

- Reduce discarded HIR classification and identity-audit scratch (#789): nested owned-byte admission counts leaves without building unused field paths or formatted cycle keys, flat admission avoids a discarded result vector, and exact nominal/type-parameter identity leaves retain their NUL checks without a heap worklist. Saved classifiers, exact original bounds and diagnostic priority, and complete query Drop observations remain owning controls. Fixed test-only core debit traces additionally locate checked-cold/ordinary cache report differences without changing Budget layout, graph fields or caps. Source-reviewed; grouped execution remains required, with no whole-validator funding or application-efficiency claim.

- Author Borrowed Record-Field Uniqueness v1 (#786): `vec_unique_by<Row>(rows, "field")` borrows one named admitted Copy-record or owned-leaf record Vec for the call and returns Bool for one literal `string` or `i64`/`i32`/`u8`/`usize`/`bool`/`char` field. Floating and Bytes keys, the legacy two-Bytes carrier, paths, temporaries, generic roots and while bodies stay closed (`SPX-T319`/`SPX-T283`). A distinct `core.vec.unique-by.v1` descriptor reuses only the explicit sort-key layout/field derivation and is replayed by source admission, both resolvers, HIR validation, every backend, workspace source projection (`SPX-G173`) and Project snapshot replay. Interpreter, native C11 and private Core-Wasm (`env.spx_vec_unique_by_v1`) heapsort one `4 * len` ordinal scratch in place, compare full keys and free scratch before the result; refusal is `semaprax.vec.v1` code 3. Selective prelude v18 binds new programs only. ShiftSim's `unique_patient_ids` adopts it; the former clone/sort helpers are kept byte-for-byte as an independent test oracle. Source-only and unexecuted; no qualification, fit or cost claim.

- Author a closed ordinary scalar lexical receiver for retained Workspace schema selection (OPT766). Both retention routes capture a separate inventory for no-import modules whose every retained function, contract and dead branch is a Value scalar shape with typed exits (exact path, module, ordered identities, origins and typed member digests; no revision, plan or schema). The Semantic Workspace preflight passes its own held sources: the receiver recomputes the source revision, authenticates exact live membership and namespace facts, and replays every member (lexical and scalar) on one paid Acquired→Preparation→Session owner. Only the resulting private consumed receipt selects the module's family, through the base classifier's now-shared v17..v10 mapping. The persisted terminated-guard owner's module therefore no longer reaches the frozen from-parts G410. Every other shape, and Change/Structural Change/Operations views, keep their existing route and refusal; frozen from-parts selectors still refuse. Session engine Diagnostics remain unfunded (#781). Oracle-parity, source/namespace/member/detached/inventory attacks, closed-family exclusions, plan mutation, exact/one-short and Drop controls are authored; source-only, unexecuted, with no fit or efficiency claim.
- Author the valid-only shared `DeclarationId` foundation (#785): a closed allocation-free compiler-static spelling or immutable `Arc<str>` backing, exact text Eq/Ord/Hash/Debug/wire and Borrow<str>, with the actual 24-byte inline layout asserted. Explicit paid borrowed/owned constructors return refusal outside the carrier and reserve backing before allocation; legacy `new` is infallible and explicitly unfunded without ambient budget access. Compiler-constant queries and borrowed graph lookups no longer construct temporary identity text. Decoder preserves wire and charges local plus owning budgets independently. Dynamic legacy construction migration and whole-engine funding remain open; source-only controls are authored and unexecuted.
- Author immutable borrowed `Slice<u8>` source `for` traversal (#780, OPT780). One `byte_len` snapshot, an ascending counter and one `byte_get` receiver whose only arm is `Some` replace manual length/index/Option/latch scaffolding; an inconsistent `None` reaches the existing invariant refusal on every backend, and every other partial `Option<u8>` consumer was audited to admit only the fully authenticated receiver. The view's whole or subrange root is frozen for the whole traversal by the source verifier and, independently of view liveness, by an HIR census over authenticated provenance and a `TraversalFreeze` loan on the resolved owner. Graph v83 owns the additive `borrow_bytes` latch, `"exhaustive":false` receivers and freeze loans; checked-HIR cache compatibility rises to `semaprax.project-checked-module-hir.v9` for `SourceForKind` tag 3. Programs without a receiver keep their prior schema and bytes. The byte form builds its pieces in place and debits the receiver's exact backing before construction; the workspace `for` prebound stays 16. Exact/one-short/sticky/Drop compiler controls and an interpreter peak no-copy/Drop control are authored. Build, execution and live gain measurement remain pending; generic-instance and native-Rust interop builder routes remain unsupported.
- Give the actual retained primitive lexical replay caller a paid outward report (#781/OPT781). An affine acquisition/preparation/Session chain keeps its report and ledger together without a pairing argument at refusal or finish. The carrier pays for one Diagnostic slot and its caller's fixed literal on the module's selected ledger before preparation. Setup, authentication, constructor and Session refusals transfer it with the exact failed ledger owner. A refused carrier returns the rejected ledger and a Copy reason instead of a Diagnostic. Local, imported-helper, graph, type, record and current-module authenticators and the selected declaration constructors now refuse with a Copy `Refused`. They allocate no discarded Vec or String. A budget refusal's prepaid text, or a Session's own Diagnostic, is moved once into the failed preparation as its first receipt and is never cloned, formatted or published. `finish_paid` returns the same boxed ledger with no refund. A missing or mismatched paid form fails closed to a typed `Unpaid` boundary, and only its named `into_unfunded` allocates. Change (G184), Structural Change (G192) and Operations (G200) prepay the literal they remap to, and pass-through routes keep G410. The owned-Diagnostic `Preparation` and `Session` retry/finish APIs are now test-only. Remaining unfunded allocations: outward legacy wrappers, non-replay view refusals, the shared scalar purity classifier's structural refusals, and non-budget replay-engine Diagnostics inside the Session. Public literals, types, ceilings and admission are unchanged. Zero/one-short, original-pointer, prepaid-receipt, no-discard, same-ledger/first-receipt, Drop and no-restoration controls are authored but unexecuted.

- Borrow the exact-current nominal type and interface inventories in scalar, owned-data and internal Wasm type reachability (OPT784). Every module's identities are still checked for duplication before the closure walk, including unreachable ones, with unchanged SPX-G173/G172 text and order; RI-06 and indexed-owner admission scan borrowed interfaces in the same flattening order, field visits use borrowed slices, and selected declarations are cloned once at publication. No reservation ledger or forecast covered the removed copies, so none changes. A saved owned-map oracle, workspace/HIR parity, unreachable-duplicate, resource-admission, nested generic, allocation/Drop controls are authored; source-only, unexecuted, with no fit or performance claim.
- Borrow immutable Kernel-0 parameter and local identities in call-local evaluator environments (partial OPT708), removing larger inline identity slots and Arc clone/drop traffic. Reverse shadowing, fresh calls, lazy/first-fault behavior and source binding remain unchanged. Saved owned-environment and literal allocation controls are authored; execution and whole-formatter performance remain pending.
- Add internal monomorphic whole-subtree `match own` record bindings (OPT779). Source/HIR checks retain exact field identities, full inherited limits and descendant-loan blocking; independent cleanup transfers map the complete child leaf suffixes. Native and Wasm use existing fieldwise carrier moves, and frozen public profiles remain closed. Recursive-control, failure, hidden-limit and plan-forgery gates are authored; qualification, cache/full-allocation accounting and original Catalog acceptance remain pending.

- Remove temporary owned declaration IDs from all five Kernel-0 renderer entry lookups (partial OPT708). Exact current-program lookup order, source binding, evaluation and settlement are unchanged. Independent lookup allocation and authenticated evaluator parity controls are authored; qualification and whole-formatter performance remain pending.

- Replace iterative HIR lowering's owned expression-path strings with a private parent/edge path arena (OPT778). Continuations hold four-byte coordinates; nodes keep only their own closed edge spelling, checked length and frame height and are released at each pop, so at most one stays live per frame slot. Final `ExpressionId`/local `ValueId` bytes stream back to front into one exactly charged buffer with the unchanged owner/domain/length/path encoding; `scoped_identity` remains the independent oracle, and the recursive reference keeps text paths through it. Closure, record-pattern and synthesized `for` lowering materialize once with exact charges. `RESOLVER_FRAME_BYTES` now bounds one frame slot plus its arena node; its compiled value and pinned builder phase peaks need re-derivation. Budgets, forecasts' formulas and public identity bytes are unchanged. Oracle, slot, growth/refusal, allocation/Drop and full-HIR differential controls are authored; source-only, unexecuted, with no recovery or memory claim.

- Author Scoped Record Row Loan v1 (OPT-775): a flat owned-leaf `for borrow` row may be lent call-only, as a direct argument, to an ordinary monomorphic `borrow R` helper whose body and contracts are independently proven to read only Copy scalar fields. HIR carries a versioned `RowLoan` descriptor (Vec place, index, element, traversal region, length bound, callee, exact parameter) validated against its call slot, traversal freeze and helper proof; the receiving call holds a whole-Vec `BorrowedCall` loan. The helper stays one authored function: native lent parameters take a versioned tagged carrier (ordinary callers adapt resident records), Wasm keeps the one-pointer ABI with a bit-31 loan tag and reserves only the 16-byte loan block, never record-sized storage for the nominal argument, and the interpreter checks the Vec generation once while staging and then aliases the frozen row (no per-read generation check; the validated freeze excludes mutation). Graph v82 and checked-module cache v8 project and encode the descriptor; workspace replay binds each authored slot to current local or provider source. Copy-record rows and every storing, returning, capturing, owning, forwarding, viewing, generic or function-value use stay `SPX-T284`. Owning definitions are authored; no gate has been executed and no efficiency claim is made.

- Author actual-binary public CLI codec suitability controls (#773): twelve-profile receipts, whole-row bounded continuation, exact/+1/one-short output, source and manifest drift, capability versus shape, and read-only grammar refusals. Every query checks the complete fixture tree for writes. Source-only checkpoint; current-source execution qualification remains pending.

- Borrow exact authored AST declarations during uncached, import-free,
  invariant-free synthetic projection resolution (partial OPT776). The sealed
  presentation owns only an optional scalar main, retains complete source/HIR
  verification and reduces only the reservation for the absent AST copy.
  Cache/import/invariant paths remain paid owned inputs. Owning parity,
  pointer, allocation-free overlay Drop and budget controls are authored;
  qualification and original Catalog/Shift fit remain pending.

- Chain decoded-identifier fingerprints through 64 bounded Copy buckets (#748/#771) in the generated request-view record decoder and the Catalog Normalizer's first-failure scan, so a probe walks only its bucket instead of every prior entry. Bucket heads and links are ordinary reserved `Vec<usize>` backing (64 and 256); full decoded-token equality still decides every equal fingerprint, including deliberate collisions. Grammar/cardinality/schema/duplicate/total/provider order, offsets, the ASCII 1..16 request policy, the 1..64-byte UTF-8 id policy, fuel and public limits are unchanged; the eight-server scan and the frozen pairwise reference stay direct. A request-view max-shape regression (256 colliding/escaped rows, 257th refusal, last-row duplicate, early-duplicate/late-schema/grammar order) is authored on interpreter/native/Wasm. Source-authored only; qualification and fuel effects are unmeasured.
- Replace native lexical-anchor Block/Match prefix rescans with the existing fixed-depth borrowed child cursor. Authored order, exact anchor ambiguity, assignment identity, iterator tail behavior and the 256-frame/1,000,000-work bounds remain unchanged; both actual Block scans are paid before traversal. Independent indexed-order, wide linear-debit, exact/one-short and hostile depth/duplicate controls are authored; qualification and performance measurement remain pending.

- Label previously unlabelled resolved-core builder reservations with compiler-owned operation stages, retaining the first sticky refusal and restoring nested labels. The 64 MiB budget, reservations, forecast and construction behavior are unchanged. Catalog’s prior 2,048-byte refusal remains unattributed; source-only diagnostic controls are extended, with qualification pending.

- Separate recursively retained interpreter Binary/If/Call/Block bodies from the giant expression match, preserving their original code and charging once at entry. Existing terminal-order tests now label each exact route/backend before dispatch. The retained debug artifact showed a 125,024-byte old evaluate prologue; the new artifact and full 256-frame canonical status/fuel/cleanup parity still require qualification. Worker stack and all admission limits are unchanged.

- Repair private BytePartition source controls against actual compiler contracts: admit only the checked usize-to-i64 scalar publication conversion in the current graph, keep owned aggregate returns on a non-entry helper, and preserve the 256/257 conservative view boundary with independent actual loan-site counts. Ordinary admission stays closed; original 4096 and hostile receiving controls remain unchanged and qualification is pending.

- Author private original-source native partition receiving (#746): a current sealed source projection selects shared carrier/helper bindings before canonical function emission, stages the actual operation failure before commit, and settles one invocation registry before publishing the result. Original 4096/count and four-status O0/O2 owning controls are authored. Ordinary/public admission, consuming iteration, Borrow-parameter receiving and complete native runtime funding remain closed or pending; no execution claim.

- Retain the first source-selection refusal from the existing fused construction derivation, preferring the authored main. SPX-F130 now reports its held function location and bounded shape guidance; legacy constructions point to the ordinary route without reducing requirements. Admission, ambiguity, source diagnostic precedence and no-fallback behavior stay unchanged. Existing hostile and legacy controls are extended; executable qualification and agent savings remain pending.
- Correct bounded agent language help for static borrowed UTF-8 literals, explicit fused source opt-in versus ordinary native builds, and exact-zero lexical guard completion. Add compiler-checked source examples and preserve the existing help budgets and pending qualification boundary; the diagnostic projection is regenerated by its owning producer.
- Author bounded read-only exact-type codec shape explanations (#773) using existing generator predicates and selector metadata. Current source/revision receipts, optional unmet policy, actual import discovery and whole-row continuation remain separate from candidate/backend admission. Owning source controls are authored; execution and #722 discovery trials remain pending.
- Author a reusable decoded-key fingerprint index in `std.data.json.dec` (#771): `decoded_fingerprint` folds one token's canonical decoded bytes once into bounded Copy metadata (decoded length 1..=limit, hash mod 65521), `fingerprint_entry` packs it with the opening offset, and `fingerprint_match` rejects unequal fingerprints while every equal fingerprint, including each collision, runs the exact `decoded_token_eq` comparison. The Catalog Normalizer's first-failure scan uses it for all 1–64-byte decoded UTF-8/NUL/escaped ids in place of its `item-###` filter, preserving input order, second-occurrence offsets, preceding grammar/schema/enrichment errors, checked totals and no-prefix publication. The pre-change pairwise batch/record pair is frozen as an independent whole-application reference. Host decoded-byte oracle cases cover deliberate ASCII/non-ASCII/NUL/64-byte-prefix collisions, escaped/surrogate/raw equivalence, 64/65 bounds, 256 rows and earliest-duplicate ordering. Source-authored; qualification, runtime and token effects are unmeasured.

- Author source-bound defining-record sidecars and borrowed retained type closure for explicit monomorphic type imports (#745). Current module/type pointers, revision, layout and field namespace facts authenticate only the demanded declaration on the same preparation transferred into replay; exact Vec field-read digests and cumulative full-chain controls are authored. Generic instances, unsupported provider bodies and broader typed closure remain closed; execution qualification is pending.
- Repair three fused receiving drifts against the frozen original 33/4096 receipts (#747/#768), sources unchanged. Native: the owner prelude's resource ABI now runs the owner's complete selected revalidation through a new owner-only constructor instead of ordinary validation, which refused the joined loop with `SPX-H006`; raw programs keep ordinary validation. Core-Wasm: a leased payload view now ends only by its exact `SliceView` loan, rederived from authoritative end edges that must be dead on every entering edge. It ends at every end point (the operand after its last read and the short-circuit join skipping it) with guarded ends, not at the transient Vec-operand loan sharing its site that retired it before `view_len`. Interpreter: successful checked arithmetic no longer builds and drops its overflow status (four allocations per row), fuel/depth exhaustion and every other out-of-band flow (guard refusal, cancellation, materialization limit) settle only a certified empty ownership state and never reuse the failure exit of the expression they stopped at, and only an actual language failure matches its exact operation-failure lane exit. Account bounds are unchanged. Positive, hostile and guard-text controls are authored and unexecuted, pending the parent batch.

- Author the explicit source-only `fused-construction-v1` run/build facade (#768): read and parse once, hold the sealed full-validation owner through receiving, require a finite caller managed account, preserve ordinary route refusal and expose only settled results. Native/Wasm fuel is not advertised as interpreter fuel; paired package publication and target-specific account contracts remain mandatory. Original 4096, hostile option, failure and actual allocation/Drop gates are authored; qualification and broader #747 completion are pending.

- Authored private native fused-row receiving now requires the concrete full
  selected owner and freshly revalidates its immutable source/HIR. Exact row
  backing is funded on the same held physical ledger at the original Vec
  boundary; address-bound receipts preserve pointer geometry and one allocation
  attempt through cleanup. Original 4096-row O0/O2 and cumulative account gates
  are authored, with execution qualification pending and default routing closed.
- Repair v0.10 interpreter leased-byte reads after the owner core made refusals sticky: thread mutable registry access through borrowed views and compare two authenticated loans together without payload copies. Add paired-read and foreign-loan regression controls, restore stale test API usage, and apply the required Rust formatting while retaining the workspace graph test size budget through an unchanged test submodule. The all-targets/all-features workspace compile and 26 owning regressions passed; the full profile stopped on five unchanged v0.10 documentation failures, and the separately selected interop unary depth fixture still refuses with SPX-H006.

- Finish the installation implementation batch against released v0.9.0: advertise both per-user scripts and five native archives from recorded hosted evidence; preserve receipt-scoped files during upgrades; retain Windows rollback material through atomic receipt publication; add real previous-release upgrades and shared Windows CLI/daemon acceptance; retain deterministic Homebrew/WinGet proposals and a post-release package-channel gate. Release-note limits now count UTF-8 bytes. The consolidated five-target installer/channel qualification passed at `0c9c2a2fe` in run `38156173827`, and the public Homebrew tap serves v0.9.0 on both native macOS architectures. The attempted full quality profile hit inherited v0.10 compiler error E0596; WinGet public indexing remains subject to external moderator approval.

- Admit an optional `;` after a bare valued lexical-exit guard (`if skip { continue; } else { 0 };`) when another block item follows (#766). The parser reuses the existing StatementIf marker, tree, discard name and canonical text of the unterminated spelling, and admits it only when a parsed exit is present and the next item cannot continue the value `if`, since canonical text drops the `;`. Generic discarded initializers, conditions, postfix/operator continuations and other value boundaries keep `SPX-T312`; `SPX-T313`, `SPX-P209`, `SPX-P106` and scalar-only discard are unchanged. The source contour now also requires the marker's normalized shape and, mirroring HIR, a guard whose every normal completion is the scalar discard zero; owned, aggregate, borrowed, non-`i64` and nonzero normal arms get a source `SPX-T312` in both spellings instead of a later HIR `SPX-H006`. Differential, hostile, nesting-bound, cache/graph and three-backend regressions plus updated compiler-checked help are authored; qualification is pending and no efficiency gain is claimed.

- Restore proved-absent root cleanup storage in the summed constructor-exact cached forecast (#764): literal, unary and binary roots, which every resolver path builds as `Value` primitives, omit only their four storage footprints from each retained parsed/semantic HIR copy. Children, checked/lazy failure blocks, bookkeeping, identities, strings, carriers, unproved fallback kinds, caps and live reservations are unchanged. Independent census, resolved inventory/plan, malformed-census and exact/one-short controls are authored but unexecuted; owning application qualification and any recovery remain pending.

- Author a borrowed current private type authority view (#765). Ordinary, compact and declaration-fact validation callers no longer rebuild an owned top-level function/type map. They reuse the invocation's authored index only after exact caller, member pointer, path, module, kind, explicit-identity, census and charged function/type kind-census proof. Slices with class methods keep the old map. Root/cursor reservations, duplicate/foreign refusal, work limits and quotas are unchanged; the proof's added scans are charged. The saved-map differential, hostile binding and exact/one-short/Drop allocation definitions await grouped qualification. The normalizer refusal causality, admission and any CPU or agent gain remain unclaimed.

- Author a single-walk retained helper closure graph (#763): a sorted borrowed directory of caller functions plus only authenticated selected members, grown with charged moves and comparisons, original-order ordinals, contiguous outgoing-edge ranges and one Kahn visit per edge under the existing preparation. Unchanged target authentication and provider receipts precede every publication; the saved complete-entry oracle, irrelevant-provider/long-ID default-cap controls, walk/visit counters and exact/one-short entry definitions await grouped qualification; no measured saving is claimed.

- Author an invocation-local borrowed helper directory (#762), preserving provider inventory, source authority and authored order while classifying each eligible body once. Independent old-capture, hostile identity, and exact/one-short work/backing controls await grouped qualification; no measured cost gain is claimed.

- Author ordinary checked LF-only NDJSON framing and Copy structured faults (#760), composed through actual receiving byte ranges in Catalog Normalizer. Preserve total legacy wrappers, frozen error ordering and 160M oracle; independent original/backend and hostile receiver definitions await qualification. Numeric frames carry no owner or generation authority.
- Authored exact borrowed Str/Slice helper-root and scalar-u8 conversion replay; added guarded Copy Option-u8 metadata, distinct-case, ordinary reader and factory-budget controls. Option receiving admission remains closed pending cumulative schema/inventory metering and executable qualification.

- Author a defining-source-bound retained static-UTF-8 composition with imported pure monomorphic scalar helpers (#745). Borrow exact provider HIR, authenticate the whole acyclic closure and replay every helper's real status/cleanup proof with one cumulative work/backing owner. Equal-name aliases, checked failures, stale/hostile provider and plan controls, saved local backend comparisons and exact/one-short allocation/work definitions await grouped qualification; broader #745 remains open.

- Activate deferred lexical replay resource selection and exact expression-scoped Copy factoring (#759), retaining independent lexical/certificate/ownership validation, multiset traces and unchanged enumerated/work ceilings. Keep selected physical provider/type exclusions and cumulative backing/work ledgers. Whole-entry, forced-strategy and immutable original ShiftSim qualification remain pending.

- Attribute seven previously unlabelled live workspace reservation seams with compiler-owned operation stages. Keep exact ledger charges, nested-budget resets and sticky first refusals. Exclude only exact borrowed Vec length/capacity observations from invented census operation failures, retaining every child path and independent enumeration control. Pin the frozen two-Bytes record profile to its documented five operations. Grouped qualification remains pending.

- Repair independent terminal-expression cleanup classification, exact borrowed String-slot result replay and matched loop admission. Preserve nested type refusals, cached-HIR hostile controls and existing lifetime boundaries. Replace audited projection wildcards, compact CLI prose within its unchanged budget and use saturating growth arithmetic. Grouped executable qualification remains pending.

- Advance ASCII once in ordinary UTF-8 scans and reuse checked quoted lengths in generated UTF-8 sizing. Preserve fallback, earliest faults, invalid short circuits and all limits; frozen original/backend differential definitions await grouped qualification.

- Keep generated UTF-8 validator identities while sharing bounded scalar byte
  kernels through the existing JSON scan/UTF-8 source modules (#753); owning
  executable qualification pending.
- Derive lexical terminal paths from exact nearest-loop breaks, actual generated continue advances and function-return postconditions; retain full authored structural scans and unchanged path/work limits. Independent enumeration and reservation regression definitions await qualification.
- Authored typed `vec_of<T>(...)` construction with bounded hygienic expansion, independent source/HIR provenance, selective Graph v81, ordinary per-push call commits, and private backend regression definitions. Eight-server/two-item examples adopt the syntax; all executable qualification and efficiency measurements remain pending.

- Read each ordinary JSON string-framing byte once in the source scanners and Query plain-byte path, preserving eager offset arithmetic, escape policies and failure encoding. Retain independent original kernels and all-byte/backend differential definitions; grouped execution and measured benefits remain pending.
- Added a summed exact cached construction fallback distinguishing parsed-only
  from semantic HIR retention, preserving old fitting receipts, quotas and the
  uncached-only peak/filter boundaries. Owning qualification remains pending.

- Repair terminal record-arm HIR admission and native resume-only scope cleanup; preserve independent contour/authority proofs. Add whole-token ASCII validation with the unchanged UTF-8 fallback, and correct owning fixture shapes and bounded help without changing limits. Consolidated qualification remains pending.
- Author same-storage primitive String-slot lowering for interpreter, native and private Core Wasm, preserving whole-Vec loan expiry, Vec/2 failure, resume-scoped commits and separate owned-Str/Slice/foreign extent boundaries. Exact allocation/copy and hostile-provider regression definitions await executable qualification.

- Authored the bounded primitive `vec_str_at` frontend, fixed String signature,
  scoped whole-owner provenance, fused byte-view identity, and selective Prelude
  v17/Graph v80 replay. Owning regressions are unexecuted; backend/application
  qualification and cost evidence remain pending.

- Add lazy ordinary JSON scalar paths for ASCII UTF-8 and selected escape kinds. Preserve the original checked arithmetic at near-limit offsets and retain independent original kernels in owning differential definitions; backend qualification and measured work remain pending.
- Adopt explicit business sort keys over Catalog wire rows, removing the intermediate SortItem carrier and output Vec rebuild while retaining complete pre-selection validation, wire order, bounded metrics, and the independent original 23-case pipeline oracle. Owning qualification and measured benefits remain pending.
- Compose exact owned normalization Input with existing independently admitted flat collection outcomes at ordinary match tails. Preserve malformed-shape, ownership, provider, cleanup, ABI and quota guards; source/HIR and three-backend owning definitions await executable qualification.

- Generate direct ASCII scalar/advance checks for JSON identifier validation and owned UTF-8 prefixes, retaining original escape/non-ASCII validation and all grammar, size and fuel limits. Independent original-path differential and maximum-capacity backend gates await qualification.
- Retain inactive iterator Done storage in its exact authored region and confine
  owned record Bytes-field moves to authenticated match-arm bindings. Preserve
  full structural replay and path limits; grouped backend qualification pending.

- Authored scalar expression statements: intermediate Copy scalar `expr;` keeps canonical spelling and lowers to hygienic immutable ordinary lets. Final-tail, underscore, owning discard and lexical initializer boundaries remain checked; qualification pending.

- Retain actual lexical String temporaries until canonical settlement and authenticate iterator condition feasibility across construction, replay, native and Wasm routes. Make isolated help links self-contained, preserve compact diagnostic advice and restore Projects help within its existing budget. Grouped owning qualification remains pending.
- Author bounded private nominal layout reconstruction behind explicit library roots, with fresh synthetic aliases, unchanged authored visibility/edges and quotas, exact clone forecasts, and hostile owning definitions. OPT #754 owning executable qualification is pending.

- Repair exact owned-record clone loans, independently authenticated cross-row Vec renewal, selected lexical skeleton reservation, and Wasm continuation after certified bottom statements. Preserve owned Str carriers and derive npm's exact fixed memory extent independently of public result authority. Reconstruct compiler Vec facts for retained nominal fields without widening imports. Grouped owning qualification remains pending; quotas and public ABI admission are unchanged.
- Preserve exact native String-copy and encoder Bytes-OOM observations, all full-bound UTF-8 wire cases, ordinary-versus-lexical record authority and owning closure refusals. Clarify fresh discard names in agent guidance; `_` remains an ordinary binding.

- Repair borrowed-Str byte-writer proof signatures, exact-extent interpreter search, nested final-UTF8 native borrow arguments, and certified bottom-binding Wasm lowering. Consolidated owning qualification remains pending; foreign ingress, source admission and resource limits are unchanged.

- Replace value-proportional JSON byte and UTF-8 offset probes with existing checked numeric conversions; retain contracts, grammar and fuel limits, with all-byte source conformance awaiting grouped execution.

- Author OPT #750 linear saved-cursor work debits for selected primitive replay,
  renewal reconstruction and resolved byte-helper proofs, preserving work/depth
  and physical bounds with exact/one-short gates; owning execution remains pending.
- Keep complete original HIR authority for selected final-UTF8 resource ABI
  preflight while retaining the exact filtered emission closure and resource
  refusal gate; authored exclusion/forgery regressions await owning execution.
- Repair native owned String view validation to retain exact owned extent while keeping foreign root and internal Slice bounds separate; select constant-space linear contains only for owned-view programs. Author long-view, matcher, ingress and backend settlement controls; executable qualification is pending.
- Move scalar-match guard and arm-value cleanup replay onto the existing bounded heap continuation machine, retaining path order, failure selection, String result transfers and limits; owning regression definitions await grouped qualification.

- Authenticate the compiler-owned owned-Bytes borrow projection in the selected
  final-UTF8 profile, retaining exact intrinsic-call validation and refusing
  Array views or named aliases. Extend the JSON helper inventory oracle to
  visit admitted byte-array literal leaves without changing field-read, clone,
  wire or backend assertions. Grouped executable qualification is pending.
- Author OPT #748 collision-safe decoded-identifier duplicate prefilter in ordinary generated request source, retaining full equality on matching fingerprints and existing fuel, cardinality, grammar priority and domain refusals; owning execution remains pending.

- Propose the unimplemented OPT #746 owned Bytes consume-and-partition contract: bounded disjoint leases, exact staged transfer and selected-domain lifetime, without changing existing allocation quotas or admitting the maximum-row constructor loop.

- Authored consuming owned-record outer Vec renewal with independently recovered
  iterator authority, existing v15 reservation replay and selective Graph v79;
  native/Core-Wasm and hostile regression definitions await qualification.

- Author a separate selected-file resource profile with 256 raw argv and the
  existing v28 String/output envelope. Add a LogLens reference whose source
  owns usage and whose wrapper grants only the selected file, plus an opt-in
  capability-authenticated future setup. Preserve original CLI49, retained
  tests, historical evidence and TypeScript task; qualification remains pending.

- Add an invocation-selected native64 Unix file-input profile with an optional
  host selector that preserves complete application argv. The first checked
  read lazily acquires one held regular-file descriptor under an explicit
  follow policy; settlement precedes staged output publication. Retain the
  existing relative-root no-follow provider. Owning O0/O2 regressions are
  authored; executable qualification and efficiency measurements are pending.

- Correct lexical completion graph facts, exact iterator argument-slot reuse,
  scoped literal JSON writes and admitted workspace/cache fixtures. Add a
  selective authenticated lexical npm recipe while retaining frozen v8 bytes
  and refusals. Document the grouped contracts in the specification catalog;
  focused executable qualification remains pending.

- Render derived application JSON responses through ordinary functional Bytes
  writers after complete length preflight. Add exact runtime-sized bounded
  allocation, independently proved nonallocating helper renewal, selective
  cleanup v19 and graph v76, and retained-workspace/cache/backend composition.
  Preserve wire ordering, escaping, limits, source authority and old profiles.
  Grouped executable qualification and physical/task-cost measurements remain
  pending; no measured efficiency improvement is claimed.

- Repair Copy-record Vec shared-read classification, authored multi-key sort
  renewal arity, absent-sort workspace allocation, exact scratch-refusal
  witnesses and lexical latch replay order. Retain fixed budgets and independent
  hostile checks; replace malformed fixtures with admitted source cases.

- Specify recoverable String allocation and author a private explicit-context C
  kernel plus physical failure probes. Production proof, code generation,
  interpreter/Wasm injection and typed application outcome integration remain
  open; this private precursor does not complete OPT #724.

- Author statement-tail lexical break, continue and return with independently
  bound function/nearest-loop targets, source-for latches, selective cleanup v18
  and loan v3. Preserve accepted acyclic returns and old schema bytes; keep
  initializer/argument/aggregate/closure/unsafe/yields crossings closed. Add
  bounded `help language author:lexical-exits` and source/HIR hostile definitions.
  Executable qualification and full OPT #734 acceptance remain pending.

- Eliminate zero-argument nominal identity traversal carriers and duplicate
  retained-key allocations through an exact bounded stack probe. Charge its
  scratch storage and keep generic/oversized identity handling, retained facts
  and encoded identities unchanged. Correct the grouped fixtures and private
  String-view host, and preserve authenticated cleanup-history debits at call
  commit. Executable verification remains pending.

- Normalize acyclic function guard and terminal match returns to independently verified value
  control flow, moving each continuation once and retaining contextual loop
  and closure refusal. Add canonical, graph, ownership-plan, runtime and
  failure regressions for the grouped implementation batch. Execution is
  pending; general lexical exits and OPT #734 remain incomplete.

- Derive bounded application codec plans against one immutable authored Project
  revision and validate the complete combined candidate before returning one
  exclusive new bundle. Preserve exact authored sources, candidate inventory and
  per-entry profile/bounds receipts; adopt the real paired ShiftSim setup and add
  drift, overlap and no-partial-output regressions. Execution remains pending;
  no managed publication authority or efficiency gain is claimed.

- Derive bounded nested JSON responses with recursive length preflight, borrowed
  record paths and up to two existing Vec owners. Repair owned Vec renewal,
  projected Wasm borrow calls, stream-to-nested-result joins and independently
  authenticated workspace schema selection. Reuse final loan candidate storage
  for independent backing charges and preflight selected generic scratch once.
  Add scoped language help and checked application formatting. Full backing
  charges, canonical cleanup and runtime limits remain unchanged. Grouped
  executable verification is pending; no current efficiency gain is claimed.

- Intersect retained loan-plan backing keys with a bounded full HIR walk,
  reserving complete scratch capacities for distinct proof candidates while
  preserving legacy receipts and the unchanged builder cap. Align finite
  owning-match cleanup, projected String reads and byte-range failure status
  replay. Repair generated JSON ownership patterns, genuine stdin bootstrap
  readers and direct nested-type imports; derive authenticated concrete record
  Vec defaults and check nonallocating response reads on the actual HIR surface.
  Grouped executable verification and live efficiency measurement remain pending.

- Pre-size retained loan-census scratch once per module, keeping complete
  reservations and the 64-MiB builder limit. Compose finite owned collection
  matches, Copy-record loop renewal and nested record layouts across source,
  HIR, cleanup replay, native and Wasm paths. Correct shared Node fixture
  arguments and bound the JSON help card. Grouped executable verification
  remains pending; no token-efficiency gain is claimed from static checks.

- Hoist generated JSON key views before loops and authenticate finite imported
  decode/encode result shapes and flat Vec element aliases. Correct authored
  example identities and native UTF-8 fixture roots/readers while preserving
  assertions, hostile cases and profile refusals. Executable verification is
  pending.

- Repair generated JSON effect-binding names and move fixed decoder key arrays
  outside loops. Authenticate nested collection cleanup and finite typed Project
  import joins across source, HIR, replay and native ownership paths. Preserve
  earlier profile refusals and original application corpora; grouped executable
  verification remains pending.

- Read named String views without cloning their owner in the interpreter and
  replay the closed conversion status table. Retain full-capacity spare HIR slots
  only when their cumulative charge is cheaper than replacement storage. Add
  exact-limit and one-byte-short witnesses; no measured token or memory advantage
  is claimed before execution.

- Add read-only typed-installation verification and preserve completed-stage
  failure evidence. Import byte-authenticated formatter outputs and repair
  terminal help and private adapter fixtures without reducing acceptance checks.
  Current-source pin regeneration and application qualification remain pending.

- Generate scoped Vec-field reads for collection-response preflight and rendering,
  preserving direct Row helper APIs, complete validation, wire bytes and limits.
  Retain explicit owning-clone failure coverage and add a clone-refusing positive
  witness for the generated two-String path. Avoided deep copies are a source
  finding; grouped execution and measured efficiency remain pending.

- Repair nested-outcome admission for the documented pure, no-export Project v8
  JSON-codec route using the actual selected export roots. Preserve public and
  older command refusals before unused-helper cropping and all ordinary source,
  HIR and cleanup checks. The real derived-project regression is source-authored;
  grouped execution remains pending.

- Route Graph v73 projected String views and v74 nested owning outcomes through
  concrete ownership rendering even without incidental Vec or loan features.
  Preserve exact additive schemas, source replay and frozen legacy refusals;
  the new routing regression is source-authored pending grouped execution.

- Release completed JSON-codec parse/round-trip temporaries before the full
  candidate Project rebuild, and move its canonical source buffer through that
  unchanged admission path. The source-only handoff regression preserves full
  typing refusals and original inputs; measured memory savings remain pending.

- Transfer completed Project semantic graph JSON and digest into retained state
  without cloning their owned buffers. Keep rendering, hashing and cumulative
  budget charges unchanged; pointer/capacity, digest and refusal regressions are
  staged for the next grouped check. No measured memory or token gain is claimed.

- Remove the standalone text/format runtime renderer's full-HIR clone by
  borrowing its authenticated selected functions. Preserve import order and
  exact artifact bytes; a selected/unselected parity regression is staged.
  Execution and any measured memory or agent-cost benefit remain pending.

- Align direct owned formatter Place transfers across cleanup construction,
  independent replay, native and Wasm with the interpreter; preserve ordinary
  String clones, pre-commit failure cleanup and post-commit worker settlement.
  Bind standalone format status 34 separately from conversion status 21; source
  regressions are staged and grouped execution remains pending.

- Reuse fully selected exact HIR carriers and the final uncached workspace
  loan-inventory allocation across functions,
  retaining full capacity charges, source ownership and the unchanged 64 MiB
  pattern gate. Repair Graph v75 generic-render routing and native projected
  Vec move/drop fixture obligations; grouped execution remains pending.

- Stage OPT-731 bulk UTF-8 codec materialization after complete existing token
  validation, retaining escaped decoding and exact input bounds. Escape-free
  quoting uses a bulk String copy; native length-delimited concatenation writes
  directly to one final carrier. Add scalar/escape/bound and physical native
  allocation/copy witnesses; current-head runtime and efficiency remain unverified.

- Improve manifest authoring help for quoted dependency keys and unsorted source
  lists without changing the closed grammar or stable refusal codes/messages.
  Traverse scoped Vec-field arguments in all affected owning test walkers.

- Author OPT-730 scoped `vec_field` reads over authenticated owned-record Vecs.
  Preserve exact carrier loans and field/index provenance, avoid semantic owned
  clones, retain sticky Vec bounds failure and bind checked-cache v7 to canonical
  selectors. Join conditional Graph v75, native and Wasm/Node field reads,
  source-index/repair and scalar/view/alias/hostile allocation-budget regressions.
  Owning execution and application qualification remain pending; no efficiency claim.


- Author bounded nested-request streaming derivation with a source-derived fully
  escaped spelling envelope, unchanged strict normalizer and one-call typed owning
  result; limits stay fixed and owning/application execution remains pending.

- Author the finite bounded nested-request source decoder for OPT-724: explicit
  acyclic record paths, existing Vec element carriers, bounded Unicode strings,
  whole-grammar/schema validation before owning construction, and proper typed
  malformed outcomes. Stage independent derivation/hostile and three-backend
  configuration/order gates; execution and full streaming acceptance pending.

- Author OPT-729 properly tagged outcomes carrying authenticated nested owning
  records. Preserve scalar error cases without a default payload, canonical
  case-qualified cleanup, existing capacities and frozen command profiles. Stage
  source/HIR/cache/Graph v74 and three-backend success/failure/zero-allocation
  error regressions for v32; execution and nested codec qualification pending.

- Author OPT-728 rooted record-field String views: exact source/HIR path and
  loan authentication, fused byte provenance, no-copy interpreter reads and
  Graph v73. Stage no-clone and failure-settlement regressions on interpreter,
  native O0/O2 and Core Wasm; execution and application adoption remain pending.

- Author OPT-727 bounded nested record composition with existing Vec owners,
  authenticated projected reads, fieldwise cleanup, distinct native/Wasm
  layouts and Graph v72 replay. Stage same-source success/failure, structural
  boundary, cache/loan and frozen-profile regressions for the v31 private
  command successor. Execution and application qualification remain pending.

- Correct native borrowed-root charging to identify actual external function
  entry rather than the first private borrowed frame. Internal owned Bytes
  forwarding preserves its existing 131,072-byte capacity, while external
  Slice/str input retains the cumulative 65,536-byte bound. Stage interpreter,
  native O0/O2 and strict Wasm capacity/root-bound regression; execution pending.

- Close the reserved String/conversion identity alias gap: authored declarations
  and retained HIR cannot impersonate compiler intrinsics by stable ID or
  executable function name. Add independent source/HIR guards and hostile
  cache-origin/template/instance regression sources; execution is pending.

- Author OPT-725 checked `char_from_i64` Unicode scalar conversion across the
  source/HIR intrinsic contract, interpreter, C11 and scalar/aggregate Wasm.
  Preserve byte conversion behavior and existing failure status; stage exact
  scalar boundaries, hostile graph/cache/HIR, lazy evaluation and staged-owner
  cleanup gates. Current-head execution and codec qualification remain pending.

- Author the owned identifier-request successor for OPT-724: checked derivation
  now emits actual String and authored-record vectors, deterministic encoding
  without retained input spans, and the existing whole-stream normalizer under
  original authority. Add independently authenticated private owning outcomes
  while preserving Copy-only and older command profiles. Detached input,
  unrelated catalog, partial materialization, backend and native stream gates
  are authored; execution, general nested codecs and efficiency remain pending.

- Author a separate Catalog23 application cohort with the unchanged staged
  requirements/corpus/oracle, fresh Project v30 source/compiler/native
  qualification and matched Codex arms. Retain the strong dependency-only
  TypeScript bootstrap, independently compile its authored source with pinned
  tsc/Node and preserve complete runtime module bytes. Qualification, owning
  mocked checks and live measurements are pending; existing cohorts and
  historical evidence remain unchanged.

- Add an explicit ShiftSim round-4 Project v30 owned-data authoring condition,
  fresh source/compiler/native-bound all-15 qualification, and pre-dispatch
  drift guards. Preserve historical rounds and the strong TypeScript prompt
  and bootstrap; disclose changed SEM harness context with unknown token/billing
  fields. Owning mocked checks and actual current-compiler qualification await
  grouped validation; no new live cost or acceptance result is claimed.

- Author the remaining OPT-723 owned-leaf vector slice: explicit deep clone,
  grouped replacement, bounded reserve, stable scalar/text ordering and
  consuming traversal, with independent source/HIR descriptors and private
  interpreter/native/Wasm projections. Add Project v30 while retaining frozen
  stream/public boundaries, Bytes capacity charges and ordinary cleanup replay.
  Pointer-inventory, partial-clone failure, stale authority and profile gates
  are authored; grouped execution, application acceptance and efficiency
  qualification remain pending.

- Bound default language help and application-route discovery, preserve the full
  reference under `help language all`, and page exact checked library signatures
  with explicit prerequisites and deterministic continuations. Correct the
  starter command grammar; current-head help gates and live measurements await
  the grouped batch.
- Add closed checked-source identifier/request-view codec profiles and incremental
  stdin JSON normalization for #724, with bounded Copy-view collections, source
  span revalidation, raw-versus-normalized diagnostics and provider-observed
  boundary fixtures. Source implementation only; combined execution gates and
  full application acceptance remain pending.

- Add checked-source derivation of ordinary application JSON codecs for private
  flat scalar records, typed invalid-input outcomes, exact output preflight and
  exclusive-create CLI publication. Preserve original profile admission and
  scanner semantics; first-tranche backend gates remain pending.
- Add the source-checked `string_format` literal operation with bounded brace
  grammar, grouped owned-argument staging, raw-template HIR/graph projection,
  and private interpreter, C11 and Core-Wasm rendering. Current-head focused
  and owning executable verification are pending.

- Store immutable loan endpoint and edge identity lists as exact boxed slices,
  retaining list order and cache encoding while charging shrinking overlap.
  Preserve conservative construction prebounds and exact retained payload census.
- Borrow retained user-function and static String/Str parameter descriptors
  during HIR validation; preserve owning generic signatures, error identities,
  recursive parity checks, and the iterative frame bound.
- Author ordinary logical text-collection declarations for faithful application schemas, with independent source/HIR structural facts and unconditional transitive runtime-use refusal. Add exact v29 stream-input Bytes/length outcomes without changing grants. Declaration, graph/cache and hostile gates are authored; runtime String-vector support is not claimed.

- Extend OPT-723’s unqualified collection tranche with independently checked two-case results owning up to two flat Copy-record vectors, private layout/cleanup carriers, and Copy-record variant loop calls. Actual-cardinality, hostile replay and exact floating-payload gates are authored; execution and application/agent qualification remain pending.

- Author Project v29 `language-command-io.stream-data.v2`: independently
  authenticated private Copy-record/Vec transport and exact bounded codec
  outcomes, with unchanged scalar command roots, stream authority and caps.
  Keep v27 closed; add source/retained/prepared/native and hostile-profile
  regressions. Execution and benchmark qualification remain pending.

- Author the bounded Copy Record Collections v1 core tranche: nominal scalar
  records in Vec, Copy reads/writes, named-field loops and deterministic field
  ordering across interpreter/native/Wasm. Preserve the 65536-byte scalar
  storage ceiling and existing public/Project profiles. Focused execution and
  matched application benchmark qualification remain pending.

- Attach the final resolved-core builder phase's first sticky reservation
  evidence to SPX-G171 help, preserving the exact message, ledger behavior,
  independent retry budgets, and unknown inner-operation attribution.
- Bind Native Rust Interop accounting pins to exact old/current nine-component
  reservations on unchanged canonical fixtures. Verify every retained-byte
  delta and derived sum plus byte-identical complete hostile HIR/cleanup/loan
  data; retain all limits, minus-one gates and four source SHA pins.

- Fix Native Rust Interop's depth-512 reservation by separating the three
  possible HIR identity backings from each single cleanup identity reference.
  Preserve the full backing-growth allowance and unchanged 32 MiB limit.

- Fix the unchanged 64 MiB pattern workspace gate with a final uncached profile
  that reserves the complete asserted expression footprint and audited identity
  carriers, then independently replays call facts against borrowed immutable
  edges. Keep all live debits, hostile checks and earlier profile receipts.

- Refresh workspace artifact KATs only after exact byte reconstruction of 62
  complete historical documents, including nested operations and review inputs;
  retain every limit, domain, replay, no-write and hostile assertion.

- Bind the hostile cleanup capacity pin to the measured shared-identity layout;
  complete canonical HIR, cleanup, and loan proof bytes remain unchanged.

- Refresh target and patch-evidence KATs after full native-byte reconstruction
  reproduces all 18 prior pins from only the result initialization relocation
  and authenticated digest consequences; retain validator and replay hostiles.

- Refresh freestanding artifact pins after byte-for-byte proof of the native
  result initialization relocation and its authenticated envelope consequences.

- Preserve exact cold/warm workspace graph accounting by measuring only loan
  capacities that can shrink on HIR clone. Keep immutable identity storage and
  full census scratch charged by their owning retention/replay paths; invalidate
  prior cache capacity metadata with checked-HIR compatibility v6.

- Reduce validation allocation by borrowing byte-operation signatures and
  retained zero-argument nominal facts, constructing byte-slot labels only
  when retained, and omitting loan census scratch for HIR-covered identities.
  Preserve conservative fallback accounting and the 64 MiB builder ceiling;
  add exact-budget, refusal, hostile-HIR and backend-composition regressions.
- Explain unknown import identities with a bounded query for the validated
  provider. Bind the CLI library index assertion to its complete catalog rows.

- Share immutable expression-identity backing storage across HIR clones while
  preserving byte equality, ordering, hashing, cache encoding and graph output.
  Account retained loan-proof vector capacities and each distinct backing
  allocation, including headers and the temporary charged inventory. Keep all
  CFG points, edges, independent replay and builder limits; the current-head
  executable gate remains pending.

- Avoid allocating unused cross-file edge paths for import-free modules, borrow
  retained HIR expression identities and lazily derive authored type-site IDs.
  Preserve complete edge replay, capability facts, canonical bytes and every
  builder pre-charge/limit; add zero-allocation and forged-edge regressions plus
  the unchanged-budget standard pattern workspace gate.

- Compare canonical HIR expression and value identities directly with their
  retained bytes during validation, removing temporary comparison strings.
  Preserve exact length-delimited identities, cached-hash checks, forged-HIR
  rejection, source-graph bytes and every builder limit/pre-charge. Add encoder
  differential, UTF-8, collision, budget and frozen-graph regressions.

- Add an opt-in bounded native target for Project v26/v28 source-command
  tests. The route compiles the authenticated test-module roots, enforces
  per-root timeout and combined-output bounds, and reports
  `semaprax.native-test.v1`; the current-head executable gate remains pending.

- Avoid rebuilding and hashing the fixed rung-two handoff binding on every
  scalar operation. Authenticate it before immutable publication, retaining
  per-handoff execution and settlement checks and supplied-binding refusals.

- Admit authenticated full-root owned-String byte views in the additive Wasm
  Text Toolkit profile. Keep the default Web and standalone internal-String
  v1 profiles closed; exercise fused and named-view cleanup through the toolkit
  runtime.

- Add OPT-704 function identity and existing body context for the unchanged
  loan-analysis work refusal, plus a named-slice repair for loop call diagnostics.
  Preserve the selected code/message, existing blame, missing provenance and
  the million-unit guard. Focused diagnostics and boundary tests pass.

- Add OPT-702 whole-record loop renewal admission for independent named
  `Slice<u8>` and `str` input borrows. Preserve ordinary alias/escape rejection,
  exact owner transfer, and canonical cleanup history. Add source, hostile
  replay, graph, and three-backend regression witnesses. The combined focused
  verification batch and scoped clippy pass.

- Explain the native build/invoke route directly in source-command interpreter
  refusal diagnostics (issue #701). Exact G170/F102 help distinguishes source
  formatting, manifest formatting, bundled imports and native-only profiles.
  Focused diagnostic/help regressions and scoped clippy pass.

- Add explicit `fmt --manifest <semaprax.toml> [--check]` for canonical table
  layout. The mode shares complete manifest semantic validation, while ordinary
  `fmt` keeps formatting only selected `.spx` files. Eight formatter regressions, the CLI snapshot and scoped clippy pass.
- Restore internal owned-String helper admission for explicit owned-data Project entry/test closures while keeping legacy String refusals and effect/borrow exclusions.

- Add `semaprax help shapes kinds` as a complete exact selector index derived
  from the generated language-shapes companion (issue #699). The bare catalog,
  existing lookups, and guide byte limit remain pinned. Four focused CLI
  regressions and scoped clippy pass.

- Keep constructed variant tag domains complete while carrying cleanup flags
  only for reachable owned cases, including scalar yields and failed reductions.
  Match authentication still derives payload inventory from validated HIR.

- Restore the ordinary interpreter direct String signature refusal without
  excluding admitted nominal owned-data records.

- Flush generated webapp publication files through the Windows file handle
  and POSIX directories through their directory handle, retaining staged writes,
  atomic rename, restart validation, and propagated synchronization failures.

- Capture optional raw compiler-output evidence before acceptance builds, with
  fresh reproduction and immutable campaign/trial bindings for source-component
  recounting (OPT #696). Matching file contents remain a final-file proxy, not
  historical authorship. Original campaign evidence is unchanged.

- Provide an opt-in pinned, private TypeScript dependency bootstrap for future
  matched web campaigns (OPT #697), without reference application code or
  scripts. Record supplied tooling and fixed prompt bytes separately.

- Clarify that `help shapes` lists the full catalog and `help shapes function`
  narrows it to matching declaration shapes (OPT #694).

- Report generated-server permission-denied listener startup errors concisely
  with guidance to the limited schema-only offline check, while preserving
  nonzero failure and full server/browser acceptance requirements (OPT #695).

- Admit the exact Project v27 schema when authenticating pure entry/test
  execution envelopes. Preserve canonical reconstruction, digest checks and
  rejection of native-only source-command and unknown project schemas.

- Add a shared browser/API creation preflight using the compiler-derived
  partial permission predicate (OPT #687). Only definitive row denial rejects
  before payload validation; concrete authorization and principal renewal after
  body reads remain authoritative. The generated HTTP runtime regression passes.

- Add the canonical native Project v27 `stdin-stream-data` starter, with
  Scaffold Capsule v6, an immutable borrowed scalar-vector helper, and direct
  CLI/language discovery (OPT #688). Earlier capsule bytes and profile limits
  remain unchanged. Canonical replay, CLI/help fixtures, and native creation,
  checking, building, and streamed execution are verified.

- Preserve ordinary sign-in label whitespace and separate qualification
  contract metadata from the executable TeamDesk gate inventory (OPT #689).

- Accept equivalent field-labelled TeamDesk enum filters while retaining the
  legacy field-qualified clear option and rejecting unrelated `All` controls
  (OPT #691).

- Recognize unique TeamDesk Create/Edit/Delete links or buttons and restrict admitted field-label prefixes to native form controls (OPT #692).

- Add `node server.mjs --self-test-offline` generated-runtime checks for socketless agent
  environments, with bounded language help and regression guards against
  listeners, child processes and writes (OPT #693). Full server self-tests and
  independent application acceptance remain required.

- Repair TeamDesk acceptance readiness and equivalent CSV/audit representations
  (OPT #689), retaining all application obligations and case identities. Frozen
  paid results remain unchanged. Six selected gate regressions and ten hostile
  rescorer regressions pass; separately pinned reference qualification and
  full archival rescoring remain independent evidence.

- Add offline TeamDesk rescore dependency receipts and final-source component
  recounting (OPT #689, #690). Both retain original campaign accounting:
  dependency recovery is hash-bound but does not claim original-runtime
  equivalence, and component metrics remain final-file proxies rather than
  verified authorship or a ratio.

- Admit calls from bounded loop bodies to exact private helpers taking
  compiler-owned `borrow Vec<Copy scalar>` parameters (OPT #684), matching the
  existing Project v27 helper boundary. Owned/non-Copy/counterfeit Vec shapes,
  Vec results, generic aliases, effects, older profiles and public roots remain
  closed; focused verification is pending the combined source batch.

- Reduce repeated Shared Loan Plan checked work by retaining deterministic
  forward reachability within one function build and examining only outgoing
  edges of live loan nodes. The 1,000,000-unit ceiling, fail-closed boundary,
  canonical plan order, independent replay and Graph bytes remain unchanged;
  focused local proof, exact-budget replay and first-overflow checks pass.

- Add `std.data.json.scan` (OPT #680), a borrowed-byte strict whole-document
  JSON facade with bounded depth, UTF-8 and escape validation, explicit
  decoded-key duplicate policy, scalar member/array navigation, and exact
  decimal source spans. The older document and query APIs keep their existing
  behavior. Focused local interpreter/native/Core-Wasm package execution,
  ordinary-project bundling, catalog and help checks pass.

- Add same-owner byte-buffer renewal through CleanupPlan v17 and
  Graph v70. Exact `bytes_set`, `bytes_set5`, `bytes_set1_or5_from_slice`, and
  `bytes_set1_or6_or48_from_slice` assignments retain their prior cleanup
  position across conditional branches and bounded loops while v15/v16 retain
  their meanings. Focused local replay, cache, native and physical Core-Wasm
  success/failure checks pass, including same-function Vec/String composition.

- Add explicit native-only Project v28
  `source-command.resource-output.v1` (OPT #678): preserve the v26 argv/file
  provider and authority while admitting 1 MiB per-String/authenticated
  borrowed-text views, 1 MiB combined heap-staged output and bounded append.
  Shared Slice/Bytes limits and every v26 route remain frozen; focused LOCAL
  native owner checks and scoped clippy pass.
- Give the Project v26 `source-command-file-text` scaffold its own exact held
  publication authority: root `digits`, two source files, and the three common
  root files. Foreign entries still fail closed, and partial cleanup remains
  limited to held identities; focused verification is pending.
- Add compiler-owned checked `u8_from_i64` and exact `char_from_u8`
  conversions (OPT #673) across the interpreter, native C11, and scalar and
  aggregate Core Wasm. Values outside `0..=255` keep the existing checked
  conversion status; focused local cross-backend, source/graph, diagnostic and
  live-owner failure-settlement verification passes.
- Add table-only Project v27 `language-command-io.stream-data.v1`, preserving
  the exact v25 native streaming command/root ABI while admitting authenticated
  non-root helper parameters of `borrow Vec<Copy scalar>` and the existing
  private Copy-scalar surface. Keep v23-v25 frozen, retain the v25 runtime and
  quotas, and refuse owned/non-Copy/public Vec boundaries plus Web/npm targets.

- Tighten generated web protocol boundaries: entity APIs require JSON number
  tokens for integer, float and reference fields while browser forms retain
  decimal-text entry; session deletion checks identity before CSRF; sign-in
  accepts both canonical `login` and the declared login-field key. Add bounded
  explicit `webapp --title` presentation metadata. Focused generated-server
  and projection regressions are authored; verification is pending the shared
  implementation batch.

- Project row-aware write policies into conservative creation previews (OPT
  #666): current-account inputs remain exact, row inputs are unknown, and
  definite restrictions hide New without inventing a blank/default row.
  The same admitted AST supplies lazy Boolean, match, helper and contract
  semantics; the server still checks every actual write. Focused generated
  callback checks and all 912 independent reference browser/API cases pass.
- Add native-only Project v26 `source-command.v1` for ordinary source-library
  imports in argv/read-only file CLI programs (OPT #667). Preserve exact
  SourceCommand authority, checked status/cleanup and immutable publication;
  interpreter/Web/npm/Wasm refuse explicitly. Owning native import, malformed
  entry/authority, canonical projection and source-drift gates pass locally.

- Fix the TeamDesk v2 TypeScript reference's signed-i64 transport for OPT #662:
  preserve JSON number lexemes, use exact integer schema arithmetic and form
  values, and write numeric tokens through REST, audit, CSV and persistence.
  Local codec/schema, physical HTTP/restart, type-check and browser build gates
  pass; the independent full-SPEC qualification remains a separate gate.

- Add the Partial alloc `std.int.decimal` package (OPT #661): canonical
  unsigned decimal normalization, comparison, exact addition/subtraction and
  floor division, bundled dependency resolution and generated discovery.
  Checked contracts reject malformed input, unsigned underflow and zero
  divisors. The package lists interpreter/native C11, with no Core Wasm or
  primitive BigInt claim. Admit supported String-replacement graph v68 in
  Semantic Workspace preflight (OPT #664), retaining exact schema refusals.
  Focused interpreter/native and bundled Project gates pass locally. Manual
  LogLens adoption passes 148 own, 33 historical and 16 independent checks;
  its modest authored-token reduction does not establish live-agent savings.

- Fix native String condition cleanup anchors to distinguish dormant inventory
  slots from canonical runtime lifecycle references; mirror the distinction in
  aggregate Wasm and Copy-variant guards. Parameter-read success and real-owner
  parent-refusal regressions are authored for OPT #660; verification is pending.

- Record focused LOCAL source/graph/interpreter/C11 O0/O2 and physical Node
  Wasm gates for the bounded owned-String record, loop-match, String-condition
  and String-replacement slices. Preserve frozen-profile refusals and every
  prior hosted distinction. Selected collection and Toolkit evidence remains
  local; the final Native Map and Project v25 focused checks passed, with no
  browser, hosted, public-package or full-profile claim.

- Author typed Map/Set transport, removal and deterministic closed key/value
  operations, composing private Stream Text helpers and bounded record fields.
  Prelude v13 extends sorting v12; focused execution and pin regeneration await
  completion of the full OPT implementation batch.

- Author per-iteration String condition lifetimes: condition-local owners settle
  before both Boolean outcomes, failures keep their ordinary sticky status,
  and source/HIR admission rejects surrounding ownership drift before the body.
  Named reads retain their allocation-free path. Focused verification is pending.

- Author Copy-scalar `vec_sort<T>` with an allocation-free native heapsort,
  interpreter total ordering and an additive authenticated Wasm host operation;
  add unsigned UTF-8 String relational operators across source and HIR checking,
  interpreter, native and web projection. Focused regressions are authored;
  verification is deferred until the remaining OPT implementations are integrated.
- Author streaming Graph revision v2 hashing through a fixed buffer for
  ordinary AST callers, preserving canonical bytes and selected prelude contracts.
  Bounded callers keep their existing formatter-work debits and overflow path;
  byte-oracle, prelude, shadow and stale-source regressions await batch validation.

- Author General Loop Match v1: private Copy variant helper and match-result
  boundaries, ordinary checked case/wildcard/or guards, canonical temporary
  settlement before selection/fallthrough, independent replay and an explicit
  private Wasm selector. Focused all-engine/hostile verification is pending.

- Author Whole String Replacement v1 with CleanupPlan v16/Graph v68, independently
  replayed guarded old-owner release, consuming RHS calls and branch results,
  an explicit private Wasm selector and focused settlement/refusal regressions.
  Consolidated executable verification is pending.
- Add concrete Copy-scalar variant constructors within admitted loop matches,
  retaining ordinary identity/type/ownership checks and canonical cleanup.
  Author interpreter/native/Wasm settlement and refusal controls for repeated
  construction, nested String results, operand/guard failure and Vec traversal.
- Author the additive bounded monomorphic owned String record runtime lane:
  exact `own`/`borrow` parameters, results, constructors, immutable updates and
  destructuring reuse canonical String lifecycle leaves on interpreter, C11
  and aggregate Wasm. Independent source/HIR classifiers, hostile layout/HIR
  controls, source/graph round trips and allocator parity gates are authored;
  verification remains pending for the combined OPT implementation batch.
- Close the SG-01–SG-24 implementation gaps: enforce nested record invariants,
  snapshot Copy record byte arrays before later argument effects, select the
  declared source main, compose payload-free variant fields, and update owned
  byte buffers without whole-buffer copies on unshared writes. Preserve projected
  webapp postconditions; revalidate mutations after body reads; require one
  directory writer; publish rows, authentication and audit in one recoverable
  snapshot; and reject failed keys, route collisions and reserved computed names
  while preserving prototype-named fields. Retain complete broker omissions,
  parse foreign exports through their owning manifest, enforce adapter I/O
  deadlines, bind cache reuse to score thresholds, refresh timeout fallbacks,
  canonicalize Clef response identities, and discover Rust enum payloads and
  aliased module glob exports. Validate and freeze imported SDK observations,
  accept unknown compiler commit provenance in VS Code, and document retained
  Projects and selected library modules through the CLI and editor.

- Restore private semantic-cache round trips for the admitted CleanupPlan v14
  owner-admission and v15 Vec-renewal profiles, preserving closed static-token
  decoding and rejection of unknown or malformed versions.

- Repair strict lint failures in cleanup replay, native/Wasm record iterator
  helpers and workspace imports without changing verification or settlement
  behavior; retain all existing regression assertions.

- Restore bounded CLI language help without changing its topic limits; complete
  documentation metadata and navigation, and join relocated source into the
  contracts that audit it. Make the stream-text native probe completion marker
  independent of host newline translation.

- GAP integer and data corrections: exact named `u8`/`i32` widening and checked
  integer conversions execute on the interpreter, C11 and Core Wasm; byte helpers
  use constant work, and equal-width `i32`/`u8` remainder preserves normalized
  failures. Typed Err reconstruction permits changing an owned Result’s success
  type, and exact Reader/Writer owners may renew through checked loop calls.
  The existing two-Bytes-plus-Copy record vector gains consuming iteration,
  with additive Prelude v11/Graph v67 and a distinct checked Wasm host protocol.
  Executable invariants over unsupported owned record fields fail
  before backend admission. Bundled dependency registration, bare-CR EOF line
  framing, strict padded Base64 decoding and multiline CSV record decoding gain
  focused regressions. Harness snapshots authenticate complete oracle inventory;
  repair preserves parsed contracts/effects, and context facets bind full bounded
  work and canonical digest inputs. These additions carry local evidence only.

- Complete Project v25 owned-String helper execution in ordinary, named,
  cancellable and prepared tests; add the canonical stdin-stream-text scaffold
  and a portable borrowed-slice JSON decoding query package. Focused local
  interpreter/native/Wasm, profile-refusal and failure-status checks pass.

- Author Ordinary Vec Loop Renewal v1: exact scalar same-cell updates preserve
  their cleanup position among untouched owners through independently replayed
  CleanupPlan v15 and Graph v66. Consuming iterator v12/v40 remains frozen;
  focused interpreter/native O0/O2/Wasm and hostile-proof checks pass locally.

- Author preserved canonical statement-if spelling through explicit parser
  provenance and authenticated normalized-tree formatting. Authored lets and
  explicit zero alternatives remain distinct; HIR/runtime lowering is unchanged.
  Focused source/graph/backend, formatter-accounting and cache-roundtrip checks pass locally.

- Add native Project v24 streaming commands with explicit `i64` application
  exit statuses (0–255), staged output rejection for invalid results, and
  artifact-free Wasm/npm refusal. Project v23 Bool status mapping remains
  frozen. ShiftSim qualification now selects the explicit v24 route.

- Preserve complete owned byte-variant case domains after construction and
  contextual owned variant matches through canonical formatting. Attach source
  spans to record-update, field-assignment, record-pattern and Useful Data
  function-body profile diagnostics.
- Borrowed Text Byte Access v1: add direct `str_byte_at(borrow str, usize)`
  with the existing total `Option<u8>` byte-read contract. Native and aggregate
  Wasm share byte-result lowering; borrowed input and full-width bounds remain
  checked. Focused local backend and independent verifier gates pass.

- Byte Widening v1: add exact, allocation-free `i64_from_u8` through the shared
  intrinsic signature and interpreter/native/Core Wasm lowering. The frozen
  Conversions v1 catalog remains separate; focused regressions cover all byte
  values and direct/byte-view borrowed-text reads. Focused local backend and
  independent verifier gates pass.

- Copy variant guard execution: evaluate nominal guards on the reference
  interpreter before selecting an arm, and provide the explicit additive
  `emit_copy_variant_module` String-settling Wasm profile. The older Wasm entry
  keeps its nominal refusal. Canonical block cleanup now includes scalar String
  operands in empty/nested branches; fixed-array byte reads use private frame
  memory in the additive profile.

- Copy variant guards: exact cases with scalar payloads admit ownership-neutral
  scalar-operator guards. Guards evaluate after case binding, false guards fall
  through, and exhaustive unguarded coverage remains required. The focused
  interpreter/native/Wasm settlement and hostile-HIR gate is
  `tests/language/guarded_copy_variants.rs`; broader #589 guard work stays open.

- Native String scope completion: settle scalar branch operand temporaries
  before loop-cell reuse, using the exact block region normal finalizers after
  owned result handoff. Focused Find/Len regressions cover nested branches,
  guard failure, and allocation balance.

- Source checking: avoid environment copies and identity ownership joins for
  empty `if` branches containing integer or boolean literals. Condition and
  both branch values still receive ordinary type checks; statementful and
  ownership-changing branches retain the full join.

- Native String joins: replay the exact nested `if`-to-variant-match handoff,
  preserving branch transfers and ownership liveness. Focused branch-result
  regressions cover statementful tails and nested scalar/variant match arms.

- Loop input: repeated `args_len`/`arg_utf8`, named immutable String/`str`
  views and user helpers with declared argument, filesystem or environment
  read effects are admitted in loop bodies. Existing capability checks,
  borrowed-owner liveness and the one-read stdin restriction remain in force.
  Focused source/HIR and native allocation-settlement evidence is owned by
  `tests/language/loop_command_input_v1.rs`.

- Repair the unbuilt conversion and loop-body changes with focused interpreter,
  native C allocation-accounting, and Wasm evidence. Loop bodies admit user
  String calls and Copy scalar or Copy-payload variant matches; scalar guards
  and String results settle on success and failure. Local Copy-scalar variants
  share admission between loop validation and the interpreter. The diagnostic
  help shortlist stays within 256 bytes while exact lookups and the complete
  mistakes table retain new conversion, map, and String-record advice. See
  [Owned String Loops v2](docs/OWNED-STRING-LOOPS-V2.md).

- Conversions v1: `f64_from_i64` (nearest, ties to even), `i64_from_f64` (truncates toward zero), `usize_from_i64`, and `i64_from_usize` convert between scalar types, and `string_from_str(s: borrow str) -> string` copies a borrowed view, so an `arg_utf8` argument can be compared with `==` (`let raw = arg_utf8(1usize); let flag = string_from_str(raw); flag == "--top"`). A value the target cannot hold fails with the checked `semaprax.convert.v1` status (code 1 out of range, code 2 NaN), which `semaprax run` reports as one stderr line. The conversions are compiler-owned and reserved (`SPX-S113`), admitted in loop conditions and bodies, and the `x as T` parse hint and the card's diagnostic index now name them. The interpreter and native C (allocation-counted, zero leaks on every exit) agree on one corpus (`tests/language/conversions.rs`); Core Wasm refuses the family with `SPX-W116`. See [Language Ergonomics v1](docs/LANGUAGE-ERGONOMICS-V1.md#conversions-v1).
- Statement `if`: `if c { x = x + 1; }`, with optional `else if` and `else` branches whose blocks may end without a value, is admitted in statement position, including `while` and `for` bodies. It is parse-level sugar for the value discard agents spelled by hand: a valueless branch yields `0`, a missing `else` is `else { 0 }`, and the result binds to the next unused `_if<n>` name (a block admits no shadowing), so `fmt` writes `let _if1 = if c { x = x + 1; 0 } else { 0 };` and the AST, graph, cleanup plans, both verifiers, and every backend are those of the value form. A value `if` followed by `}`, `;`, or an operator parses exactly as before, and a statement `if` that ends a block needing a value keeps the value grammar's `SPX-P104`/`SPX-P203` diagnostics. The interpreter, native C, and Core Wasm agree on one corpus (`tests/language/statement_if.rs`). See [Language Ergonomics v1](docs/LANGUAGE-ERGONOMICS-V1.md).
- Strings selected by `if` and `match` now run everywhere they check. `let c = if n > 0 { a } else { b };` over owned `string` bindings aborted natively with an "owned plan transfer liveness" invariant failure, and `string_concat(if c { "a" } else { "b" }, "x")` failed natively with `SPX-B104`: the native `if` now joins a `string` result in its cleanup-plan slot, as it already did for Bytes. A `match` whose arms yield `string` over a payload-free variant (`match severity { Severity::Critical {} => "page", _ => "watch", }`) was refused with internal `SPX-H006` ("owning variant match result is not an exact generic template") on every backend; the cleanup plan now joins each reached arm's string into the match slot whatever the scrutinee. The reference interpreter admits user functions that take or return `string`, which `semaprax run` had refused with `SPX-F102 (unsupported_callee)`. A function that takes or returns a record with a `string` field, which no backend lays out, is now refused with the stable `SPX-T309` and a fix naming a separate `string` parameter, instead of internal `SPX-H006` ("invalid ownership mode"); the declaration and its invariants stay admitted for schema projections. The interpreter also runs a `match` over a Copy variant that ends in `_`, and Copy variant parameters, which it had refused. The interpreter, native C under the allocation-counting harness, and the String-settling Wasm profile agree on one corpus (`tests/language/string_branch_results.rs`).
- String Collections v1: `Map<string, i64>` keeps per-key counts and sums in ascending bytewise key order. `let mut counts = map_new(capacity);` creates one (at most 65,536 entries), `counts = map_add(counts, key, n);` inserts or adds (checked) and `counts = map_set(counts, key, n);` replaces, as same-owner updates admitted in loop bodies and branches; `map_get_or`, `map_has`, `map_len`, `map_key_at`, and `map_value_at` read it without consuming it, and `string_compare` orders strings bytewise (-1/0/1). A full map, an index past `map_len`, a capacity above the bound, and an overflowing add are the checked `semaprax.map.v1` status. A map is a local binding: parameters, fields, copies, branch results, and temporaries are `SPX-T275`; other instantiations are `SPX-T274`. Interpreter and native C agree under an allocation-counting harness; Core Wasm refuses the family with `SPX-W116`. A LogLens command-line report (distinct clients, top paths, per-hour counts) now runs in a single `.spx` file. See [String Collections v1](docs/STRING-COLLECTIONS-V1.md).
- Cleanup replay no longer counts independent decisions against `SPX-H006`. A function with many independent `if`s, lazy `&&`/`||` operands, or `match`es (a field parser, a dense predicate, a variant-equality `main`) multiplied its terminal paths past the 65,536-path ceiling and was refused even when no decision touched an owned value. Above 4,096 paths, replay now compares the typed-HIR skeleton with the cleanup plan factored by cleanup state: the HIR walk merges paths with identical cleanup state, and both sides are compared as acyclic automata by hash-consed weighted subset construction, which proves the same path multiset without enumerating it. Its cost follows distinct cleanup states, all of it charged to the unchanged program-wide work budget. Plans, graphs, and backend output are unchanged, and the plan side is still read from the plan alone. Test builds compare the factored and enumerated verdicts on every function small enough to enumerate. A corpus of formerly refused functions (thirty statement `if`s, twenty `&&` chains, a twenty-four-term sum, twelve-field `string_byte_at` and `byte_get` parsers, sixteen variant comparisons, nested `while` and block decisions, a live String across twenty decisions, and a selected overflow failure) returns the same result on the interpreter, native C, and Core Wasm. See [RFC 0003](docs/RFC-0003-CLEANUP-AND-RESOURCE-ABI.md#factored-skeleton-comparison).
- Text Toolkit v1 and command-line programs: `string_slice`, `string_find`, `string_to_i64` (returns `Option<i64>`, matchable in loop bodies like `byte_get`), `string_trim`, and `string_byte_at` cut and parse text by byte offsets, with out-of-range offsets and split characters as the checked `semaprax.text.v1` status; `file_read_text(path)` reads one UTF-8 file of at most 64 KiB under `fs.read`. A single file that permits `fs.read`, `process.args.read`, or `process.stderr.write` is a command-line program: `semaprax run tool.spx -- args` (and `--native`, and `build --target native`) passes argv to `args_len`/`arg_utf8`, publishes stdout and stderr after `main` returns, reads files only below the current directory, and exits with `main`'s result; a checked failure prints one stderr line and exits 1. Interpreter and native C agree under an allocation-counting harness; Core Wasm refuses the family with `SPX-W116`. Native loop bodies now release String temporaries nested in a statement (`total = total + string_len("ab");` in a `while` body aborted on its second iteration). See [Text Toolkit v1](docs/TEXT-TOOLKIT-V1.md).
- Owned String Loops v1: a program can now build text in a loop. `text = string_concat(text, more);` on a `let mut` string moves the old text into the call and stores the result back (no clone, no release at the assignment), in straight-line code, loop bodies, and `if` branches. String literals and `string_*` calls are admitted in `while` and `for` bodies, and each iteration releases its own strings. The interpreter, native C (allocation-counted, including failures inside the loop), and the String-settling Wasm profile agree. Whole string replacement stays `SPX-U105`, and a string value in a loop condition is `SPX-T252` with a fix hint. See [Owned String Loops v1](docs/OWNED-STRING-LOOPS-V1.md).
- Syntax habits that cost agents an edit-check turn are now admitted as sugar with unchanged canonical form: `else if` (formatted as `else { if … }`) and payload-free cases without `{}` (`Role::Admin`, formatted as `Role::Admin {}`). The web card documents the first-run account flow and the 8-byte password minimum, and the generated self-test prints one evidence line per role. On the 20-entity benchmark, SEMAPRAX now needs a median 3.0x less net task input than TypeScript/React (best run 6.1x), at about 2.2x lower estimated cost net of the fixed harness context.
- Record Invariants v1, variant equality, and case or-patterns. `requires` lines after a record's closing brace state invariants over its fields by bare name; every record literal, `with` update, and field assignment re-checks them, and a false one is the ordinary contract failure of a failing precondition on the interpreter, native C, and Wasm (`SPX-C101`..`SPX-C103` for non-bool, effectful, and generic-record clauses). `semaprax doc` lists them, the graph carries them as the `#invariant` function's preconditions, and `semaprax webapp` turns them into entity rules. `==`/`!=` now compare two values of one payload-free, non-generic variant (`status == Status::Done {}`); other variants stay `SPX-T207` with a `match` hint. `Status::Todo {} | Status::Doing {} => …` joins payload-free cases in one arm of a plain `match`, with exhaustiveness accounting; payload, foreign, duplicate, mixed, and guarded alternatives keep stable diagnostics, and `SPX-T254` now names the admitted forms. See [Record Invariants v1](docs/RECORD-INVARIANTS-V1.md).
- Web Application Projection v1 and v2: `semaprax webapp <file> -o out` turns a module's records, payload-free variants, and convention-named pure functions into a dependency-free full-stack web app: a JSON REST API, atomic file persistence, the same validation in browser and server from `requires` clauses, computed fields with checked BigInt `i64` semantics, and a browser UI. v2 adds unique keys (`<entity>_key`), workflows (`<entity>_<field>_step`), rollups (`count_<child>`/`sum_<child>_<field>` parameters), accounts (`<entity>_account`) with scrypt-hashed passwords and HttpOnly sessions, role- and row-level permissions (`can_read`/`can_write` with `me`/`my_<field>`), an audit history, and CSV export. `node out/server.mjs --self-test` checks every feature for every entity and role and prints the observed evidence. `semaprax help language web` teaches it in about 1,100 tokens. `SPX-WA102`..`SPX-WA105` fail closed. A declaration's last field or case may now omit its `,`. Benchmarks: building the 10-entity v1 app costs TypeScript/React 2.1x the tokens of SEMAPRAX (batched model; 2.4x net in live runs; SEMAPRAX was 3-7x worse before). The 20-entity v2 app costs TypeScript 4.4x the net task input and 4.3x the wall time of SEMAPRAX in live agent runs. Static models give 1.8-2.7x, bounded by the spec's own information content.
- MA-01..MA-10: harden the harness host and bridge from the 2026-10-05 main audit. A cached adapter handle is reused only under an identical launch identity (isolation, grant, executables, roots, forwarded env); errors and invalid payloads after dispatch keep side-effecting steps uncertain; cancellation and the original deadline are checked before dispatch and bound the handshake. Side-effect journals take an exclusive per-lineage `flock` for claim and `begin`; omitted `step` gets a unique per-session identity returned in the response; malformed `isolation`/`deadline_ms`/`step` are refused before any work; terminal journal write failures surface as `durable: false` with `journal_error`. Bridge and skills MCP stdio use one bounded frame reader (oversize closes the session), every transport-error exit cancels live work before joining workers, and long-lived bridge sessions drive the idle reaper.
- LAW-16: add a supplemental matched multi-module Boolean provider-edit capture: 30 ordinary-check processes per Bend/SEMAPRAX before and after state, separate Bend verdict-kernel outcomes, and unchanged-law signature-change refusals on both sides. Retain raw streams and exact tool/source pins without promoting the original checked-`u32` incremental cell or claiming cache reuse or a timing winner.
- TC-00..TC-12 (in progress): minimise billed cost per accepted harness task. TC-08: opt-in `[skills] cost_profile = "compact"` renders fixed invocations without the skill catalog, skips shipped-default skills on tiny structured tasks, honours `host_delivered` skills without duplicate copies, and reports snapshot, rendered and provider-token sizes separately (`semaprax.skill-cost-report/v1`); the default is unchanged until TC-12 qualifies a profile. TC-09: a supplied or completed same-lineage proposal is validated and used before routing (zero router/model calls, no new reservation), and a tampered or missing done artifact is refused rather than replayed. TC-11: tokenizers are host-approved with a fingerprint, tasks may name approved tokenizers, and identical counts are memoised per run. TC-05: an opt-in initial context target (`[budget] context_target_bytes`) with provenance-safe span deduplication, bounded justified escalation and a chosen/omitted report. TC-06: repair feedback reaching the model is a deterministic, size-bounded projection: the current failure verbatim, earlier failures compacted by digest, accounting kept in the report, and scratch-candidate failures labelled as such. TC-07: an opt-in Caveman 3.1.0 `command.view` adapter (loopback middleware-protocol client, mandatory runtime credential, raw fallback, upstream originals revoked after use). It is verified against a real Caveman v3.1.0 runtime (`caveman-proxy`, built from GitHub tag v3.1.0 / 8af1f1b9; npm has no 3.1.0) with a recorded, replayed exchange. It is not qualified or promoted. TC-01: provider usage receipts (cache reads/writes, reasoning subset, streaming merge) are normalized per protocol and carried through the real workflow with provider-reported and price-book-estimated cost kept apart; unknown stays unknown. TC-02: the accepted output reservation is sent as `max_output_tokens`, opt-in per-shape tiers and strict mode refuse unenforceable caps before dispatch, and truncated output is refused rather than applied. TC-04: an opt-in `ordered-v1` prompt renderer puts stable host and task content ahead of the per-attempt suffix. It binds a prefix identity and offers declared-cache models a closed `segments` boundary. The default rendering is unchanged. TC-12: an offline cost-profile qualification path. `bench app run --profile-arms --max-usd` runs the arms against a mandatory spend cap, and `bench app qualify` applies a predeclared criterion where unknown cost or no accepted tasks is never zero. A capped paid haiku-4-5 qualification (USD 3.10 of USD 5) found at most about 1% lower cost per accepted task, short of the 10% gate, so defaults are unchanged; `--production-adapter` runs the arms through a real adopted `model.generate` provider, and tiers, feedback allowance and ordered rendering are applied on the wire. TC-03: one durable task spend budget. Router and generator dispatches are reserved and journaled before they are sent and settled from receipts. Uncertain cost stays reserved, resume restores spend and fails closed on contradictory accounting, and the session or task token limit now admits each next request. Opt-in `[budget] strict_monetary`, `task_max_cost_micros`, `task_max_tokens` and `gateway_max_retries` add monetary caps. TC-10: opt-in cost-aware routing (`[routing] cost_aware`, `[routing.ladder.<family>]`) chooses by qualified total cost per accepted task from existing evidence. It never treats an unknown price or zero acceptances as cheap, and escalates at most a bounded number of rungs after classified terminal failures (never after an uncertain request, an authorization refusal or a missing dependency).
- HN-00..HN-19: turn the harness into a maintained, skill-native development product. `harness run` honours explicit change/plan tasks on healthy projects and runs bounded compiler-feedback repair sessions (`harness apply` is the separate application step); every model request is budgeted over its exact serialized text with named tokenizers. Official Ponytail v4.10.3 and Caveman v3.1.0 ship embedded with task-aware, per-session activation, kept current by `harness updates`, bound by artifact identity v2, and exposed through the bridge/MCP (real Claude Code and opencode sessions). `harness setup` adopts existing RTK/Graft/Graphify from bundled adapters; Graft 0.21.1 and Graphify 0.9.75 are qualified with user-index adoption; RTK views feed the repair loop; retrieval follows the task; routing has evidence gates (no-go: rules stay default); bridge cancellation is real; a gated WikiSkill experiment ran. A USD 10.52 haiku benchmark found no qualifying lift, so defaults are unchanged.

- HP-00..HP-17: add the development harness provider host (`crates/semaprax-harness`, private `semaprax-full harness`). Typed `semaprax.harness-provider.v1` capability contracts, per-project `semaprax.harness.toml`/frozen lock with explicit trust, a bounded stdio adapter host, a compiler-assisted workflow, native-first context, authoritative command results with compressible views, policy-first decision routing bridged to `ProviderPolicy`, local endpoint adoption over the existing Responses adapter, a lazy skill catalog, a Claude Code hook bridge, observation attribution, an adapter SDK and conformance kit, and real Graft/Graphify/RTK/Laya adapters. Evidence is local (macOS aarch64); Graphify and learned routing stay opt-in. The compiled `semaprax.plugin-manifest.v1` is unchanged.

- Complete the LAW16 proof/verdict cache evidence with 30 paired guest file-page-cache observations for pinned Bend `--verdict` on x86/Rosetta and the source-derived SMT obligation checked directly by native ARM64 Z3. Retain separate 30-run host source-to-SMT rendering samples, raw outputs, source and tool pins, and offline review. The two guest profiles use different architectures and have no cross-route timing comparison; the ARM route does not claim SEMAPRAX project-proof execution or native compilation.
- Retain a LAW16 Linux/Rosetta guest file-page-cache pilot and thirty cold/warm
  pairs for ordinary Bend and SEMAPRAX checking. Exact `mincore` observations
  qualify each guest reset; raw samples, runtime pins, provisioning, failures,
  and cleanup remain reviewable offline. Host/Rosetta caches and formal-proof
  routes remain outside this profile; AC5 and issue #392 stay open.

Project log follows a compact [Keep a Changelog](https://keepachangelog.com/)
format: `Unreleased` then release buckets, grouped by impact.

> For full historical detail of every entry, refer to
> [docs/CHANGELOG-ARCHIVE.md](docs/CHANGELOG-ARCHIVE.md).

## Unreleased

- Source-only #836 adds consuming `vec_update_field<Row>(rows,index,value,"field")`
  for exact Copy scalar slots of invariant-free flat owned-leaf records, with
  independent source/HIR/graph/cache checks, ordinary sticky preflight cleanup,
  interpreter/native/Wasm paths, typed ShiftSim Worker adoption and an unrelated
  inventory example. Owning gates remain pending; no efficiency result is claimed.

- Source correction for #780: ordinary and retained loan candidate discovery use the paid contextual byte slot before plan selection; preserve complete strict v1 candidate controls, typed child-ledger refusal, external setup observations and unreachable-fixture diagnostics. Executable qualification remains pending.

- Source-only nested record-pattern validation now streams exact binding paths
  from its existing depth-first continuation indices, removing owned root/field/
  record labels without another directory or quota. The complete old receiver
  remains saved for both full main oracles; Copy/Own/Borrow diagnostic, scope,
  decimal/depth and actual complete-drop controls are authored but unexecuted.

- Source-only HIR expected child labels now borrow authenticated parent text and
  stream static suffixes/indices into exact identity comparison. Saved full
  owned iterative and recursive oracles, frame bounds and forecasts remain;
  new byte/debit/allocation/hostile parity controls are authored but unexecuted.

- Compare complete canonical loan plans during their existing independent build,
  retaining an exact-program deferred mismatch for the original final validation
  boundary. Public standalone validation and diagnostic priority remain intact;
  owning qualification is pending.
- Add explicit named `string_take` owner transfer while preserving cloning
  reads, canonical argument staging, source move checks and backend forwarding.
  Owning qualification of this consolidated batch remains pending.
- Fund caller-owned canonical loan lookup storage before growth, borrow current
  identity keys, and reuse inserted declaration identities and closed Vec/Box
  compiler constants. Initial dynamic identity and loan-builder funding remain
  separate open work; no compiler budget or forecast is increased.
- Scope diagnostic attribution to one invocation and initialize exact byte-array
  literals directly in their binding slots. Preserve assignment/block-result
  copies and the fixed-array loop refusal, with repeated-call reinitialization
  controls. Owning qualification remains pending.

- Optimize changed HIR scope publications by cloning only changed/new bindings,
  preserving exact nested state and saved full-map publication controls.

- Author public `std.pattern` acceptance gates for #706: four compile-once fixtures independently exhaust ASCII bytes in header/KV key and value positions, plus four 8192-byte valid/nonmatching records under the unchanged 1,000,000-step interpreter default. The same authenticated project snapshot supplies native `-O0`/`-O2` capture results, four-invocation physical settlement and repeated Core Wasm settlement with adjacent arena refusal. These gates are unexecuted; the full issue, long-input usefulness and performance claims remain pending.

- Add phase-owned borrowed function and exact expression-ID directories to byte
  helper ModuleIndex queries (#738), retaining independent unseen-target proof,
  original census order and pointer authority. Fixed-pass radix work avoids
  allocator-address-dependent refusal; constructor-only textual ID discovery
  retains the first linear winner with actual byte and merge-copy debits. Sparse-module parity, logarithmic
  zero-backing queries, duplicate-ID and exact/one-short controls are authored;
  execution qualification remains pending.

- Retain one callee inventory and cumulative replay work ledger across captured primitive lexical module members; reconstruct each function lease independently. Executable qualification pending.

- Factor ShiftSim Copy-state scans and metric decisions into checked helpers, retaining the original semantic path-budget refusal and all 15 wire cases; qualification pending.
- Precharge geometric selected-replay FIFO frontier growth in full before allocation, preserving wrapped order, sticky refusal and the ordinary route; actual-layout regression definitions await qualification.

- Correct Catalog sorted-owner names, preserve canonical prefixed codec-plan digests, and reuse the canonical command manifest for the full 264-value UTF-8 oracle. Source-only Bytes writer imports independently authenticate their current nonallocating provider before forwarding an owner; public export profiles are unchanged.

- Generated identifier-view JSON encoders renew one String prefix through ordinary consuming append, avoiding scope-long immutable prefix owners without changing wire bytes or limits. The codec-plan regression now authenticates unchanged dependency bytes and SHA-256 separately from canonical generated members, and checks canonical idempotence for every candidate.


- Authored finite owned-iterator Bytes scratch capacity replay (OPT741): exact immutable Vec constructor provenance, cumulative allocation bounds and selective Graph v78; owning execution remains pending.

- Preserve authored JSON codec names and stable IDs containing template-marker
  spellings through one-pass expansion. Added generator and owning Project
  regressions for exact identities, policy replay and detached nested owners;
  executable qualification remains pending.

- Add a source-only stream UTF-8 owned request selector that requires the original stdin permit and reuses the unchanged incremental grammar normalizer, with native composition regressions for empty first arrays, Unicode/NUL and large legal whitespace; execution gates remain pending.

- Add source implementation and owning regressions for opt-in bounded UTF-8 owned request codecs, with distinct Unicode scalar decoding, empty/repeated value admission and exact escaped-output preflight. Existing identifier selectors remain separate; execution and the full-bound three-backend gate are pending.
- Refresh both semantic-change integration receipt KATs after complete historical/current byte proofs; retain exact replay, fixed-point accounting, shared locks, and no-write assertions.

- Generated webapp self-tests stop their child through private parent IPC so Windows
  releases the writer claim before restart; forced-crash recovery stays explicit.
  Node preload paths are converted to file URLs on every host.

- Authored webapp v3 sign-in limits, session-bound CSRF, explicit field migrations
  and pairwise candidate constraints (#607); focused verification pending.

- Add Project v25 `language-command-io.stream-text.v1`: existing streaming
  input and i64 process result with length-delimited native text/local maps and
  private owned String helper boundaries. Focused native O0/O2, manifest,
  boundary/refusal, allocation and provider-settlement checks pass locally.
  Anchor optional native stream helpers so valid operation subsets build under
  `-Werror`.

- Admit `string_len(namedString)` in while conditions without cloning the owner, preserving fuel and cleanup across interpreter, native C11, and admitted Core Wasm profiles. Allocating String conditions remain outside this narrow profile.

## 0.9.0 — 2026-10-06

- Installation: one-command per-user installers. `install.sh` (macOS and
  GNU/Linux) and `install.ps1` (Windows PowerShell 5.1 and 7) resolve a
  release once, download only the selected archive and its verification
  material, check it against `SHA256SUMS` and the release manifest, verify
  the publisher attestation with `gh attestation verify` when available
  (reported separately from checksum-only), smoke the staged binary, then
  activate atomically with a receipt, version pinning, upgrade, downgrade
  and receipt-scoped uninstall (`docs/INSTALLER-V1.md`; #552, #553).
- Releases: five native targets (`aarch64-unknown-linux-gnu` and
  `x86_64-apple-darwin` join the existing three). Linux archives are built in
  an `ubuntu:22.04` container and rejected above `GLIBC_2.35`, macOS
  deployment targets are pinned and checked, and every archive records its
  runtime requirements (#555, #560). Installers are explicit release assets
  in `SHA256SUMS` and the manifest's new optional `installers` inventory, and
  `doctor verify-release` re-hashes them.
- Releases are published only after every target's exact attested archive
  passes the installer journey (fresh prefix with a space, beginner
  project printing 42, daemon handshake, reinstall, damaged-archive control,
  uninstall) on its native host, Linux inside the glibc 2.35 baseline; the
  published `SHA256SUMS` and manifest must equal the tested candidate. The
  provisioned archive harness matches the current starter contract (#556).
- Release pages lead with an install table and the next command; the
  changelog is collapsed. Archive `README.md` files are rendered per
  platform with tag-pinned links and the first-project journey (#554).
- The handbook install page is the prebuilt-first beginner guide, with
  selected-archive checksums, PATH setup and a checkout-free first project;
  `release-reconcile.py` checks install claims against
  `packaging/channels.json` (#551). Homebrew: `brew install
  wavect/tap/semaprax` (Apple Silicon; #557). WinGet manifests are generated
  from release metadata (#558).
- VS Code: **SEMAPRAX: Configure Compiler** and a compiler status item
  select, probe and repair the compiler without editing settings JSON
  (#559); hot-reload stdin failures end the session cleanly (#571) and
  stdout is framed as LF-delimited bytes with strict UTF-8 (#572).
- Fixed: native code keeps an earlier operand's read of a `let mut` Copy
  value when a later operand assigns it (#561).
- Harness fixes: update-state writers are serialized so a stale check cannot
  erase a revocation (#563); strict update ranges with zero-major caret
  rules (#575); terminal Python adapter cancellation and a conformance suite
  that enforces it (#564); bounded bridge backpressure (#565); idle protocol
  violations stay quarantined (#566); strict chunked HTTP framing (#570);
  qualified evidence before the cost ladder narrows the model pool (#569);
  budget-fitted Graft envelopes (#573); request-scoped Graphify results (#574).
- The `SPX-U101` parameter hint no longer suggests `let mut value = value;`,
  which shadowed the parameter and failed with `SPX-T209`; it names a new
  local. New help for `mut` parameters (`SPX-U103`), a `-> str` result
  (`SPX-O116`), and methods called on scalars.
- Type-mismatch help: `string_concat("n=", 5)` names `string_from_i64`,
  `SPX-T207` names both operand types (and the literal suffix when one side
  is a literal), an `i64` passed to a narrower parameter names the suffix,
  `format!`/`println!` explain there are no macros, and reusing a moved
  `string` or `Bytes` (`SPX-O101`) names the borrow or copy route.
- More one-step fixes for agents. An unknown function that a listed project
  module declares gets the exact `use function @id("…") from … as …;` line,
  and a standard-library name gets its signature plus the exact dependency
  and `use` lines (an exact library name now outranks a near local spelling,
  so `min` no longer suggests `main`). New hints for `to_string`, `assert`,
  `if let`, `0..=5` patterns, `i++`/`i--`, and a missing comma between match
  arms; an interpreter admission refusal (`SPX-F102`) names `run --native`.
- Cut edit-check round trips for agents writing SEMAPRAX. New `help:` fixes for
  `c ? a : b`, `break`/`continue`, `as` casts, `and`/`or`, `|x|` closures,
  `use std::…`, `println(…);`, `[1, 2, 3]`, `Circle(i64)`, string `+` (`SPX-T250`),
  shadowing (`SPX-T209`), unsuffixed narrow literals and foreign type names in
  `let` (`SPX-T232`), `main -> bool` (`SPX-T104`), `?` outside a
  `Result` function (`SPX-T218`), a `let mut` `for` source (`SPX-T284`), an
  empty `for` body, and missing `permit`/`uses` (`SPX-E101`, `SPX-E102`, now
  naming both edits). View hints no longer suggest the rejected nested
  `str_as_bytes(string_as_str(x))`. Single-file `run` falls back to `fn main`
  under any `@id` and names runtime statuses (`… (division by zero)`); bare
  `semaprax help diagnostic` lists the indexed codes instead of failing. The quick reference gains a checked `lists` topic for
  `Vec<T>`, recommends one `fmt && run` call with plain output, and drops a
  stale row; the scaffolded `AGENTS.md` points agents at one language topic
  instead of the whole 33 KB card.
- MR-00..MR-15: model routing and runtime choice over pluggable decision
  adapters. `decision.evaluate` v2/v3 with disclosure, score semantics and
  call identity (MR-01..MR-03, MR-15); one shared decision core
  (`semaprax::model_routing`, `semaprax-decision-core`, MR-07); Jev, Laya,
  Mini Jev, hosted Clef/Clef-Flash and local Clef adapters plus a copyable
  SDK starter (MR-04..MR-06, MR-15); harness phase role routing and session
  decision reuse (MR-08, MR-12); runtime routing over approved deployment
  profiles with turn re-routing, handoff and delegation (MR-09, MR-10);
  `choice-select/v1` typed agent and tool selection with deployment-grant and
  specialist-registry candidate sets, an authorize-stage recheck
  (`SPX-HPJ026`) and two runnable examples (`examples/support-routing-project`,
  `examples/tool-choice-project`, MR-11); matched routing evidence
  (`bench routing-matrix`, MR-13: not evaluated, rules stay active); and
  routing setup, explainability and end-to-end examples (MR-14):
  `harness status --routing` profiles with a non-billable `--check` and an
  announced, metered `--probe`, `route.explain` in reports, parent-model
  ownership in the bridge handshake, service upstreams that adopt and trust
  from the checkout, an end-to-end routing CI lane and a dated current support
  matrix. No learned decision adapter is live-tested on this host.
- MF-01..MF-06, MC-01..MC-06: harden Graft/Graphify cache adoption.
- Resolve the conformance fixture's Node interpreter to an absolute host path
  on Unix CI, and refresh the pinned agent skill bundle after the diagnostic
  inventory changed.
- Align Windows standalone-lockfile dependency prefetch with the same harness
  exclusion used by its test shard, so the offline lockfile gate sees every
  required package.
- Keep CI workflow contract checks aligned with the Windows harness exclusion,
  and give the local TLS provider enough time to accept and handshake on busy
  runners while retaining its bounded shutdown and duplicate-delivery checks.
- Repair the 0.8.0 CI matrix: keep the Unix-only harness out of Windows Cargo
  targets, restore its strict Clippy checks, align release and workspace known
  answers with current artifacts, correct the indexed owner physical link and
  static reference-service acceptance setup, and serialize native SDK cases
  that contend when run as separate libtest threads.
- Restore CI's focused dependency and formatting checks: admit the locked
  `foldhash` Zlib license and format the harness sources checked by rustfmt.
- Complete and retain the preregistered 20-trial LAW16 Claude Boolean campaign:
  19 candidate/attack trials passed, one Bend candidate failed verdict, and
  provider-reported cost was $0.291235. The adverse result remains visible.
- Freeze a separate LAW16 Claude campaign configuration that retains failed
  trials, requests a higher per-call budget after the first CLI overrun, and
  can resume after provider rate limiting without pooling configurations.
- Retain the first preregistered LAW16 Claude campaign: four costed matched
  Boolean pairs passed, then a fifth Bend call exceeded the requested $0.03
  per-call limit before source admission. Preserve its sanitized provider and
  replay streams as an adverse incomplete campaign.
- Freeze a separate LAW16 Claude Haiku Boolean campaign plan and bounded runner
  with schema-checked edits, observed provider token/cost fields, sanitized
  events, and independent proof/attack replay.
- Retain 30 LAW16 local Boolean check/build/run phase samples per route with
  raw streams and generated-artifact digests; keep SEMAPRAX's internal build
  work combined and exclude cross-route performance claims.
- Retain a real three-module SEMAPRAX project-incremental cache control for
  LAW16, with a provider body edit, signature-change refusal, exact test-binary
  identity, and raw outputs. The matched Bend and large-project comparison
  remains open.
- Execute and retain six LAW16 unified fresh non-agent routes plus their
  failed first attempt. Fix the forwarded compiler digest prefix and support
  offline verification after copying the raw capsule, including strict RSS
  command/provenance binding. Agent evidence remains retained replay; AC1 and
  issue #392 remain partial/open.
- Preserve LAW16 unified replay command receipts and partial stdout/stderr on
  timeout or failure, including a digest inventory of earlier output. Failed
  routes remain nonresults and never become successful attack rejections.

## 0.8.0 — 2026-10-04

- Re-pin all three generated Rust ownership caller digests to the 0.8.0
  package identity after the physical moves, allocating, and nested-moves
  controls passed on the current source. Release manifests and GitHub
  publication now mark beta builds as regular releases.

- Re-pin the private Wasmtime Component runner's four independent known-answer
  sets to the 0.8.0 package identity. The owning contract test now reports
  all mismatches together; unchanged source descriptor digests stay pinned.

- LAW-16: retain pinned Bend U32 universal insertion-sort verdict/kernel
  evidence and pinned SEMAPRAX LAW15 Lean sortedness/permutation/multiplicity
  evidence over the U32 subset. A versioned guarded-i64 profile records their
  matched semantic laws, separate source identities and trust boundaries;
  bounded balance controls and source-Z3 obligations remain separate. Agent
  token events are authenticated across ten Boolean pairs, while monetary
  cost events and cache-isolated cold measurements remain unavailable. The
  original checked-u32 cells and LAW-16 closure remain open.
- RI-13: retain clean locked offline macOS arm64 and Linux x86_64 guest
  M1/M2/M3 application receipts. Each has 22 passed, 0 failed, 0 skipped
  stages/measurements and 44 verified raw streams. The linked consumer,
  copy/friction ledgers, and adverse-throughput investigations are published.
  Exact target checks refuse unsupported M1/M3 Wasm routes while the separate
  M2 scalar Project builds; generated Rust Serde/iterator adapters are not
  claimed on Wasm. Linux performance remains guest evidence.
- Repaired current-main CI regressions in command help, task-service semantic
  fixture setup, source-local manifest refusals, standalone generated-package
  lockfile classification, SMT proof guards, review digests, and Windows durable
  writer contention. The network handle-capacity test now splits its source
  across bounded helper calls while still exercising the ninth-handle refusal.
- Pinned native tool setup to the real Linux Clang image, scoped the checked-in
  macOS arm64 Regex/URL registry envelopes to their host, and checked both
  carrier-specific generated context names. Linux service packaging acceptance
  now builds and supplies a static service executable.

- Fixed the patch-receipt evidence pagination regression to exercise a
  renameable declaration in the app module; the fixture now preserves its
  cross-file identity check without attempting to rename `main`. Both renamed
  functions now carry contracts so the contract-delta page checks their IDs.
- Made the paired affine callback's flipped-source control change the paired
  return expression, so its physical consumer detects the substitution.
- Recorded the durable job writer's harness-aware child selector in the
  self-invocation inventory.
- Added the explicitly bounded SMT solver process module to the audited unsafe
  quarantine inventory, including its production and test-only Unix calls.

- RI-08: admit one synchronous parameter-rooted borrowed-text source capture.
  Source/HIR scope validation rejects aliases and escape; interpreter, native C
  and Core Wasm preserve the borrowed descriptor. The generated Rust scope
  executes the actual source closure under an RI-06 URL owner-view guard, with
  real iterator, pointer/copy controls, contract and lifetime regression gates.

- HR-07: complete the macOS arm64 cross-layer hot reload evidence at
  `9a9db7a81`. Twenty-two exact selectors and a real installed VS Code
  Extension Host gate pass; 11 raw samples distinguish save-to-ack, full
  restart, and authenticated warm restart. The observed interpreter reload is
  slower than full restart on this fixture. Other platforms, native/Wasm state
  swap, and production rollout remain unclaimed.

- RI-08: admit the narrow noncopyable `FnMutI64(i64) -> i64` receiver with the
  specified direct transition literal. Source/HIR ownership and alias refusals,
  success-only state commit, interpreter/native/Core Wasm parity, generated Rust
  FnMut consumers and failure/drop controls cover the transactional profile.

- RI-08: stage the transactional scalar mutable carrier across HIR, interpreter,
  native C, Wasm and the generated Rust owner. State commits only on checked
  success; internal guard/copy tests and Rust borrow/thread-bound negatives
  cover the carrier seams. Source and retained-HIR admission stay closed.

- RI-08: reserve distinct `FnMutI64(i64) -> i64` and `mut fn` syntax with
  canonical source preservation, private AST/HIR codec tags, exhaustive leaf
  classifications and independent source/HIR refusal. The mutable runtime
  remains unadmitted; this foundation does not claim stateful execution.

- RI-08: permit a direct mutable `i64` binding as the scalar half of the
  private retained `FnOnceI64() -> i64` profile. Construction copies the value
  into the existing environment, so later source mutation cannot alias the
  callback; interpreter, C, Core Wasm and generated Rust regressions cover the
  snapshot boundary.
- Add an RI-13 combined application measurement gate. It runs the existing
  locked M1 Regex/Url, M2 Serde record/iterator callback, and M3 local HTTP
  generated consumers in one ordered receipt; it separately records each
  Cargo build-and-run stage, M3 route timing and M3 allocator requests. The
  receipt explicitly preserves the separate source-profile boundary and does
  not claim copied bytes, a nontrivial batch result, Linux evidence, or one
  linked M1/M2/M3 Project.
- Add the LAW-16 Bend 2 benchmark harness. It pins Bend's reviewed revision,
  keeps ordinary and `--verdict` execution separate, requires separately
  declared SEMAPRAX SMT/Lean/runtime paths, and retains raw cold/warm timing
  and seeded law-gaming controls under exact local source/environment inputs.
  No Bend fixture or result is claimed: missing, drifted, timed-out, or
  semantically mismatched cells remain unavailable or failed.

- Bind six checked-`u32` semantic fixture corpora into LAW-16 benchmark
  results, including distinct acceptance and law-gaming inputs. SEMAPRAX's
  admitted scalar profile lacks `u32`, so an `i32` substitute is explicitly
  unavailable rather than represented as an equal implementation.

- RI-08: add a distinct private `FnOnceI64() -> i64` source profile for retained
  owned Bytes plus immutable i64 captures, with graph v63, versioned cleanup
  identities, and aligned interpreter, C, Core Wasm and generated Rust carriers.

- Add a bounded RI-08 same-thread foreign-registration lease to the generated
  affine FnOnce() -> i64 Rust projection. A physical Rust consumer retains
  the source-created environment inside a stateful safe registry, dispatches it
  once, and proves unregister drops an uncalled owner before later dispatch
  reaches callback state. The generated lease remains !Send and reports a
  closed registration rather than entering C after teardown. Mutable, borrowed
  and mixed source capture modes remain open.

- Save an RI-13 M1 mixed Regex/Url application. One held, canonical Project
  source authenticates four selected imports and two exports, then generates
  separate source-bound SDK carriers with distinct C owner symbols. Exact
  admission and stale-lock/source controls pass 1/1; locked offline prepare
  and a single-process Rust/C consumer pass locally on macOS arm64. The
  general Project SDK CLI, fresh-checkout/Linux run, and wider RI-13 acceptance
  remain open.

- Repair main CI's current constructor and discovery contracts, frozen help
  snapshot, source-locked coverage, standalone lockfile checks, and selected
  project fixtures. Keep native Rust interop replay on its wire ABI, scope
  real registry evidence to its recorded target, and make the local benchmark
  daemon's integrity fault deterministic. Format the new Rust and collection
  sources, export the project hot-reload lifecycle, and preserve fail-closed
  repair receipt recovery after malformed candidate observations. Restore the
  Windows checkpoint API, documentation catalog and editor activation snapshot,
  and split over-budget source modules while retaining source-locked coverage.
  Cover the checkpoint-waiting branch in the source-agent handoff test fixture.
  Keep the native Regex/Url lint allowance valid under non-Clippy builds with
  warnings denied. Canonicalize Rust formatting after the merged v0.8.0 work.
  Repair the durable-job recovery fixture's byte request and the list-proof
  fixture's borrowed evidence slices. Keep the source-local Future Project
  fixtures free of Clippy warnings without changing their runtime checks.
  Scope physical Url test helpers to their supported target and document the
  independent fixture inputs used by the guarded foreign-law repair test.
  Align verifier-hint and CLI help fixtures with admitted lists and the public
  `dev` command. Mark the list sort proof's type spelling as code so rustdoc
  accepts the module documentation with warnings denied. Catalog the RI-13
  indexed Rust Future profile and state its intended audience.

- Repair the current main CI fixtures for owned-byte Wasm imports, constructor
  schema counts, the pinned iOS action, and authenticated Everyday Agent
  examples. Regenerate the Agent skill bundle, refresh exact workspace
  artifact digests, and keep Rust modules within their size budgets. Correct
  owned-wait test fixtures and platform-specific host/compiler assertions.

- Keep explorer response branch schemas under the root document identity so
  generated clients can normalize them, and trim generated Rust source
  indentation to keep the selected client within its byte limit. Complete
  documentation metadata and catalog navigation, align VS Code syntax and
  activation checks with the manifest, fix a Unix-only proof import on
  Windows, quote container types in native interop Rustdoc, and supply the
  owned-byte interval imports in the iterator Wasm fixture.

- Scope the linked agent migration test's backend-only import to macOS and
  Linux so the Windows Clippy build has no unused import.

- **LAW-15 collection laws and unchanged-law repair:** added a saved immutable-list insertion-sort pack with source-authenticated pinned Lean sortedness, permutation and multiplicity proofs; empty-output and length-preserving duplicate mutants refuse, while separate kernel-checked counterexamples expose their lost multiplicity. Certificates bind source, proof/semantics versions, complete coverage and standard axiom reports; runtime resources and lowering remain explicit limits. The money/state gate now restores body-only no-op edits and reproves all three original clauses.

- Bind LAW-08 structural induction to checked immutable `List<i64>` append/reverse source and a separate authored Lean proof module. A selected Project/LawSet gate replays exact v9 prelude, source, proof, theorem association and strict evidence through installed Lean 4.34.0 (1/1); wrong reverse and stale proof controls refuse. The workspace linker now retains List compiler-owned declarations and operations without treating proof as lowering authority.

- Save an RI-13 M2 record/iterator Rust application. An opt-in native builder
  projects one checked record and scalar callback from the same source revision;
  the locked offline consumer parses and serializes generated Serde records and
  executes generated `Fn`/`FnMut` adapters under `std::Iterator`. Ordinary
  callback admission still refuses record declarations. This is source-local
  projection, with selected Project publication and broader RI-13 acceptance
  still open.

- Add the bounded RI-08 affine `FnOnce() -> i64` source profile: one owned Bytes capture survives helper returns, moves and single invocation across interpreter, native C and Core Wasm. A generated Rust owner executes the checked callback body with physical drop/failure controls and rustc move/Clone/Send refusals. Mutable, borrowed and foreign-retained registrations remain open.

- Canonicalize the checked money/state law-pack source, list both new example
  directories in the index, and check selected native-law modules with their
  own parser and canonical formatter in the example inventory gate.

- Remove redundant proof clones in the workspace law tests and simplify the
  remaining test-only types for the Ubuntu Clippy job.

- Record an exploratory RI-13 M3 local HTTP comparison with 90 raw samples
  each for direct Rust, equivalent handwritten checks, and generated checked
  source, plus a 30-call preparation/await attribution probe. Generated versus
  handwritten normalized throughput was 0.1242 (paired bootstrap 95%
  interval [0.1207, 0.1276]); measured registration/preparation accounted
  for 52.26% of generated total time in the separate probe. This triggers
  investigation. The tiny loopback workload cannot satisfy the nontrivial
  batch threshold; copied bytes and allocations remain unmeasured.

- Lower checked immutable `List<i64>` / `ListStep<i64>` source to native C11
  using invocation-scoped persistent cons cells. Shared tails stay immutable;
  each list has the same 8192-node success bound as the interpreter, and a
  root call releases every allocated node. Focused source/interpreter and
  real C11 O0/O2 gates passed 2/2, including shared-tail and bound controls.
  Core Wasm and List-bound Lean proof export remain open under LAW-08.

- Admit a narrow checked `List<i64>` / `ListStep<i64>` immutable source profile
  through a versioned prelude, HIR, graph and interpreter. Exact `list_nil`,
  `list_cons` and `list_uncons` calls use a persistent cons carrier. Native C
  and Core Wasm explicitly refuse until physical lowering is implemented;
  the existing LAW-08 Lean theorems remain bound to the older `Iter` source.

- Save a bounded RI-13 M3 local HTTP application with canonical checked
  Project source, a generated Rust Future registration module, pinned offline
  Cargo inputs, and an explicit Tokio/reqwest host effect. The focused Project
  gate runs real local requests for success, typed 503/parse/timeout failures,
  source postcondition failure, timeout omission, cancellation, no retry, and
  held source drift (1/1 on macOS arm64). The standalone generated-module
  application also prepared and executed under locked offline Cargo, while
  timeout-omission and stale-registration mutants produced the expected
  results. M1/M2 integration, measurements, and Linux evidence remain open
  for RI-13.
- Add a bounded HR-01 prepared-Project hot reload session with checked candidate
  admission, read-only compatibility planning, opaque generation-bound plans,
  and activation through the existing whole-state worker pivot. This is a
  partial local profile: source-Agent checkpoint handoff and complete
  compiler-derived closure/state compatibility remain open.

- Add an internal persistent `Nil`/`Cons` list value with immutable shared tails,
  a failure-before-commit 8192-element limit, and iterative cleanup. Its exact
  unit gate passed 1/1. This is a LAW-08 source-carrier prerequisite; `.spx`
  syntax, source/HIR admission, native C and Core Wasm lowering remain open.

- Close the bounded RI-09 Future bridge lifecycle with a real executor
  shutdown control. A pending local Future drops exactly once when the
  caller-owned Tokio `LocalSet` and runtime shut down, and its cloned late
  waker becomes inert. The matrix records the focused acceptance evidence
  while keeping public package and authored import expansion explicit.

- Add a LAW-15 finite request-identity Project using the existing LAW-10
  source checker. An active request 101 may retry; mismatched request 202
  reaches a terminal refusal. A body-only erased identity check fails exact
  protocol coverage with a concrete wrong-return witness; restoring the body
  repairs the unchanged law, and version-only drift invalidates cached evidence.
  The example states its finite identity domain and no external exactly-once claim.

- Render an exact Project-selected Rust async module and compile its one-shot
  source-yield callback registration in a locked local consumer. The generated
  code pins Project revision, function identity and suspension plan, and
  refuses a changed source before invoking the callback. Public SDK package
  publication and authored native Rust import syntax remain open.

- Bind the LAW-15 foreign-boundary pack to the real guarded indexed Project
  SDK harness. Saved canonical source and explicit versioned assumptions drive
  correct, bad-return and repaired native consumers under one unchanged range
  law; a zero-return control exposes that law's limited strength. The report
  walkthrough separates checked caller routing, accepted foreign assumptions
  and observed native results without claiming a foreign-body theorem. The
  exact physical gate passed 1/1; the bounded LAW-09 profile satisfies its
  stated frontier criteria, with managed ACTIVE and foreign theorem tokens
  outside its admitted route.

- Exercise the selected interpreter-backed Project async export through a
  real locked local `reqwest` request under an explicit Tokio current-thread
  runtime. The resumed checked source computes `84` from a server-returned
  `43`; a second request is cancelled after server receipt without a retry or
  rollback claim. Generated Rust SDK publication remains open.

- Start LAW-08's source-bound list induction lane: an exact pure monomorphic
  `Iter<i64>` tail match may return `Vec<i64>`, and a separate proof module
  discharges fixed append/reverse laws with real pinned Lean. A versioned
  certificate replays source, definitions, proof text and law associations;
  a wrong-reverse control refutes the selected order law and generated native
  C11 executes the admitted source at O0 and O2. Runtime capacity, call depth,
  Core Wasm execution and public aggregate ABI remain outside the theorem.

- Add an interpreter-only Project async selection with a distinct
  `rust_async` manifest inventory, Phase-A source signature, retained
  revision and explicit Web/npm/native refusals. The focused held-Project
  gate covers checked Rust Future completion, source drift and wrong export.
  Generated async SDK publication remains open.

- Bind the experimental Result callback adapter to exact selected Rust
  trait/index/package identities. A captured rustdoc fixture and a separately
  compiled safe implementation exercise retained state; unsafe, sealed,
  incomplete and mismatched trait obligations refuse. Source mutable and
  owned capture modes remain open.

- Add a canonical finite retry Project to the LAW-15 examples and bind the
  LAW-10 positive model test to its checked source. The retained negative
  mutation replays `charge, success, charge` from changed source. The example
  states the finite command-safety boundary and leaves request identity and
  external provider effects open. Add a second architecture Project whose
  unchanged `forbid_reaches` claim flips from held to a three-node violated
  path under a saved call-edge mutation. The source protocol gate passed 7/7
  and the architecture gate passed 8/8.
- Remove a redundant formatting call in the explorer Markdown export so the
  macOS Rust build passes Clippy with warnings denied.

- Keep the Native Rust interop builder's test-only seams out of production
  compilation and resolve the Clippy findings exposed by the current CI
  toolchain. Check the Windows output-limit fixture's constant bounds at
  compile time.

- Repair main CI after the toolchain action update: align the AArch64 tracking
  contract with the pinned action, remove redundant borrows in the shared Rust
  API index tests, and update the isolated Component runner and its locks to
  patched Wasmtime 48.0.5. Include the private index crate in the runner's
  exact workspace inventory. Supply the owned-byte imports in the JSON Wasm
  round-trip fixture.

- Start LAW-15 with a checked money/state example used directly by the
  finite-structured-law Z3 harness. The pack proves exact debit, credit,
  conservation, and insufficient-funds behavior on bounded checked integers;
  a no-op transfer still proves conservation but refutes both amount clauses.
  The structured proof lowering now selects same-record conditional results
  field by field under their original execution guards. The focused real-Z3
  positive/mutant selector passed 2/2.

- Add an ephemeral checked-source `Future` adapter for one direct scalar
  suspension. A caller-owned Rust Future answers the request; the interpreter
  resumes under its exact in-memory binding. Focused pending/wake/ready,
  source-refusal and cancellation-drop controls pass. Project-authenticated
  async SDK admission and external rollback remain open.

- Exercise a real locked reqwest response through the generated local Future
  bridge and an authenticated Project v8 owned-Bytes SDK. The checked `.spx`
  body transforms `hello` to `ello`; an over-limit second response cannot
  reach that body. Rust still owns the await point and source-level async
  import/export remain open.

- Add checked named Result callbacks to the experimental native Rust adapter. Real O0/O2 iterator and safe-trait consumers preserve signed domain errors, contract/semantic/panic separation and state rollback; forged-success and authored-body controls fail as intended. Source mutable/retained capture semantics remain open.

- Exercise LAW-12 `unknown`, `timeout`, `unsupported`, and `stale` diagnostic
  states through held local process fixtures in both selected-law summary and
  detail without losing strict required counts. The existing agent-workflow MCP
  adapter and token observer carry a failed law as one measured tool payload;
  successful delivery does not mark the law valid or create a reward stream.

- Make the bounded RI-09 local Rust Future handle directly awaitable by an
  explicit caller executor, including shared local waiting for cancellation.
  The locked reqwest fixture now awaits the generated bridge directly; this
  does not admit source-level Semaprax async import or reverse export.

- Finish bounded LAW-17 acceptance with an emitted-Core-Wasm Node benchmark
  for the proved add-zero rewrite, plus call-operand, numeric-kind, and stale
  artifact refusals. The installed-Z3 focused gate passed 1/1; the read-only
  reduction report continues to state that no parallel execution occurred.

- Add a fixed two-tool MCP stdio catalog over the selected-law Project agent
  route. It shares current-revision and host-policy replay with direct JSON-RPC,
  requires MCP initialization, and cannot select an executable or root from a
  request. A real installed-Z3 selector exercises failure, stale revision,
  body repair, recheck, and protected-law drift through the MCP wrapper.

- Complete the bounded RI-06 native loan acceptance with precise unchanged-import refusals for unsupported Url reference/lifetime shapes. The owning source/rejection matrix passes alongside retained real Regex/Url, callback, sanitizer and Miri evidence; broader mutable source syntax and hosted support remain outside the claim.

- Compare actual emitted Core Wasm before and after the LAW-17 proved add-zero
  candidate in the focused installed-Z3 gate. Node confirms the same return
  value and checked-overflow failure; the test moves into the owning nested
  workspace harness to keep its Rust module within the size budget.

- Complete the bounded RI-06 native loan acceptance with precise unchanged-import refusals for unsupported Url reference/lifetime shapes. The owning source/rejection matrix passes alongside retained real Regex/Url, callback, sanitizer and Miri evidence; broader mutable source syntax and hosted support remain outside the claim.

- Add an opt-in selected-law Project v7 stdio agent route using the existing
  bounded JSON-RPC codec. `law/status` returns the authenticated current
  revision and policy digests; `law/check` shares one strict-report evaluator
  with the CLI and refuses stale candidate revisions without a proof query.
  An installed Z3 gate covers direct-library use and a persistent daemon's
  edit, failure, stale request, repair, recheck, and protected-law drift. An
  MCP catalog and editor delivery remain separate work.

- Complete the main CI fixture follow-up: keep the shared index parser's Regex
  compile check available to the public crate tests, teach all three filesystem
  Wasm facades the owned-byte interval imports, refresh the calculator browser
  graph known answers against explicit import ownership metadata, and use the
  equivalent `?` propagation required by current Clippy in owned publication.
  Format the files added by the concurrent v0.8 merge so its Rust build jobs
  pass the repository format check.

- Repair the follow-up main CI failures: package Rust API index replay with the
  public compiler, add the full toolchain's direct index dependency, update the
  embedding example lockfile, and complete the Node Wasm owned-byte harness.

- Restore `main` CI after the Rust API index and Sigstore dependency updates:
  pin the local index dependency for cargo-deny, refresh the three standalone
  Cargo locks, adapt offline release verification to Sigstore 0.14, and keep
  the Unix-only owned-wait fixture out of Windows tests. Apply the repository
  formatter to the affected workspace.

- Add a read-only LAW-17 reduction-eligibility report for one exact checked
  `i64` CPU fold. It replays the bound artifact and installed identity proof,
  checks live disjoint buffers and a no-overflow nonnegative domain, and
  separates regrouping from reordering. The real-Z3 focused gate covers
  eligible and explicit overflow/alias refusals; no parallel dispatch occurs.

- Run the production Url carrier and exclusive lease under strict-provenance Miri with live backing reads, the bounded hostile-carrier corpus and owner/view cleanup. The explicit offline Rust-only gate passes with default leak checks; native C and panic quarantine remain separate evidence.

- Gate selected guarded Project SDK publication on a host-held LAW-09
  conditional strict policy. The builder replays source and law before package
  staging, checks the actual staged manifest digest before the no-clobber
  pivot, then returns the opaque publication token and conditional report.
  Mismatched policy leaves the requested output absent; core managed Workspace
  publication continues to refuse foreign strict coverage.

- Start LAW-17 with an opt-in `i64` add-zero candidate rewrite. It accepts a
  real installed-tool proof of the exact assumption-free scalar identity,
  replays its Project/LawSet binding, recognizes only an authored place plus
  literal zero, and uses ordinary candidate revalidation without source
  publication. The focused real-Z3 positive and stale-input gate passed;
  reduction eligibility and target benchmarking remain open.

- Add an explicit builder-owned LAW-09 conditional strict report for one
  protected foreign law with a unique Project source owner. It requires the
  guarded SDK publication token, exact host-pinned adapter/summary and all named
  assumptions; forged report bytes and narrower condition policies refuse.
  The ordinary core strict route stays open, and no foreign theorem is claimed.

- Add a selected-host LAW-12 CLI failure and repair workflow. The additive
  `project-proof-check --workflow` route replays the complete strict law verdict
  after protected-baseline admission, reports bounded summary/detail views,
  and checks concrete Z3 models against source semantics before labeling a
  counterexample. Values default to redacted. A real installed-Z3 CLI gate
  repairs only a function body, rechecks a new Project revision, and refuses
  a protected law edit. General agent transport and editor delivery remain open.

- Exercise the Url bridge with a fixed 1,024-case hostile-carrier corpus and null/alignment/UTF-8/width/stale-generation controls. The checked generated C and callback relay pass ASan/UBSan; a deliberate heap overflow is detected. Rust dependencies remain uninstrumented and Miri evidence is still pending.

- Retain a guarded foreign frontier in the private authenticated Project SDK
  bundle and issue an opaque conditional caller publication token only after
  exact source, summary, target, manifest and file replay. A changed summary
  refuses token creation and package drift refuses token replay. Protected and
  strict LawSet attachment is still pending.

- Add a per-owner exclusive Url callback lease to the generated Rust companion. Real C/Rust nested callbacks refuse same-owner access before target entry, allow independent receivers and restore owners after panic. Source move/drop/replacement/escape/checkpoint and cross-crate Rust lifetime controls pass; selected Semaprax &mut imports remain outside this primitive.

- Add a bounded LAW-09 source-derived caller certificate for direct public i64
  forwarding of a guarded Rust import. It replays exact Project source and
  retains every foreign assumption. A read-only published SDK verifier checks
  the manifest, listed files and guard against an independently held digest;
  forged digests and changed guard files refuse. Protected and strict LawSet
  coverage remains open pending builder-owned evidence attachment.

- Add a resealed LAW-13 trust-link negative ladder for changed source body,
  law statement, Lean statement, compiler identity, fixed profile, target,
  artifact bytes and unauthenticated adapter requests. The bounded Core Wasm
  certificate refuses each mismatch before publishing a trust-chain view.
- Complete bounded LAW-11 installed proof-task reuse for modular scalar,
  finite structured, native relational and direct Project postcondition laws.
  Authenticated private entries bind checked transitive subjects, tool/profile,
  model, axioms and budgets; selected native laws recheck in prerequisite order.
  Fresh current Project/artifact evidence is rebuilt after logical reuse, and a
  canonical per-law report separates verdicts from fresh, validated-reuse,
  stale, unsupported and inconclusive work. Focused real Z3/Lean gates and
  poisoning, cancellation, dependency and artifact-drift controls passed.

- Add an inert exact Url 2.5.8 Project package route with checked Semaprax body execution and receiver-tied returned views. Local locked/offline O0/O2 consumers prove authored-result changes, direct pointer identity, canonical owner/view cleanup and guard-removal controls. Source and HIR retain the owner relation through byte inspection; RI-06 remains partial for its remaining lifetime and safety acceptance.

- Add an opt-in LAW-09 guard to the authenticated indexed Project Rust SDK.
  The generated adapter checks an exact declared i64 return range before
  publishing the value to Semaprax and reports a stable import status on
  violation. A real compiled consumer exercised both good and seeded bad
  returns; the conditional frontier is bound to the published SDK manifest.
  Caller certificates and protected LawSet association remain open.
- Exercise one authored record and variant law-runtime fixture through the
  interpreter and emitted Core Wasm with a hand-written result reference and
  seeded body mutation. The scalar public export remains narrower; this is
  bounded runtime differential evidence, not an aggregate lowering proof.

- Add a versioned LAW-13 proof-to-runtime trust-chain view with exact source,
  artifact and optional kernel replay, explicit trusted lowering and unexecuted
  runtime status. A scalar reference/interpreter/emitted-Wasm fixture exercises
  checked failure semantics and detects a seeded wrong runtime value. Record,
  variant, foreign-adapter and full mutation-ladder coverage remain open.
- Complete the bounded LAW-13 trust-chain gates: the record/variant emitted-Wasm
  fixture and resealed negative ladder now pass, and the owning specification
  names foreign calls as explicitly unsupported in the Lean proof profile.
  Runtime guards remain exercised by the scalar differential fixture; no
  compiler-preservation or foreign-adapter theorem is claimed.

- Add an inert authenticated Project-to-native Regex package route that executes the checked Semaprax body and canonical cleanup plan. Pinned real Regex consumers pass at O0/O2, including authored-result changes, domain errors, zero adapter copies, exact String construction counts, and missing-finalizer controls. Url returned-view integration and the remaining RI-06 safety criteria stay open.

- Complete the bounded LAW-07 structured proof profile with a selected
  four-module Project and managed Workspace. A private record-body law
  executes under exact installed Z3 evidence; a fresh candidate proof permits
  strict publication, while stale or missing proofs leave `ACTIVE` unchanged.
  Reordered fields and added variant branches invalidate source-bound replay.
  Public authored aggregate ABI remains outside the scalar export profile.

- Add bounded RI-08 checked callback and source-driven registry projections. Real C/Rust iterator and stateful safe-trait consumers pass at O0/O2, with cross-crate lifetime controls, shared nested-call guards, distinct failures, and uncertain-teardown quarantine. Source mutable, borrowed, and owned capture admission remains open.

- Add a LAW-07 versioned Project certificate for finite record and variant laws. Reparse exact retained source, bind field/case and query identities, rerun installed Z3 or pinned Lean on replay, and attach only opaque proof to exact Project assurance. Distinct strict profiles reject scalar-to-structured method substitution. A 196-state reference corpus and real installed Project Z3/Lean gates passed; selected physical publication remains open at the public export profile's `SPX-W115` aggregate refusal.

- Add a straight-line LAW-06 checked-summary path: separately prove exact callee contracts, instantiate fresh typed results, stage caller-side preconditions before summary assumptions, and prove the caller using installed Z3. A weakened-summary negative control fails the caller proof without claiming a concrete runtime witness.

- Add LAW-06 Project-bound linked-HIR admission and a bounded scalar-call inlining proof fallback. Preserve caller precondition checks as ordered checked obligations, report replayed Z3 witnesses, and bind proof metadata to exact transitive source digests. The reusable summary and LAW-04 attachment work remains open.

- Lower LAW-05's shared typed scalar VC subject directly into SMT and Lean,
  preserving binding identity and both public proof formats. Add a small
  checked-i64 model interpretation corpus as test evidence. Stage precondition arithmetic by evaluation order, require a
  checked satisfiable-domain witness before new proof export, guard Lean's
  lazy boolean ranges, and refuse nonlinear multiplication under QF_LIA.
  Focused unit and installed Z3/Lean negative controls passed locally.
  Source-bound v1 certificate replay now reconstructs a checked domain
  witness or returns unknown. Structural v1 replay remains envelope-only.

- Enforce host-selected strict laws for native-law v2 Projects. Persist the independently held baseline and method policy under a private host marker, refuse generic Project and Workspace protected routes, and replay exact opaque proofs through selected execution, build and managed publication. Managed Workspace generations retain native law source bytes and facts with no executable law nodes. Focused library 2/2 and real Z3 selected publication 1/1 passed, including omission, drift and bypass controls.

- Add explicit bounded installed Lean/Z3 checking for new exact Project
  postconditions and native typed relational laws. Opaque proof tokens bind the
  Project, law inventory and semantic proposition; strict candidate replay
  preserves open assumptions/prerequisites and refuses missing, forged, stale
  or wrong-method evidence. The installed CLI checks one selected subject
  without running application code. Global protected-route admission remains
  open LAW-04 work.

- Complete the RI-14 stable Rust-source experiment with a no-go promotion
  decision. The feature-gated checked-HIR owned-Bytes island executed through
  pinned stable Rust at O0/O3, while the same source's scalar entry ran in the
  interpreter and C11 at O0/O2. Six focused cases passed, including a generic
  Rust callback and forged-cleanup refusal. Shared physical cleanup traces and
  matched allocation/overhead measurements are unavailable, so default targets
  and support claims remain unchanged.

- Extend private generated Regex/Url adapters with invocation-scoped owner-tied
  string views. Keep re-entry guards through forgotten views and unwind, reject
  moves/mutation/escaping views at Rust compile time, and execute pinned-library
  O0/O2 plus guard-removal/copy controls. Semaprax loan/borrowed-ABI admission and
  full RI-06 acceptance remain open.

- Add the first Strict Law Assurance v1 library and candidate gate: independently
  selected complete law inventory, exact method/trust requirements, bounded model
  separation, and intent plus coverage replay at managed publication. Caller
  proof-reference strings cannot grant formal acceptance. Global protected-route
  admission remains open LAW-04 work; installed adapters are recorded above.

- Add an experimental bounded native String renderer with checked source/HIR
  ownership, graph v57, exact selected signature binding, canonical helper
  cleanup, and core-compatible String cloning. Focused physical controls cover
  allocation/admission refusal, panic, stale carriers, missing cleanup, and
  allocation abort. String Project publication and full RI-05 remain open.

- Protect law intent with independently held revision-bound baselines, conservative
  specification closure, explicit editable implementation bodies, and exact
  host-approved specification-change proposals. Candidate review reports unknown
  semantic changes and protected publication rechecks approval under the ordinary
  Workspace lock; protected advisory repairs never suggest weakening contracts.

- Add LawSet v1's independently protected inventory of named scalar contract,
  architecture, protocol-realizer and reference-model laws. Bind exact Project,
  ProgramRoot, proof profile and provenance; reject ambiguous or retargeted
  identities and replay missing/open coverage without shrinking expected laws.
  Existing assurance report bytes and obligation identities remain unchanged.

- Extend the experimental native owner renderer and indexed Project package with
  checked owner-returning Semaprax helpers. Replay each helper cleanup plan,
  preserve provisional-result guards and sticky failures, and exercise counted
  destruction plus missing-cleanup and early-publication controls. Public SDK
  exports remain scalar; full RI-05 support remains open.

- Add an explicit CLI handoff from pinned rustdoc extractor output to a
  canonical prepared Rust API index. Bounded selected-import context and
  candidates now expose a scalar callback escape hatch for rejected items;
  an installed VS Code Extension Host gate matches Regex hover metadata to
  the compiler CLI without preparing build tools.

- Exercise the explicit local Semaprax builder from a standalone, locked,
  offline Cargo consumer. A source change rebuilds the generated SDK and
  changes the observed result; a wrapper gate rejects nested Cargo. Model
  owner-tied returned string views and per-resource callback refusal with
  focused Rust checks. Rich package relocation and generated borrowed ABI
  remain open RI-10/RI-06 work.

- Map captured generated-wrapper rustc trait, feature, and lifetime errors to
  the selected `.spx` import with bounded, read-only diagnostics. Keep raw
  compiler detail and mark external captures unverified; generic context,
  impact, and review still refuse native Rust imports.

- Add experimental selected-index opaque-owner Project packages over the
  existing explicit indexed-project route. Bind resource/type/package identity,
  compile exact Rust signatures, and publish generated owner glue through the
  held archive and no-clobber package publisher. The scalar and owned-data v1
  package contracts remain unchanged; general RI-05 support remains open.

- Expose replayed prepared Rust API index facts through a 4 KiB bounded CLI
  context and candidate projection. VS Code reads the same pure compiler
  metadata for selected-import hover, completion, declaration navigation, and
  candidate import fixes. Oversized docs truncate visibly without changing
  support or rejection status; no editor request invokes a tool or build.

- Add an explicit `indexed-project` Native Rust SDK CLI route over a bounded
  selection file and prepared Rust API index. A focused physical CLI test
  generates a selected Project package and runs its Rust consumer; read-only
  context inspection stays separate from build authority.

- Add experimental native Rust opaque-owner rendering from checked Semaprax
  and canonical cleanup plans. Preserve owned constructor results and native
  argument moves through source/HIR verification; generate an opaque C carrier,
  Rust ownership table, consuming method and destructor glue. The physical gate
  covers ordered Rust destruction, failures, and compiled negative controls.
  Project/CLI owner builds and RI-05 completion remain open.

- Bind explicit indexed Rust imports before Project/workspace frontend
  checking, include selected facts in additive graph v5 projections, and
  invalidate frontend reuse on metadata drift. The authenticated Project SDK
  now verifies selected plans and compiles generated package adapters; a
  physical Project regression retains success and a flipped-result control.

- Disclose the consequences of a later trusted native build separately from
  read-only CLI inspection: build scripts and proc macros have host filesystem
  and network access, Cargo's offline flag is not confinement, and the later
  explicit invocation selects its environment and roots.

- Add a private CLI integration negative control: check, format check, query,
  and graph run beside a hostile Rust build script and proc macro with Cargo
  and rustc marker shims, leaving every marker and source byte unchanged. No
  rich Native Rust index replay CLI route exists in this profile.

- Add a read-only private `native-authority-check` CLI route over explicit plan,
  crate, and selected tool files. It exercises the native profile's build or
  dispatch admission and reports actual unsupported target, missing tool,
  missing capability, untrusted behavior, and unavailable sandbox refusals.
  It never launches Cargo or a callback and labels audited effects as a
  maintainer assertion rather than compiler verification.

- Add explicit rich Native Rust host wrappers for admitted Cargo build,
  capability grant, and callback dispatch. Render unsupported API, missing
  tool, missing capability, opaque native code, and unavailable sandbox as
  distinct human/JSON diagnostics. The full CLI has no rich-Cargo route yet.

- Add RI-01 bootstrap negative controls for plan/descriptor disagreement,
  unsupported target/signature refusal, stable-ID source facts, Rust Result
  failure, and a caught fixture unwind. Bind missing-effect refusal to RI-11's
  profile dispatch before callback entry.

- Implement RI-01's local generated scalar round trip: a canonical
  BindingPlan now renders the Rust callback adapter for an ordinary fixture
  crate, and the native harness compiles and runs it through the existing C11
  bridge. Preserve the v1 bridge and leave Result/panic, automatic indexing,
  Cargo preparation, and target promotion to their separate gates.

- Define RI-01's additive rich-Rust BindingPlan contract and generated
  C-compatible bootstrap boundary. Reserve its schemas and diagnostics, retain
  the scalar v1 bridge unchanged, and defer automatic indexing, Rust-source
  lowering, and patched-rustc monomorphization to their separate issues.

- Use verified #321 guard forwards as dispatch authority while retaining native
  CLI turn counts as metadata. Preserve cohort07's two trials separately; its
  guard correctly refused excess bytes before a legacy turn check halted it.

- Add the #321 fixed-TLS request guard and one-use MCP FIFO bridge, with physical
  network confinement and exact-model/work bounds. Keep unknown-cost incomplete
  trials under full reservations while preserving integrity/overrun halts; state
  the provider framing limitation without claiming an invoice ceiling.

- Account for the pinned Claude CLI final non-tool turn on exact terminal
  success, retaining the same model-request turn/cost limits. Preserve the
  prior eight-position packet and require a fresh full protocol cohort.

- Freeze a final #321 300-second wall profile while retaining 32 turns and
  existing token/cost ceilings. Bind MCP temporary files to its private state
  root; retain the earlier timeout packet and unknown-cost halt unchanged.

- Distinguish exactly observed native turn exhaustion from integrity failures
  in a new #321 protocol: score the retained partial candidate as a failed task,
  preserve max-plus-one terminal turn accounting, and bound cached-read tokens
  separately. Unknown/overrun cost, timeout and model drift still halt dispatch.

- Freeze a separately authorized #321 cohort at 120 seconds, 32 turns,
  131,072 reported tokens, $0.25 per trial and $9 aggregate API-equivalent
  reservations. Preserve both earlier halted/aborted packets and unchanged
  no-refund/admission-halt rules; subscription invoice cost remains unknown.

- Preserve the #321 native compiler MCP under explicit isolated settings;
  native safe-mode had disabled even the explicitly supplied server. Add a
  zero-user-turn confined MCP discovery gate alongside hostile-hook refusal.
  Retain the first two-position packet as aborted evidence without retries.

- Add an explicitly authorized Claude Team coding-agent pilot transport with
  18 frozen positions per model, separate native receipts, confined compiler
  gateway, private disjoint authority roots, and durable aggregate reservations.
  Preserve existing OpenCode evidence and distinguish technical scoring from
  operator-recorded review waiver metadata. Native admission failures halt
  further dispatch; no provider inference was needed for the focused gates.

- Provision the #332 Linux provider guest with exact CPython 3.12.14 and a
  credential-free committed source projection, retaining archive/file hashes
  without guest Git claims. Add exclusive interactive-login custody and orphan
  auth cleanup. Pure provider/runtime gates passed 6/6 and 4/4; native Python
  metadata matched the pin. No model calls or guest restart were performed.

- Admit #332 guest-native generation from an externally pinned controller
  source snapshot without requiring a guest Git executable. Recompute exact
  implementation/source/prompt and plan fields, record controller revision
  provenance explicitly, and preserve ordinary Git-based controller scoring
  plus one-use cell custody. Focused local fixtures passed 12/12 in 3.479s;
  no provider inference was performed.

- Add explicit #332 Linux arm64 Apple Container scoring admission with official
  Node/TypeScript provenance, immutable image and launcher pins, Landlock and
  seccomp confinement, and physical read/write/fork/socket denial controls.
  All five focused checks passed in 42.296s, including real guest success and
  wrong-result/early-exit failures in both phases. This is a local VM scoring
  fixture with zero provider calls, not independent physical hardware or a
  second-environment model-generation claim.

- Bind the #332 frozen pilot to distinct native host executable digests, auth
  homes, kernel/boot identity and shared Claude CLI version/models/caps. Split
  native generation from controller scoring, revalidate exact provider bytes
  and consume one create-new ledger entry per model/host cell before scoring.
  Correct completion evidence for the silent frozen validation harness. The
  focused protocol/transport/handoff/bridge gate passed 11/11 in 2.231s; no
  provider inference was run and independent generation remains required.

- Admit only the exact undated Sonnet 5.5 model version ID alongside dated
  snapshots in the #332 pilot. Preserve family-alias and guessed-version
  refusal, with a focused protocol regression; no model request was made.

- Add the #332 laboratory pilot route: freeze the full 182-row inventory and
  two-model/14-adapter pilot dispositions; require disjoint candidate/hidden
  paths; bind native Claude subscription calls to explicit executable/model
  authority with bounded capture and truthful usage/cost receipts. The new
  Darwin candidate session isolates numeric evaluation from fixed assertions
  and rejects early-exit success forgery. Local fixtures passed 8/8, supported
  scope preservation 29/29, and existing v3 pure provenance 11/11. No provider
  trial or second-host admission is claimed; the fixed-source v3 route remains
  unchanged.

- Pin unsupported native/C11 and Core-Wasm admission for the checked source
  Agent owned-wait fixture: SPX-B116/SPX-W126, with both scalar artifact
  projections refusing SPX-H006 before an artifact or effect. The focused gate
  passed 1/1 in 6.61s on local macOS. Record three narrow cached preservation
  passes from a62101c84: exact SDK prompt (0.02s), shared Copy/scalar ABI
  spellings (0.04s), and inert observation SDK refusal/usize bounds (0.00s).
  These results do not claim native execution or a broader wire suite (#330).

- Add an opaque public first-model prepare/finish/shutdown boundary. Explicit
  abandonment and cancellation before Authorize settle the same actual State
  through HostAbandoned, Started, observed receipt and Cancelled Stop ACKs,
  without evaluator work, target dispatch or new funding. Uncertainty retains
  custody and cannot retry. Local macOS 2 MiB gates passed explicit/cancel
  success 1/1 (two scenarios, 64.84s), failure/Started faults 1/1 (four scenarios,
  129.71s), receipt/Stop faults 1/1 (four scenarios, 129.87s), observer-failure
  Stop refusal 1/1 (32.75s), and existing cancel/denied-policy preservation 1/1
  (two scenarios, 52.96s). No full profile was run; current-head Linux process
  evidence remains a separate closure gate (#330).

- Settle actual first-turn source Refused through its original State, exact
  compiler cleanup vector and acknowledged State receipt before sticky
  StageRefused Stop. Empty scalar-only Decision cleanup stays empty; uncertain
  append or observer failure retains custody without retry. Local macOS 2 MiB
  gates passed public success 1/1 (33.85s), Started pre/postwrite faults 1/1
  with two scenarios (54.97s), and observer failure plus failed-receipt Stop
  refusal 1/1 (33.62s). Broader shutdown remains separate work (#330).

- Add exact first-TransferCompleted public recovery with a consuming State
  restoration permit, authenticated current-prefix pins and ordinary charged
  Authorize. Post-restoration failures retain actual State/Decision custody;
  fresh, terminal and missing-authority recovery refuse before new work. Public
  subprocess success passed 1/1 (366.52s), State/Decision ACK-fault custody
  passed 1/1 with two scenarios (131.30s), and settled-without-transfer refusal
  passed 1/1 (65.97s), all on explicit 2 MiB workers on local macOS (#330).

- Select live candidate-test evidence when an interrupted repair resumes and
  executes tests; derive replay-only evidence only when no live observation
  exists. Avoid reporting one observation twice as a receipt conflict, while
  terminal replay still performs zero provider and effect dispatches (#323).

- Keep the physical repair post-settlement pause parked through queued tokens
  and spurious or explicit wakes. A process regression exercises the durable
  ACK/marker path and repeated unpark signals without crossing into subsequent
  work; interrupted effect intents remain refused on recovery (#323).

- Settle a real second-turn target failure through the original State owner,
  shared physical CleanupStarted/receipt/Stop ACK adapter and cumulative funding
  registry. Public `FailedEffectStopped` admits close only after the checked Stop;
  uncertainty retains custody without redispatch or repeated cleanup. The public
  2 MiB success gate passed 1/1 in 316.81s; State Started before/after-write faults
  passed 1/1 (two scenarios) in 615.61s. Receipt and Stop before/after-write
  selectors passed 1/1 each in 629.13s and 632.35s; State-observer panic and
  cancelled Stop passed 1/1 each in 317.10s and 315.94s. These six selectors
  used the same emitted macOS binary for the e97bd0828 core packet. Required
  transferred-owner recovery and broader shutdown remain open (#330).

- Admit the exact observed `json` fence around a native Claude JSON-string
  proposal as explicit transport framing. Reject other labels, nested fences,
  prose and trailing bytes; preserve decoded proposal bytes and strict compiler
  validation. Private diagnostic08 establishes the framing mismatch (#323).

- Frame native Claude proposal results as one explicit JSON string, preserving
  the provider-authored escaped final LF through CLI output. Reject unframed
  objects and trailing JSON; keep exact decoded bytes and the strict compiler
  decoder unchanged. One private diagnostic observed a missing final LF (#323).

- Raise the native Claude repair V3 per-call ceiling to 90 seconds, bounded by
  remaining configuration time and checked cumulative deployment budgets.
  Preserve OpenCode limits and test native ceiling admission, shorter deadlines,
  timeout termination, output limits and cancellation with local processes (#323).

- Supply native Claude response guidance from the compiled proposal schema,
  including the exact envelope identity and digest omitted from the frozen
  source request. Keep provider result bytes and the canonical decoder
  unchanged; local decoder and executable fixtures cover this boundary (#323).

- Preserve validated USER/LOGNAME login metadata in the native Claude host
  so its existing keychain subscription login survives environment clearing.
  A local auth-status diagnostic and credential-free executable regression
  distinguish this from inherited credential or endpoint variables (#323).

- Bound owned-Agent terminal driver stack retention by carrying owners and
  typed failures on the heap between each selection, append, ACK, release,
  transfer and Report claim. Pin the fresh public regression to a 2 MiB worker
  independently of suite stack settings. At `46d99ddfb`, the local macOS fresh
  public gate passed 1/1 in 395.90s and the independent prepared-process restart
  plus hostile-tail gate passed 1/1 in 445.90s with 2 MiB workers. The terminal
  body frame fell from 1,860,528 to 1,280 bytes; its ACK driver fell from 690,192
  to 240 bytes. Linux and broader failure/shutdown evidence remain separate
  (#330).

- Add a private native Claude print-JSON repair V3 route with exact model
  binding, bounded shared process capture and provider-reported usage. Preserve
  V1/V2 config meanings and checked source/candidate/journal authority; local
  fixture gates do not establish live-provider or hosted repair evidence (#323).

- Author a public first-Prepared process recovery entry for Source owned-Agent
  runs. Strictly parse complete host-retained registration facts, recheck the
  compiled Project binding and physical store pins, and consume separate
  recovery and continuation host grants into the existing two-turn runtime.
  A preparer/relauncher regression covers Report completion and pre-effect
  refusal for fresh, forged and hostile histories; it awaits execution (#330).
- Add an authored fresh public Source owned-Agent entry around the existing
  checked two-turn runtime. It derives the binding from retained Project source,
  requires complete physical registration retention before append, and returns
  an opaque custody handle whose terminal projection carries only checked
  Report data. A real public two-turn regression is authored; its default-stack
  run overflowed and the corrected fixture rerun hit local disk exhaustion.
  Broader failure shutdown remains pending (#330).
- Extend owned-Agent heap transfer boundaries through each second-turn join
  and each Decision-cleanup append/ACK, preserving typed failure custody and
  cleanup order. This addresses a late 2 MiB worker-stack overflow; executable
  validation of this follow-up remains pending (#330).

- Reduce owned-Agent two-turn driver stack retention by transferring physical
  owners between short heap-backed phases. Preserve existing consuming joins and
  failure custody, and pin process-restart regression children to a 2 MiB Rust
  worker stack so larger suite settings cannot hide a regression (#330).

- Fix first Prepared restart admission to compare the authenticated request
  digest written by the live wait, preserving the frozen wire format. The
  process regression now explicitly distinguishes that digest from the ordinary
  observation digest; its Model ACK assertions and fault injection are bound
  to the actual Prepared sequence. This correction is source-checked, with
  behavioral rerun pending (#330).

- Preserve real second-turn failed Observe and first-turn Decision-observer
  failure in private owned-Agent runtime custody, with distinct checked State
  cleanup/receipt/Stop tails. Earlier target failure remains sticky, normal
  authority stays poisoned after observer failure, and incomplete boundaries
  refuse close and retries. Add owning runtime success, cancellation, callback
  panic and all cleanup before/after-write fault regressions; authored but
  unexecuted. Public constructor and full shutdown remain open (#330).

- Route an actual first-turn owned-Agent failed target from private runtime
  custody through its checked State cleanup, receipt and sticky Stop. Failed
  cleanup boundaries retain the reached owner without retry; owning success
  and three append-fault regressions are authored but unexecuted. Public entry
  and full failure/recovery settlement remain open (#330).

- Join the exact authenticated first Prepared restart into private owned-Agent
  runtime custody before Model execution. The restored owner can continue
  through the existing two-turn terminal path; continuation failures retain
  their actual owner and refuse close or retry. Add process-relaunch,
  terminal/no-redispatch, cancellation, hostile-tail and append-fault regressions,
  authored but unexecuted. Public construction and full shutdown settlement
  remain open (#330).

- Fix successful owned-Agent Report projection poisoning its journal when the
  inherited Reduce hold was dropped. The physical claimed Report now permits
  one checked retirement of the matching authenticated terminal registry entry;
  incomplete and failed paths keep quarantine armed. Composed success/reopen
  and failure-retention regressions are strengthened, unrun in this source-only
  change (#330).

- Owned Agent v8 now has private typed runtime custody for Initialize through
  Model/Resume, independent of disposable caller session handles. Runtime-driven
  failed-Observe cleanup uses the existing acknowledged cleanup/receipt/Stop
  chain, retains exact failures, and admits no cleanup or dispatch retry.
  Pending owners refuse normal runtime close; forced teardown retires the
  journal before backing release without claiming semantic settlement. Six
  owning regressions are authored, unrun; public lifecycle and restart remain
  incomplete (#330).

- Define the public owned-Agent entry contract for #330. It records the
  authenticated two-step fresh-registration boundary, the required ownership
  transfers, and the conditions for a future bounded two-turn SourceLive-v8
  driver. Private drivers now join initial, continued, and later failed Observe
  plus initial failed-target cleanup through acknowledged receipt and sticky
  Stop, retaining reached owners on incomplete boundaries. A private terminal
  path consumes the live Report claim into a bounded projection with exact
  authenticated evidence. Public multi-turn entry, remaining failure tails,
  and recovery remain open, so this source-only work does not close #330.

- Disable implicit OpenCode title, summary and compaction model work in the
  private fixed-model host policy, and pin its default, small and selected-agent
  models. The process-stub regression checks the policy actually staged before
  dispatch. A refused local #323 attempt exposed title-model selection outside
  checked attempt accounting; this fix is not successful live-provider evidence.

- Complete #328's exact `f99c76dc2` Kernel-0 accepted-profile record: the
  124-case Kernel selector, 10-case owned-handoff selector and required Lean
  gate passed locally. Record the reviewed rung-1 retention decision, raw
  receipts and bounded proof/authority claims. The baseline alone carries the
  user's local full-profile waiver; no full-profile pass or rung-2 promotion
  is claimed.

- Establish the Windows doctor image-binding argument from continuous NTFS
  deny-write/deny-delete sharing and the existing native retained-section
  initial-open receipts. Preserve every production guard; add concurrent
  section/open races and hostile writer attempts at all five launch boundaries
  to the native selector. The two new cases still require native execution;
  production Windows support and release trust remain unpromoted.

- Extend the standalone Windows doctor confinement primitive with a two-second
  per-process CPU ceiling, a 256 MiB committed-memory ceiling, and 64 KiB
  combined anonymous-pipe output accounting. The 31-case selector preserves a
  CPU-limit nonzero exit code without unsupported attribution, requires an
  allocation refusal, and floods both streams below their individual cap but
  above their shared cap. This source-only change has no Windows runtime
  receipt and does not wire an ordinary Windows provisioner route.

- Connect private owned-Agent runtime custody across the complete two-turn
  lifecycle: first Model completion through authorization, target execution,
  Decision cleanup, Reduce/Continue, the second turn and authenticated Report
  consumption. Reopened session handles cannot repeat dispatch, cleanup or
  append; incomplete joins retain their exact owner and refuse runtime close.
  Add success/store-reopen, all 19 first-bridge prewrite boundaries, later
  Model/terminal faults, cancellation, policy, target and observer regressions.
  These tests are authored but unexecuted. Public construction, complete
  shutdown settlement and general restart recovery remain open (#330).

- Harden the Windows doctor request/bundle carriers against duplicated write
  access and owner-mediated DACL changes using a protected OWNER RIGHTS deny
  policy. The existing native child handoff case now rejects `FILE_MAP_WRITE`,
  `WRITE_DAC`, and `WRITE_OWNER` duplication. This source-only correction keeps
  all 26 selected Windows cases and still requires native execution evidence.

- Distinguish initial file-open admission from later oplock refusal in the
  Windows doctor #333 binding corpus. The retained writable-section and
  surviving-view cases now require refusal before the first successful open;
  the launch control requires all five checkpoints in order. The existing
  24-case selector is unchanged. This source-only tightening needs native
  execution and does not close exact image/request/bundle binding.

- Compose the private owned-Agent second turn from the actual first Continue
  Step through Observe, Model, authorization, target dispatch, Reduce, and
  authenticated terminal Report projection (#330). Every failed join retains
  its physical owner in an opaque quarantine and retires the same journal;
  cancelled and unsupported iteration admission performs no new effect.
  Add owning success, prewrite, cancellation and profile-refusal regressions,
  unexecuted at this change. Public construction, initial-turn orchestration,
  runtime quarantine lifetime and general restart recovery remain open.

- Retire the failed exploratory Windows OWNER RIGHTS image experiment (#333),
  preserving the 24 established native cases and every production guard.
  Native run 36983893062 observed `SetSecurityInfo` access denial; Microsoft's
  sharing contract also rules out the proposed metadata-only deletion pin.
  Exact signed-image binding remains open.

- Add source-only process-restart regression coverage for the private prepared
  owned-wait continuation (#330). An exited preparer and independently rebuilt
  relaunch use the original pinned directory plus test-held registration facts;
  the relaunch dispatches once, while hostile tail bytes refuse before any
  owner or adapter. This test transport is unavailable outside `cfg(test)` and
  its new regressions are unexecuted.

- Add the sealed first-turn Prepared restart continuation (#330). A second
  trusted-host grant rechecks the exact source/checkpoint/tail/lease facts
  before it consumes fresh restored backing into the original model path. The
  Prepared prefix has no AttemptIntent, so the path cannot redispatch; refusal
  or model failure quarantines the reopened journal. Cleanup, effects and
  public Agent execution remain outside this private route.

- Add a sealed first-turn prepared owned-wait v8 restart owner (#330). After
  close/reopen, one trusted-host grant can authenticate the exact registered
  Prepared tail and checkpoint before allocating fresh process-local Bytes
  backing. The recovered lease stays read-only; later turns and StartReserved
  uncertainty refuse without model dispatch or append authority.

- Fence recovered source-owned-wait v8 leases to authenticated read-only
  history (#330). Retained registration, matching pins and the MAC chain can
  inspect evidence but cannot append a successor before a sealed physical
  owner-restoration permit exists. The store regression proves the bytes stay
  unchanged after a rejected restart append; physical owner restoration and
  public multi-turn entry remain open.
- Strengthen the #333 Windows no-view writable-section regression: a retained
  section must actually mutate an observed signed-image byte after the expected
  pre-spawn refusal, then restore the fixture. Native Windows execution remains
  required; exact image/request/bundle binding remains open.

- Reconcile the full-profile rustfmt gate and two private-interface visibility
  warnings exposed while validating the #327 Linux migration sanitizer. The
  formatter changes only Rust layout; stage and cleanup behavior is unchanged.

- Run the Linux held-native migration sanitizer gate through a test-only ELF
  compiler launcher, preserving exact ASan/UBSan flags and symbol checks when
  the process provider refuses held shebang scripts (#327). Add a physical
  refusal regression; production held-executable rules are unchanged.

- Include owned record and variant field transfers in cleanup skeleton work
  reservations (#337), preserving the global replay limit and refusal before
  unbudgeted materialization. Add nested generic record and owned variant
  regressions for the derived bound and one-unit-short diagnostic.

- Preserve the frozen public-generic native byte-runtime and generated-package
  bytes by emitting newer buffer-store helpers only for resolved calls that use
  them (#337). The legacy runtime pin and selected-helper regression now run
  together.

- Add a private consuming turn-two Complete closure through actual Step cleanup,
  field transfer, terminal ACK and original Report claim (#330). Every refusal
  retains its reached owner and spent funding. Focused local success and
  terminal-prewrite refusal passed 1/1 each; the receipt-prewrite case remains
  unrun. Public delivery and physical owner restoration remain open.

- Expand the Windows doctor hostile/runtime selector to 22 cases (#333),
  covering retained writable-section refusal cleanup and anonymous carrier
  handle lifetimes. All 22 ran and passed on Windows Server 2025 at
  `e15c16202`; exact launched-image binding remains open.

- Join the private turn-two Completed owner into the existing authorization,
  effect, Reduce and staged Step pipeline (#330). The join retains its physical
  Resume, exact ACK history and actual later Step hold. Focused local success
  and foreign-wait refusal passed 1/1 each; the authorization-prewrite
  regression awaits execution. Public
  multi-turn execution and restart restoration remain open.

- Bind recovered target-migration finalizer rows to the exact prepared pure
  migration closure (#327). A structurally valid row for an unrelated source
  function now refuses before the durable destination can use the handoff.

- Add a branch-scoped Ubuntu/Podman reference-service OCI gate (#336) that
  builds the exact static Linux artifact, checks source/artifact identity, and
  exercises refusal plus login/CRUD/job/restart paths. Its selected hosted
  Linux/Podman journey passed at `c3d5dead8` with a retained artifact digest
  and evidence record; broader deployment and service acceptance remain open.

- Assert ordered target cleanup-event parity for durable fresh, ordinary
  recovery, migration-seeded, and seeded-recovery Agent runs (#327). Checkpoint
  prefix/current-suffix and independent evidence controls passed locally 2/2;
  hosted migration and the full target profile remain open.

- Resume the actual turn-two Parked wait after its exact reservation ACK and
  append `OwnedWaitCompleted` only from a checked Resumed State (#330). The
  owning success and Completed-prewrite refusal selectors passed locally;
  later Effect/Reduce/Step and public recovery remain open.

- ACK actual turn-two Model Usage and a full-fuel Resume reservation from the
  retained physical owner (#330). The owning success and both distinct
  prewrite-refusal selectors passed locally; physical Resume, Completed, and
  public recovery remain open.

- Add an isolated Windows anonymous request/bundle carrier experiment (#333).
  It authenticates signed artifact bytes into read-only inheritable mapping
  handles and adds a native hostile-write selector. The provisioned Windows
  selector passed 18/18 at `06c0090d9`; production child transport remains open.

- Reject producer-impossible target cleanup receipts during durable Agent
  recovery (#327): oversized finalizer inventories, invalid function identities,
  and liveness flags outside `u32`. The focused negative-control gate passed
  locally; hosted migration and full target-event parity remain open.

- Extend the selected Windows doctor launch test with post-binding hard-link
  creation and writable-section probes (#333). Those selected cases passed in
  the eighteen-case native run at `06c0090d9`; exact launched-image binding
  remains open.

- Check optional inbound version-00 trace metadata through the reference
  service's source decision before clock or state work (#336). Five focused
  success, denial, compatibility, and oracle cases passed locally; no trace
  propagation is claimed.

- Bind outward durable semantic-work evidence to the selected target (#327).
  Evidence v3 carries the same target binding as the metered checkpoint;
  fresh and both recovery paths assert parity. Three focused selectors passed
  locally.

- Dispatch turn-two Model work through the retained physical owner (#330),
  then append its actual settlement ACK with the fixed writer and cumulative
  hold. Focused success and settlement prewrite-refusal selectors passed
  locally; later Usage/Resume and public recovery remain open.

- Bind durable metered Agent recovery to the selected execution target (#327).
  Metered checkpoint v2 records the target binding; v1 remains inspectable
  but cannot resume live work under an unbound target. Focused codec,
  cross-target refusal, and migration-replay selectors passed locally.

- Add opt-in signed-timestamp JSON-event v2 completion delivery (#336),
  checked against the scaffold webhook decision using authenticated prior
  intent facts before export, state, or physical delivery. V1 and OTLP remain
  available to older projects. Focused delivery (4/4), policy (6/6), and
  decoder (1/1 each) selectors passed locally.

- Append the turn-two Model Intent ACK from the retained physical Prepared
  owner (#330). The checked request builder uses its actual State, request,
  observation and ordinal; the fixed writer and cumulative hold retain the
  parked owner before SDK dispatch. Focused success and prewrite-refusal
  selectors passed locally.

- Retain authenticated HTTP intent facts for checked webhook admission (#336):
  the native host records an HMAC-bound body digest, signing timestamp, and
  first-attempt reservation under the existing no-redispatch marker name.
  Legacy and invalid records cannot supply invented prior facts.

- Append turn-two `OwnedWaitPrepared` from the retained physical Parked owner
  (#330), using the existing fixed writer and cumulative hold. The focused
  success and prewrite-refusal selectors passed locally; later Model and
  public recovery remain open.

- Enter the physical turn-two source wait from the retained two-ACK Start owner
  (#330), preserving the State, Copy observation, fuel accounting, and original
  Start reservation. The focused success and prewrite-refusal selectors passed
  locally; later checkpoint and public recovery remain open.

- Bind actual OTLP completion logs to the checked structured-log policy
  (#336), with source denial before delivery and six explicit credential flags.
  Correct the default metric wrapper so successful completion evaluates under
  the public decision seam. Five log-policy, metric oracle, delivery protocol,
  and six separate-process provider selectors passed locally.

- Carry the actual later-turn Observe owner into `OwnedWaitCreated` and Start
  reservation (#330), retaining its State/Copy observation and two ACKs. The
  focused success and prewrite-refusal selectors passed locally; later source
  entry and public recovery remain open.

- Cover lost terminal acknowledgement during metered target migration recovery
  (#327). The integration regression checks paired replay fuel reservations and
  semantic-work receipts, one retained Complete transition, and no host
  redispatch; its focused selector passed locally.

- Gate reference-service completed-job delivery through the checked
  `completed_job_metric_is_admitted` source decision before outbound delivery
  or snapshot mutation (#336). Source denial preserves the pending job and
  outbound inventory.

- Settle the later physical Observe result through `OwnedObserveSettled` and
  `TurnObserved` (#330), retaining the actual owner and reservation on a
  rejected append. The focused success and prewrite-refusal selectors passed
  locally; later Start and public recovery still require their owner joins.

- Verify reference-service outbound delivery against a separate local TLS
  provider process (#329). Success, provider refusal, and close-after-request
  settle through the actual service/store and retain one provider-observed
  request across restart. An optional operator-held DER root enables private
  provider trust without disabling TLS hostname verification.

- Claim the actual physical Complete Report after its authenticated terminal
  ACK (#330). The private owner keeps the store borrower and checks a borrowed
  delivery projection against the terminal carrier. The owning success and
  prewrite-refusal selectors passed locally. Public Report delivery and
  restart owner restoration remain open.

- Carry the real continued Step into turn-two State and Observe (#330):
  a separate later owner selects the State row, ACKs the exact Observe
  reservation, and enters physical Observe through the existing engine. The
  owning three-turn success and State-prewrite refusal selectors passed locally.
  Public multi-turn entry, terminal delivery and owner restoration remain open.

- Bind reference-service job completion to the checked source decision (#336):
  the host admits only the source-selected Completed status before preparing
  delivery or a snapshot; source denial and evaluator failure leave committed
  state and outbound inventory unchanged. Both focused completion-policy tests
  passed locally. Broader service decisions and storage remain open.

- Add a distinct `otlp-http-json` reference-service telemetry adapter (#336):
  checked configuration and host replay select OTLP/HTTP JSON-Protobuf logs at
  `/v1/logs`, with strict full-success response handling and no webhook
  signature alias. Four focused config, mapping and delivery checks passed
  locally. SQLite/PostgreSQL storage and physical OCI execution remain open.

- Authenticate read-only terminal recovery for source-owned waits (#330):
  reopening the real journal with retained registration and an explicit host
  grant returns copied terminal status and evidence only after the complete
  terminal row. The real-chain success and terminal-prewrite refusal selectors
  passed locally. Multi-turn public delivery remains open.

- Complete the catalog-normalizer maximal application gate at the original
  100,000,000-step bound (#324). Bounded owned-buffer stores, a scalar writer
  cursor, validated quantity lookup, and one-pass label layout preserve the
  frozen oracle, target parity, and capacity ceilings. The complete local
  selector passed across interpreter, native C11 `-O0`/`-O2`, and Core Wasm.

- Carry the actual turn-1 Step through transfer reservation, physical field
  move, completion and terminal Transition ACKs (#330). The corrected
  real-chain transfer selector passed locally. A private owner-backed
  `TerminalSnapshot` writer and fold join passed both the success and
  prewrite-fault selectors locally. Public entry, delivery and recovery remain
  open.

- Add an opt-in packaged reference-service OCI runtime journey (#336): an
  offline layout can be imported into local Podman with explicit state,
  outbound, secret, and bundle mounts, then exercise auth, task/job mutation,
  restart, and no redispatch. Separate `Entrypoint` and default-port `Cmd` so
  an operator-selected port replaces the default. Structural packaging tests
  passed 3/3 locally; the Linux Podman runtime selector still needs a trusted
  static Linux executable and has not run on this macOS host.

- Restrict the Windows doctor confined child to its three declared standard
  handles through an explicit process handle list (#333). Add a selected
  inheritable-sentinel child probe, raising the provisioned runtime selector
  to 17 cases. The gate self-test and source formatting passed locally;
  native Windows execution and exact launched-byte binding remain open.

- Carry the real continued Step cleanup-start owner through the existing
  physical cleanup engine and durably ACK its actual settled receipt (#330).
  Success and receipt-prewrite fault real-chain selectors each passed locally;
  a failed append retains the released owner and cannot release twice. Result
  transfer, public entry, and restart recovery remain open.

- Close the reference-service authenticated-route clock boundary (#336):
  unknown route and method shapes now refuse before acquiring a session clock,
  and exact idle/absolute expiry selects only the checked terminal session
  transition before any protected route mutation. The five-case focused
  session selector passed locally; broader service acceptance remains open.

- Append the real turn-1 `OwnedReduceCleanupStarted` row after the continued
  Step ACK while retaining its evaluated owner and spent Reduce hold (#330).
  Focused success and prewrite-fault real-chain selectors passed locally;
  physical Step cleanup, result publication, public entry, and recovery remain.

- Append the first real continued turn-1 Step ACK under the retained physical
  owner and spent Reduce hold (#330). The focused success selector passed;
  the corrected prewrite-fault selector also passed. Later Step phases, public
  entry and recovery remain separate gates.

- Route reference-service task creation through checked
  `create_is_committed(0)` before task ID allocation or candidate state (#336).
  Generated-source parity and denial/evaluator-failure nonmutation passed 2/2
  focused selectors; broader service acceptance remains open.

- Charge cleanup-replay skeleton preflight by actual reachable block
  transitions and edges instead of a global widest-transition multiplier
  (#324). Two focused bounds tests passed and the candidate catalog conversion
  cleared `SPX-H006`; the unchanged 100M catalog selector still returned
  `FuelExhausted`, so catalog acceptance remains open.

- Consume the real continued Outcome once after the turn-1 Reduce reservation
  ACK and run the existing checked reducer under the retained spent hold
  (#330). The private real-chain selector passed 1/1 with full Step facts,
  unchanged accounting, one host call, and no synthetic Step row. Durable Step
  ACK, public entry, and restart recovery remain open.

- Route reference-service task deletion through checked
  `delete_is_committed(0)` before candidate state or snapshot commit (#336).
  Generated-source parity, denial, evaluator failure, and nonmutation passed
  two focused local selectors; remaining service routes and OCI execution stay
  open.

- Refuse a tampered semantic-work event during metered migrated durable
  recovery before a new host call or checkpoint commit (#327). The focused
  Runtime-facade regression passed 1/1 locally; the full parity and sanitizer
  profile remains open.

- Route reference-service task status updates through the scaffold's checked
  `update_is_committed` decision before candidate state or snapshot commit
  (#336). Source denial and evaluator failure leave the committed state
  untouched; the two focused service selectors passed locally.

- Bind the private owned-wait v8 continued physical State/Outcome handoff to
  its actual successful Decision CleanupSettled ACK (#330). The one-use pending
  effect holder is consumed under fresh source, policy, clock, and cancellation
  checks before turn-1 Reduce reservation; failure retains the reached owner
  and cannot repeat Decision release. The focused Outcome selector passed 1/1
  locally; public entry, Step, and restart recovery remain open.

- Exercise the reference service from an independently copied development
  package through local register/login/task/job/restart and refusal paths;
  canonicalize owned temporary roots before Project v1 checks (#336).

- Reject migrated durable target receipts whose semantic fuel exceeds the
  declared limit or claims exhaustion before consuming that limit (#327).

- Route new immediate reference-service job enqueues through the checked
  scaffold's `enqueue_is_legal` decision, with source denial and evaluator
  failure leaving committed state and outbound work untouched (#336).

- Add offline reference-service packaging for operator-selected development and
  static Linux OCI executables, with a digest-bound copy, real project/config
  preflight, deterministic OCI layout, and bounded refusal tests (#336). Runtime
  installation and container execution remain pending.

- Add the private one-or-five owned byte-buffer primitive for #324. Its wide
  path reads five ordered bytes from an authenticated distinct borrowed source
  and zero-fills absent source positions; its one-byte path never reads that
  source. The catalog source conversion was reverted after it exceeded the
  replay preflight budget, so the original 100M catalog acceptance remains
  open.

- Add the private owned-wait v8 continued Decision cleanup driver (#330). It
  durably records Started, executes the explicit cleanup observer once, and
  records the sticky Settled receipt while retaining the reached owner on every
  failure. The focused real-chain selector passed 1/1 locally; public entry and
  restart recovery remain open.

- Durably ACK the private owned-wait v8 turn-1 Reduce reservation after
  continued Decision cleanup (#330), advancing its hold from CleanupSettled to
  SpentReduce once. The focused real-chain selector passed 1/1 locally with no
  extra host dispatch or cleanup; Step, public entry, and restart recovery remain open.

- Add the internal Owned Bounded Byte Buffer v2 `bytes_set5` operation (#324).
  It preflights one contiguous five-byte interval before the canonical owner
  transfer. Its focused language and Core Wasm selectors passed locally; the
  unchanged 100M catalog application gate remains open because the attempted
  source conversion exceeded the fixed workspace graph builder budget.

- Dispatch the real owned-wait v8 next-turn effect through an explicit host
  handler once, then persist ordinary settlement and settlement-record ACKs
  (#330). The focused real-chain selector passed 1/1 locally; public entry,
  durable process recovery, and later cleanup remain open.

- Advance the real owned-wait v8 next-turn effect owner through guarded
  preparation and a durable Intent ACK (#330). The focused real-chain
  selector passed 1/1 locally with no effect host dispatch. Actual effect
  dispatch and public durable recovery remain open.

- Add a Linux held-clang ASan/UBSan gate for metered v4 Agent migration and
  durable recovery; its Linux execution remains pending.

- Bind v4 pure-migration target execution to the metered durable destination
  route (#327). Missing, unmetered, changed-fuel, and mixed held targets now
  refuse before destination handoff or host work. Two focused refusal selectors
  and same-target Interpreter, held native, and held Core Wasm recovery
  selectors passed locally; sanitizer and full-profile acceptance remain open.

- Advance the real owned-wait v8 next-turn authorization into two durable
  effect ACKs through promotion (#330). The focused real-chain selector
  passed 1/1 locally. Actual effect dispatch and public recovery remain open.

- Cover the migrated runtime's metered durable recovery on the same
  caller-held native target (#327). The focused selector passed 1/1 locally
  with receipt pairing and zero retained host-work redelivery; mixed target
  refusal and full acceptance remain open.

- Cover the migrated runtime's metered durable recovery on the same
  caller-held Core Wasm target (#327). The focused selector passed 1/1
  locally with receipt pairing and zero retained host-work redelivery;
  mixed target refusal and full acceptance remain open.

- Expose an explicit metered durable route on fresh and resumed migrated
  runtimes (#327), binding stage semantic-work evidence to a distinct
  migration root. The focused same-Interpreter recovery selector passed 1/1
  locally with no retained host-work redelivery. Cross-target acceptance
  remains open.

- Advance the real owned-wait v8 next-turn Completed owner through five
  durable authorization ACKs (#330), including transfer at the second and
  guarded stage entry at the fifth. The focused real-chain selector passed
  1/1 locally. Effect execution and public recovery remain open.

- Add a crate-private migration-seeded durable metering route (#327) that
  retains authenticated per-stage semantic receipts across recovery. The
  focused seeded interpreter selector passed 1/1 locally and verifies no
  redelivery of retained host work. Public migrated runtime association
  remains open.

- Durably ACK the owned-wait v8 next-turn Completed row after the single
  resumed-program entry (#330). The real-chain selector passed 1/1 locally;
  authorization and public multi-turn recovery remain open.

- Advance a real owned-wait v8 next-turn Model holder through Usage and
  Resume-reservation ACKs before one actual resumed-program entry (#330).
  The focused selector passed 1/1 locally. Completed-row publication,
  authorization and public recovery remain open.

- Dispatch a real owned-wait v8 next-turn Model request once and durably ACK
  its settled response before Usage or Resume (#330). The focused selector
  passed 1/1 locally with one provider start, one Settled row, and no source
  resume. Public multi-turn recovery remains open.

- Select completed-job retry refusal through the checked source terminality
  decision (#336), with an explicit mapping from persisted reference-service
  states to durable-job codes. The focused completion selector passed 1/1
  locally and verifies no second outbound marker on retry.

- Gate reference-service registration through the checked source admission
  decision (#336) before password work, using the live account count, persisted
  capacity and selected Argon parameters. Focused capacity refusal and
  existing successful register/login route passed 1/1 each locally.

- Advance the real owned-wait v8 next-turn Prepared owner through one checked
  Model intent and durable Model acknowledgement (#330). The focused selector
  passed 1/1 locally and proves no provider construction or source resume at
  this boundary. Dispatch and public multi-turn recovery remain open.

- Gate reference-service completion delivery with the checked source export
  policy (#336), using the canonical signed-event length and configured
  telemetry origin before any outbound attempt. Focused refusal and existing
  successful completion routes passed 1/1 each locally. OCI and remaining
  service decisions remain open.

- Advance a live owned-wait v8 next-turn Start owner through its sole source
  entry and durable Prepared acknowledgement (#330). A real-owner selector
  passed 1/1 locally, including single-entry and holder-release checks.
  Model dispatch, later turn completion, and public restart recovery remain
  open.

- Cover the reference service's source-selected absolute session expiry (#336):
  a focused host regression verifies the checked state transition, persisted
  terminal state, HTTP refusal, and replay stability (1/1 locally).

- Advance a real owned-wait v8 `Step::Continue` holder through its State and
  next-turn Observe journal acknowledgements (#330), retaining the unique
  live owner on each failure path. The focused real-owner selector passed 1/1
  locally. Later turns and public restart recovery remain open.

- Route reference-service idempotent enqueue through the scaffold's checked
  scalar decision (#336), removing the Rust truth-table mirror. Focused
  decision admission, source/host parity, and actual enqueue selectors passed
  1/1 each locally; the project formatter check passed. Remaining service
  decision paths and OCI execution remain open.

- Authenticate a recovered owned-wait v8 journal before admitting a fresh
  first-turn State (#330). A real held-store restart regression verifies that
  an existing prepared prefix refuses reinitialization, preserves the exact
  journal bytes and sequence, and keeps the reopened lease valid. The focused
  selector passed 1/1 locally; multi-turn public recovery remains open.

- Make the reference service's narrower database contract explicit (#336):
  checked configuration and independent host requests reject SQLite,
  PostgreSQL, and DSN selections with stable diagnostics. Snapshot remains
  the named durable state profile. Focused source tests passed 8/8 and the
  process-level pre-write refusal passed 1/1 locally; SQL support and the
  runnable OCI route remain open.

- Add #327's explicit metered durable typed-effect checkpoint profile. The
  caller-trusted store retains hash-chained stage receipts; recovery validates
  retained deterministic work, appends newly charged replay receipts, and does
  not redeliver retained host effects. Focused metered recovery evidence passed
  4/4 and ordinary-route crossover refusal passed 1/1 locally. Digests bind
  bytes and grant no cryptographic authority.

- Cache immutable owned-wait capacity maxima under exact checked-binding
  identity (#330). The focused cache reuse and crossed-proof refusal regression
  passed 1/1 locally; continued lifecycle acceptance remains open.

- Bind the reference service's accepted `semaprax-json-events` telemetry
  profile to the closed `semaprax.json-event.v1` completion envelope and its
  fixed `/v1/events` route. The generated configuration still admits only
  `snapshot` plus that telemetry profile and refuses SQLite, PostgreSQL, DSN,
  and OTLP selections. Focused event and scaffold selectors passed 1/1 each
  locally; no hosted, OCI, SQL, or OTLP support is claimed.

- Record the Windows doctor #333 binding decision and native mechanism/corpus
  plan. Reject advisory oplocks, repeated hashes, byte-range locks and an
  unproven copy/reopen transition as exact image-binding repairs. Image-section
  exclusion, request/bundle transport and resource/handle corpus work remain
  open; this documentation change adds no execution or support evidence.

- Correct the historical effect-capacity phase regression (#330) to assert
  distinct exact Reduce and Decision-observer State cleanup reserves. The
  observer branch checks typed authenticated widths, legal cleanup edges,
  premature/wrong-status Stop refusal and failed-State-observer quarantine.
  The old equality predated the separate observer closure; production capacity
  and the fixed-row cache are unchanged. The strengthened selector is unrun.

- Memoize the three immutable v8 effect-room aggregates (#330) through their
  existing canonical serializers. Compiler-dependent cleanup, current closure,
  authenticated inventory and physical checks remain live. Fixed-prefix parity
  and malformed-cleanup refusal coverage is added but unrun; timing remains
  unverified.

- Retain the immutable cumulative v8 fresh-turn capacity forecast under exact
  context and checked-proof identities (#330), avoiding repeated maximal
  checkpoint and effect-result template serialization. Current prefix and
  physical checks still run. Added parity and refusal tests are unrun; no
  speedup or owned-Agent lifecycle acceptance is claimed.

## 0.7.0 — 2026-10-01

This alpha candidate gathers development work since v0.5.0: checked session
endpoints, private owned-Agent continuation and cleanup, local package and
resolver work, and host/tooling repairs. The completion matrix remains the
authority for executable support; local or private evidence does not become
public support through a release tag.

- Preserve the selected host failure and physical authority-loss retirement
  when cancellation and lease corruption coincide during continued
  owned-effect dispatch. Keep the
  refused authorization proposal fixture in canonical wire order, and check
  failed cleanup against its own reserved capacity edge.

- Repair main CI regressions in the example index, Rust formatting and module
  budget, Unix-only owned-wait test selection on Windows, the desktop linker
  pin, generated-package Cargo coverage, generic Wasm entry-wrapper count,
  and sanitizer omission-control cleanup. Keep the browser fixture's exact
  revision mismatch visible for the next hosted run. Follow up on hosted Clippy
  diagnostics for owned-wait context matching and private phase visibility.
  Restore the owned-wait outcome visibility required by parent modules and
  accept the three exact linker builds observed on hosted Windows runners.
  Keep platform-independent owned-wait tests active on Windows while limiting
  tests that require the Unix physical lease fixture to Unix; resolve the
  hosted Clippy diagnostics in workspace and catalog acceptance tests.
  Retain cross-platform settlement test helpers, refresh the browser
  baseline's exact graph digest, and admit the shared workspace fixture in
  the offline package test harness.
  Resolve native-host rustdoc links on Windows and remove redundant explicit
  targets from the reference-service documentation.
  Keep the generated TypeScript fixture aligned with its ABI-version field,
  and send large native parity inputs through bounded stdin framing so the
  full 64 KiB cases run without exceeding process argument limits.
  Select the native ASan/UBSan hostile corpus only on its documented local
  macOS arm64 target; the hosted sanitizer lanes keep their separate gates.
  Refresh the browser rename fixture's exact graph digest after hosted
  generation exposed its current known answer.
  Index the Kernel-0 accepted-revision validation document and highlight the
  session-protocol `endpoint` keyword in the VS Code grammar.
  Give the Source Agent owned-wait contract a separate audience field and
  catalog entry so the documentation gate covers it.
  Use a checked length conversion for the native parity probe's bounded
  stdin frame on 64-bit hosts.

- Refresh workspace artifact known answers for the current deterministic
  projections. Correct the bounded complete Semantic Impact JSON so embedded
  workspace review evidence matches the direct single-file report exactly.

- Repair Windows unit CI fixtures: gate native stage parity tests on the
  supported process hosts, use the current snapshot and JSON-event host
  adapters, retain the source entry in the checked-cache reuse test, and
  refresh the pinned agent skill bundle for the current diagnostic catalog.
  Resolve the compact CLI's plain-project test fixture from either package
  manifest so the root and full-toolchain binaries test the same project.


- Add a closed acceptance-record format for #328's Kernel-0 rung-2 decision.
  It requires every local receipt to bind to one selected revision or an exact
  unchanged subject, keeps all rows pending, and separates an eventual reviewer
  decision from historical local counts and hosted evidence. No gate was run,
  and rung 1 remains the only accepted rung.

- Add a read-only validator for #328's accepted-revision record. It enforces
  canonical record bytes, the complete ordered receipt inventory, immutable
  commit bindings, and byte-exact declared-subject reconciliation including
  `Cargo.lock`; success and drift/inventory refusal regressions are present but
  unrun. It cannot run receipts or validate a rung-2 promotion.

- Connect actual continued owned-Agent Decision cleanup to the existing v8
  fixed append and physical release path (#330). Preserve the same State,
  reservation hold and accounting across Started/Settled, cancellation and
  observed release failure. Continued Outcome/Reduce, public execution and
  restart recovery remain unfinished. Compilation passed; bounded test runs
  were interrupted without completed results, so this increment is unverified.

- Add partial signed-image checks to the standalone Windows doctor spawn using
  held NTFS file/path guards and a retained advisory read oplock (#333).
  Preserve the ten historical native cases and add six substitution/settlement
  cases. Writable-section mutation can still race; exact binding acceptance,
  native Windows execution and request/bundle transport remain open. No
  production or release-trust support is promoted.

- Retain catalog-normalizer's 100,000,000-step maximal-response requirement
  (#324) in the complete application selector. Its one-call scalar phase
  encoder omits redundant per-byte token-length, terminal-shape and enrichment
  arguments; the bounded fixture outcome is represented only in the enriched
  tail phase. Record the 160,000,000-step library ceiling only as the current
  execution capacity and retain the separate 2,000,000-step source-suite
  bound. The frozen oracle, corpus, response capacity, mutation controls and
  backend lanes are unchanged.

- Add the explicit `endpoint Bytes` session profile, connecting checked protocol
  order to a unique source carrier through local moves and terminal consumption.
  Refuse stale aliases, use after close, replacement carriers and escapes before
  backend emission; preserve the existing declaration-only profile.
- Pass all eight source/HIR/graph/cache and interpreter/native O0/O2/generated
  Wasm endpoint success and terminal-failure settlement tests locally at
  `c714e7c6c` on 2026-09-30. Endpoint/compiler/backend paths remain unchanged
  through `e9019e9e1`; that later comparison is source equivalence, not a new
  execution receipt. [Session Protocol Types v1](docs/SESSION-PROTOCOL-TYPES-V1.md#local-execution-receipt)
  records the command, scope, and separately pending legacy preservation and
  broader integration evidence.

- Add an opt-in local Ollama specialization runner for #326 around the frozen
  control schedule and scorer, with public-only prompt projection, exact model
  pins, explicit independent-review gates and immutable outcome receipts.
  Keep the unresolved discount cells unavailable; synthetic tests and offline
  receipt checks are not actual model execution or experiment acceptance.

- Add #326 read-only specialization cell accounting using the existing v1
  protocol. Retain the original 81-cell inputs byte-for-byte from `ebe4235e`,
  distinguish today's nine added cells and oracle drift, and report every
  missing authority, unexecuted outcome and unrecorded independent review.
  No provider or training work is dispatched; the experiment remains blocked.

- Resolve comparison-adapter scope #322 through explicit exclusions: retain
  only the already-admitted official TypeScript v3 lane, without promoting
  local fixtures. Add a read-only, source/correction-bound support inventory
  and offline regression gate preserving all 182 task/adapter rows. Correct
  stale status prose while retaining the original 54/54 execution subject.
  No executor, scorer, frozen source, wire profile or resource bound changes.

- Reconcile generated-package support decision #325 with ADR 0003: retain
  ordinary owned-data Rust-only maintenance, the fixed unpublished preview
  identity and five-target boundary, and real SemVer before any future publish.
  Distinguish genuine Rust/npm consumer and exact local MSRV evidence from npm
  maintenance, public promotion, publisher identity and release provenance.
  npm remains deferred to its own ADR; no publication or machinery change.

- Add private continued Transfer and Authorize transport into actual Granted or
  Refused Staged outcomes, retaining the same token, ledger and measured source
  consumption. Owning runtime gates and full public execution remain pending.

- Add private continued model SDK settlement and Resume transport through actual
  durable ACKs, retaining authenticated accounting and the same spent token.
  Owning runtime gates, next authorization and full public execution remain pending.

- Add private fresh-cell acquisition certificates and native host custody,
  rollback and retirement on the existing owner registry. Owning runtime gates
  are pending; source endpoints and interpreter/Wasm admission remain unfinished.

- Add private continued Start and Prepared ACK transport around the actual
  retained owner and existing evaluator, preserving its ledger and hold.
  Owning runtime verification and the next real SDK exchange remain pending.

- Add private actual failed-Observe State cleanup ownership, per-action release
  capture and fixed durable ACK transport. Owning runtime verification and
  public lifecycle acceptance remain pending.

- Add private actual Decision-observer State cleanup through a monotonic seal
  and fixed ACKs, plus retained continuation preparation foundations.
  Integrated runtime verification and public lifecycle acceptance are pending.

- Add private initial and continued Observe settlement producers with actual
  State provenance, evaluator consumption and fixed durable ACKs. Owning
  integration verification and cumulative lifecycle execution remain pending.

- Add private actual Continue State/Observe ACK carry and irreversible observer
  cleanup-seal foundations; retain static Reduce capacity templates per exact
  Context. Cumulative physical execution and integration gates remain pending.

- Retain immutable checked Reduce proof per invocation and add private actual
  failed-target State disposal through fixed durable ACKs with unchanged
  accounting. Focused integration verification remains required.

- Add private owned-wait v8 authenticated effect history, retained-container
  append checks and physical effect/reducer ownership foundations. Fresh
  initialization uses exact typed Task and acknowledged stage reservations;
  historical data cannot mint owners. Actual held Authorize/Consumed/Intent
  ACKs now preserve the same owner and exclusive future-Reduce credit through
  consuming host dispatch, settlement/Recorded ACKs, physical Decision cleanup,
  and guarded Outcome handoff with retained invocation accounting. Actual reducer
  stages expose inert compiler-checked Step/failure facts and observed fuel.
  Original Reduce now spends that same hold only at its actual full-F reservation
  ACK and enters the existing evaluator with the actual State and Outcome roots.
  Public owned Agent execution and durable recovery remain incomplete; full integrated
  acceptance is pending.

- Add candidate embedded ordinary Agent operation bodies and same-module model-wait helper associations, with original-source replay before checked HIR cache reuse. Source graph v50 and workspace/package graph v4 preserve their selected legacy bases and carry descriptive execution associations. The owned Agent lifecycle remains incomplete; integrated acceptance gates are pending.

- Add an opt-in interpreter model wait through one combined Source Live v7
  journal, with checked Copy carriers, precharged evaluation/replay, crash
  recovery, and exact joined evidence. Migrate an explicit offline repair
  example through the public route; retain existing SDK malformed-response
  failure and frozen journal profiles. Full owned Agent state remains open.

- Extend the local public-generic settlement corpus with versioned physical
  input/result commit and result-root acquisition failures, strict Rust error
  category checks, and an opt-in complete artifact/provenance inventory.

- Add an opt-in held-target selector for the v2 in-memory migrated Agent
  continuation. Interpreter, native C11, and Core Wasm retain the same
  migration result and reservation accounting; backend instruction counts
  remain distinct in evidence. Pure migration evaluation and general durable
  metering remain interpreter-selected.

- Admit bounded Copy-only record or variant parameters and results through a
  separate sequential interpreter `yields` entry point. Bind aggregate
  arguments to replay, preserve the existing scalar API and bounded Bytes
  request channel. Add a distinct aggregate durable invocation with a v2
  authenticated journal and v7 checkpoint, checked answer refusal before
  append, and success/failure crash recovery tests. The Agent-operation
  bridge remains open.

- Carry one direct sequential `yields` request with bounded `Bytes` leaves
  through interpreter suspension, a v6 authenticated checkpoint, and the
  durable journal. Reject a second Bytes request site and Bytes responses at
  checked admission; Agent operation migration remains open.

- Add an opt-in public Agent live target route that records bounded semantic
  work, ordered cleanup events, and settlement for interpreter, native C11,
  and Core Wasm stages through the sealed dispatch. Focused local parity tests
  cover the selected backends; durable routes retain reservation accounting.

- Reject missing, empty, or byte-identical hidden overlays before scoring
  cross-language benchmark tasks, including caller-supplied inventories.
  Fixed scoring, agent scoring, and dry-run planning share the preflight;
  invalid fixtures cannot invoke the solver transport or produce a false
  hidden-test success. Same-path replacements remain supported. This is
  structural fixture validation, not a test-coverage or model-quality claim.

- Add caller-held native and Core Wasm selectors to durable Agent checkpoint
  and checked migration execution. Both reuse the existing journal, preserve
  target-neutral checkpoint identity, and refuse unavailable retained Wasm
  source before a migration handoff is staged. Local parity and refusal tests
  cover the new route; hosted target evidence remains open (#293).

- Share cleanup-plan replay skeleton observations behind `Rc`. Sequencing a
  path prefix with each suffix deep-copied every identity and place, so a
  function with tens of thousands of paths materialized gigabytes: the
  catalog-normalizer test's `tests.main` enumerates 65,533 paths and is
  replayed 37 times per project authentication. Budget charges, sorting and
  comparison are unchanged. Locally the
  `catalog_normalizer_application::batch_boundaries_and_string_normalization_agree_across_backends`
  test drops from 862 s and 6.51 GiB peak to 210 s and 0.71 GiB; on hosted
  Windows it had exceeded the six-hour job limit.
- Run all twenty-six AArch64 offline-doctor lifecycle fixtures against real
  carriers (#334). `doctor-provisioned-linux-aarch64-carriers.sh` provisions
  pinned Clang 17.0.6, Node 22.23.2 and Rust 1.88.0 and bundles them with the
  packager's new explicit `--architecture aarch64`; the lifecycle driver now
  requires those inputs instead of probing for their absence. The AArch64
  syscall rows gain the traced Node and rustc `fcntl` rules, rustc's `ppoll`
  and `pipe2`, and its exact pthread `clone`. 26/26 passed locally on native
  AArch64 (Linux 6.18.35 with `CONFIG_PROC_CHILDREN`); not hosted, not a
  signed-release gate.
- Move the isolated Component runtime runner to Wasmtime 48.0.3 for
  RUSTSEC-2026-0315 and RUSTSEC-2026-0316, which failed its `cargo deny`
  advisory audit. 49.0.1 carries the same fixes but breaks the runner's
  same-Store recovery after a refused call, so it is not adopted here.
- Split the longest CI legs. `verify-tests` gains `integration-5`; the Unix
  source-repair matrix runs two shards that `ci-msrv.py --repair-shard` fills
  round-robin from the listed cases; Windows repair cases leave the Windows
  unit shard for a dedicated `windows-source-repair` blocker; and AGENT-06
  runs its `lifecycle` and `revisions` halves as separate legs, which together
  had reached the six-hour job ceiling.
- Carry `$ORIGIN`-resolved libraries in the doctor bundle's system library
  directory (#320). The confined root has no `/proc`, so the loader never
  expands `$ORIGIN` and real rustc exited 127 before `main`; the same
  inventory now starts `rustc --version` in a `/proc`-less root locally.
- Let the confined x86-64 rustc doctor role start the Ctrl-C watcher thread
  that rustc 1.88 requires (#320). Its `clone3` now returns `ENOSYS` so glibc
  falls back to `clone(2)`, admitted only for the exact pthread flag word;
  Clang, Node and AArch64 keep denying both. Local evidence is the BPF-oracle
  suite on Linux; the real-carrier gate has not yet been rerun.
- Give Linux source-repair tests the same dedicated blocking lane as macOS,
  preserving once-per-host coverage. Author the UTF-8 capacity fixture from a
  formatter-pinned canonical template so setup does not replay proof-only
  scalar renderers for each of its 25,000-plus characters. Keep all three
  capacity boundaries, Project authentication, artifact replay, publication,
  and independent Node byte checks; add phase timings for timeout diagnosis.
  Meter npm recipe String literals under the existing 1 MiB bound so their
  source writer uses the bounded Rust-authority path without changing bytes
  or bypassing recipe/HIR replay.

- Repartition slow macOS repair and Windows agent-runtime tests into distinct
  release blockers without duplicating their coverage. Use a real macOS Git
  executable for publication tests, keep unsupported Windows stage hosts
  fail-closed, correct a Linux offline-worker fixture, and speed up the two
  independent macOS desktop reproducibility builds.

- Restore source-locked test coverage after recent HIR, graph, scaffold, and
  workspace-graph splits. The tests now bind the new submodule text or verify
  its quality-route classification; the existing coverage threshold is not
  raised.

- Continue the concise documentation rewrite through the language tour,
  development guide, agent protocols, project manifests, and design decisions.
  Clarify that the workspace generation pivot is atomic visibility, not by
  itself power-loss durability, and update the historical Graphify ADR to the
  current Graft navigation workflow.

- Compose the local, caller-authorized mirror-to-held flow with the existing
  signed resolver-cache bridge and deterministic Resolver-v2/Lock-v3 root/leaf
  replay. Cache reads are bounded, receipt-named and held nofollow reads; cache
  partial effects remain distinct from pre-effect, held-publish-uncertain and
  receipt-bearing post-commit outcomes. This is local evidence only and adds
  no hosted registry, ambient network/cache, installation or execution support.

- Rewrite the documentation entry path—overview, install, quickstart, CLI
  guide, and first contribution—in shorter task-based language for new
  developers. Preserve the tested commands, diagnostic examples, and
  versioned contracts; update the v0.6.0 release-gate status without claiming
  publication.

- Remove a stale coordinator-only ABI handoff and deduplicate the 0.3.5/0.2.0
  changelog history, retaining the full older record in the linked archive.

- Record exact-job, old-head partial hosted evidence for the in-progress
  v0.6.0 tag gate without promoting it to a signed or published release.

- Compose caller-authorized bounded mirror bytes through signed Registry-v3
  proof, a held-generation-v3 authenticated timestamp-age anchor and one live
  Lock-v3 artifact read. Resume state is derived from the live held generation,
  not caller checkpoints; identical timestamp replay retains the original
  observation and a newer signed timestamp is the only anchor advance. v2
  history remains readable with no automatic migration. Receipt-bearing
  post-commit read or confirmed-pivot uncertainty remains distinct from
  no-effect refusal; lower held-publish uncertainty carries no receipt. This
  is local evidence only; it adds no hosted registry, resolver-cache, root,
  filesystem or execution authority.

- Allow the unchanged GEN-05B hosted generic-instance corpus enough job time;
  the v0.6.0 release gate reached its former 90-minute ceiling before the
  authored-variant and owned-result checks could finish.

- Persist and restore semantic caches for admitted Projects whose bundled
  standard-library closure exceeds the authored-source manifest limit. The
  private snapshot now validates the complete bounded source inventory before
  warm replay; no source or cache authority is widened.

- Reduce repeated catalog-normalizer control-escape work within the admitted
  Project graph budget. Fifteen independent-oracle cases pass across the
  interpreter, native C O0/O2 and Core Wasm; the exact 256-record maximum
  remains unproven under the unchanged fuel limit.

- Compose acquired exact mirror metadata through Registry Trust v2's signed
  timestamp/snapshot/publisher-manifest verifier and its existing rotation,
  revocation, expiry and checkpoint controls. The local mirror policy refuses
  a follow-up update after seven days without a checkpointed timestamp; this
  remains local proof, not hosted distribution support.

- Add a capability-explicit native HTTPS registry-mirror byte acquisition
  boundary. It accepts only caller-named origin-relative digest-bound metadata
  and artifact paths with disabled proxy discovery, credentials, redirects and
  retries; returned bytes still require the existing signed Registry-v3 and
  held-store admission flow. Local scripted transport controls are not hosted
  registry, TLS-peer, availability or production evidence.

- Steer agents to the cheapest sufficient semantic command. The repository
  guide now orders `query`, `doc`, `context`, then `graph`, with the measured
  cost of each step on the committed examples: one line per declaration,
  roughly the source bytes, a caller-chosen byte budget, and roughly forty
  times the source bytes.

- Attach an actionable hint to the `compact api-surface` refusal on projects
  without the owned-data-api.v1 profile. The `SPX-J105` diagnostic keeps its
  code and message and now points at `semaprax doc` and `semaprax query`;
  a CLI regression test pins the hint on the committed calculator project.

- Point the agent command ladder at `doc --json` for machine consumers. The
  contracted `semaprax.doc.v1` skeleton carries signatures, contracts, and
  identities at roughly the source bytes, eighteen to thirty-four times
  smaller than the full graph on the measured examples.

- Merge the pending Dependabot bumps (`wasm-encoder`/`wasmparser` 0.259.0,
  `argon2` 0.6.0, `x509-cert` 0.3.0, `rustix` 1.1.5, `reqwest` 0.13.5, the
  pinned `dtolnay/rust-toolchain` action, and `actions/upload-artifact`
  7.0.1; #264-#267, #311-#313) and fix the resulting API breaks (x509-cert's
  private `tbs_certificate` field, argon2/password-hash 0.6 APIs, wasmparser
  wire pins and KATs). Admit the transitional duplicate versions these bumps
  introduce in `cargo-deny` (`deny.toml` skips for `x509-cert@0.2.5`,
  `der@0.7.10`, `der_derive@0.7.3`, `spki@0.7.3`, `base64@0.22.1`) and
  refresh the five standalone lockfiles the bumps left stale.

- Pin single-runner CI jobs, and the Android JNI matrix entries, to
  `ubuntu-24.04` ahead of GitHub's `ubuntu-latest` migration to Ubuntu 26
  (2026-10-19). The six three-OS matrices keep their `ubuntu-latest` matrix
  value, so required check names such as `Rust ubuntu-latest` are unchanged;
  only `runs-on` resolves to `ubuntu-24.04`.

- Prove the compiled public-generic Core Wasm provider's own ABI hostility
  through the generated TypeScript consumer (#287): call-after-close, an
  over-capacity/out-of-bounds declared length, a byte-mutated canonical
  frame, export-before-call, release of a foreign/stale/already-consumed
  handle, double release, and a handle foreign to a second simultaneously
  live instance all refuse at the provider's own exact status with no
  leaked handle and no duplicate dispatch. The regression drives the real
  compiled `WebAssembly.Instance` through an intercepted `instantiate`,
  never a hand-written re-read of `instance.exports`; the shipped generator
  template is unchanged. Local, proof-only evidence; no PG-9 or support
  decision changes.

- Fix four defects the differential harnesses found in the compiled
  public-generic Core Wasm provider (#288): a stubbed owned-byte runtime
  that trapped on any allocating subject (`bytes_copy`/`bytes_zeroed`/
  `bytes_set`) now has a real invocation-local implementation; `input_prepare`
  no longer grows linear memory before the carrier frame is validated; the
  input-payload window moved off the input aggregate record into its own
  128 KiB region, fixing a silent overwrite of combined payloads above
  2 KiB while the call still reported success; and the provider now emits
  Wasm adapter ABI v2, reporting a semantic carrier-replay failure as its
  own raw status 14 (`SPX-PG803`) instead of collapsing it to raw 5.
  `result_export`'s destination pointer/length is now bounds-checked before
  the memory copy (status 13), and the classifier's baked-in leaf count is
  const-asserted against the endpoint's actual leaf count so the two can no
  longer drift apart silently. Local, proof-only evidence.

- Execute one closed, versioned settlement-matrix corpus
  (`semaprax.public-generic.settlement-matrix.v1`, 14 cases over the checked
  `Pair<Bytes>` identity/refusing/allocating subjects) across the retained
  interpreter, raw authenticated native C11 (O0/O2 plus local ASan), the
  compiled Core Wasm provider, and the generated C11/Rust/C++17/TypeScript
  callers built from the same descriptor bytes (#301). Each engine reports
  one receipt per case/cycle (primary/secondary status, returned bytes,
  dispatch count, live/peak resources, physical release order); the harness
  asserts an exact, non-vacuous 126-cell split. Following #288's provider
  fixes, the matrix's former 8 known-defect cells now pass: 105 pass, 0
  known-defect, 21 documented not-applicable. Local, proof-only evidence.

- Add a Wasmtime 47.0.4 differential-conformance submodule to the private
  Component runner (#292): the reference interpreter, the standalone
  compiled Core Wasm provider, and the typed Component must agree on
  returned leaves for two checked-in projects (a non-identity leaf swap,
  and `requires false`), including stale-Component and stale-descriptor
  refusal before instantiation, Core open refusal of a stale descriptor,
  resource-arena recovery after both success and failure, and an
  oversized-list trap followed by fresh-instance recovery. The differential
  found the standalone provider's payload-overlap defect #288 later fixed.
  Re-pinned all four component-runtime fixtures' provider/component digests
  and raw component SHA-256 after #288 changed the compiled provider's
  bytes (each fixture's descriptor digest, a pure function of checked
  source, is unchanged); un-ignored the large-payload regression the fix
  closed. Local, proof-only evidence.

- Give Core Wasm call-depth admission equivalent to the interpreter's
  `MAX_CALL_DEPTH` and native C11's `SPX_MAX_CALL_DEPTH` (256), across both
  the aggregate byte/scalar-export emitter and the separate legacy
  scalar-core emitter (#293). Both emitters use an always-on live-frame
  counter reset at every genuine external entry, so a refused deep
  recursion cannot poison a later, shallower call on the same module
  instance; the executor-side status decode reports
  `RetainedCallOutcome::CallDepthExceeded` consistently across native and
  Core Wasm. Also add semantic fuel/cleanup metering parity across the
  interpreter, native, and both Wasm Agent Stage executors, and fix a
  macOS held-tool spawn issue. Local, proof-only evidence; the affected
  Wasm-byte pins were re-derived field-by-field for the changed private
  global.

- Replace the durable HTTP-delivery library entry point's
  whole-checkpoint-digest provisional probe with an identity-keyed
  (deployment/invocation/idempotency-key) atomic create-new intent marker,
  independent of capacity, policy, and restoration state (#295): an
  existing marker, or any create/sync/recheck error, surfaces `Uncertain`
  and never enters the adapter, and the marker commit is one atomic
  create-new with no preceding read, so concurrent fresh workers cannot
  both win. Loopback fixtures only; this remains a library entry point with
  no caller in a runnable application or service policy package.

- Add a Reference Service Host v1 (#303, `docs/REFERENCE-SERVICE-HOST-V1.md`):
  the existing service scaffold (`examples/task-service-project`) now runs
  as a real local loopback process — HTTP/1.1 serving, content-addressed
  write-once snapshot persistence, held file-backed secrets, and durable
  outbound webhook delivery over #295's identity-keyed marker — reusing
  existing decision and adapter machinery and granting no new authority. No
  SQL wire protocol (SQLite/PostgreSQL DSNs are held, never connected to),
  no TLS server provisioning, no OTLP protobuf, and no hosted or production
  support is implemented or claimed.

- Add a resumable-effects continuation contract v1 (#296,
  `docs/RESUMABLE-EFFECTS-CONTINUATION-V1.md`): a durable, fsync'd,
  HMAC-chained, single-writer (flock) journal-backed library driver
  (Unix only), extending the source-level resumable profile with
  control-dependent yields (`if`/`else` branches and `while` bodies; v3
  plan/envelope, up to 8 static sites, up to 16 suspensions; `SPX-T305`/
  `SPX-T306` refusals) and a whole owned `Bytes` local carried across
  `if`/`else`-nested yields in a v4 envelope with driver-enforced per-item
  cleanup settlement. Loop-embedded carrying is refused (`SPX-T303`), not
  silently narrowed. Native and Wasm code generation still refuse `yields`
  (`SPX-B116`/`SPX-W126`); this is a library contract with local evidence
  only, not a runtime scheduler or public continuation ABI.

- Session protocol declarations (`session protocol`) are parsed,
  canonically formatted, verified (`SPX-K101`-`SPX-K106`), and erased with
  unchanged native/Wasm bytes (#297), and are bound to their `@id`, span,
  and checked HIR `via` functions in the per-source graph
  (`semaprax.graph.v48`, declaring programs only), `context`
  (`session_protocol_kernel.declared`), Architecture Claims
  (`protocol_realizers_bound`, attesting only that `via` targets are
  checked call-graph nodes, not ordering), and Assurance Manifest v1 (a
  closed `session_protocol` obligation kind, `compiler_proved` static
  validation only; older verifiers reject such envelopes with `SPX-Z103`).
  Canonical declarations of `project-agent-session-v1` and
  `database-transaction-v1` are gated field-for-field against the kernel
  specs the two live subsystems run. Legal declaration order grants no
  runtime authority. Project semantic cache compatibility bumped to
  `semaprax.project-checked-module-hir.v2`. Fixed a stale
  `context --filters session_protocol` note that had claimed no subsystem
  calls the kernel.

- Add a Compute Kernel Profile (#306, RFC 0005): a deterministic CPU
  reference executor (`semaprax.compute-cpu-reference.v1`) for
  elementwise-map and sequential-fold kernels bound to checked functions by
  `@id`, with capability-gated owned device-buffer lifecycle, sticky
  failure selection, stale-artifact refusal, and diagnostics
  `SPX-GC014`-`SPX-GC021`. Add an optional macOS `metal-device` Metal
  backend (`objc2-metal`) for the elementwise map on `i32`/`i64` with
  dispatch-time admission parity, including a fix for a 64-bit `ulong`
  division that crashed the Metal compiler service. Local physical-device
  evidence on one Apple M3 Pro only; no hosted, multi-device, or production
  accelerator claim.

- Add cross-language runnable-adapter contract v2 (#284,
  `docs/CROSS-LANGUAGE-RUNNABLE-ADAPTER-V2.md`): C, Python, Swift and Java
  lanes with independent ports of all twelve comparison tasks (48 of 48
  pairs run `ok`, each port checked against a task-specific broken
  candidate), and real execution of the already-admitted TypeScript lane, all bounded, offline and pinned to
  exactly observed local toolchain paths and digests (local provenance only,
  never official). v1 and its Rust lane are unchanged; the six reserved
  external languages stay blocked with their recorded reasons.

- Execute the genuine compiler-built npm package journey (#290): pack,
  offline install into a clean project, strict TypeScript build, import and
  real Wasm calls, plus tampered-file, swapped-Wasm, path-traversal and
  stale-integrity refusals applied to that same tarball. The stale-integrity
  check uses an npm cache the genuine tarball never touched, because a warm
  cache masks `file:` integrity failures. Local evidence only; the npm
  support decision stays open (ADR 0003 answer 8).

- Fix Core Wasm agent stages never reporting the settlement of an owned
  `Bytes` leaf returned inside a multi-leaf variant (#293): the byte-stream
  driver did settle the leaf but returned a hex string, so no
  `CopyOutAndSettleBytes` receipt was recorded. Cleanup events are now counted
  for the selected case only, and the Core Wasm special case that accepted
  empty cleanup events in `rich_target_backends_preserve_raw_grant_and_continue_byte_payloads`
  is removed, restoring the strict cross-backend assertion.

- Make the Kernel-0 interpreter differential corpus finish (#294): each
  self-hosted canonical-token renderer (int, bool, char, operator, string)
  re-derived its fixed embedded Kernel-0 component on every rendered token.
  Renderers now derive once and reuse the program only for byte-identical
  source, keeping drift detection intact.
  `reference_interpreter_agrees_with_the_compiler_over_the_kernel_zero_corpus`
  drops from over four hours to about nine minutes locally (854 comparisons,
  0 disagreements, unchanged corpus and seed).

- Extend public-generic Component conformance (#292): native C11 -O0/-O2 as
  a fourth parity column (over an equivalent flat fixture, since native
  admission does not yet accept the nested record the other columns use), and
  mid-call fuel interruption for the Component and the Core Wasm provider,
  which traps, discards the store without publishing and recovers on a fresh
  instance. Private profile; no public-support claim.
- Record the benchmark's issue #211 category coverage, observed local
  toolchain identities and the reserved languages' provisioning needs (#298);
  the "Agent workflow" category's coverage awaits a maintainer scope decision,
  and the real two-model and second-host pilot remains open.
- Admit nested owned records on the native boundary through a new, separately
  versioned `authenticated-native-moves-nested.v1` profile (#292), with
  positional leaf-path equality against the verified descriptor and the hostile
  corpus rerun against a nested descriptor; the Component parity suite's native
  column now uses the same checked endpoint and byte-identical descriptor as
  the interpreter, Core Wasm and Component columns. `moves-v1` is unchanged.
- Extend the optional Metal backend to sequential folds and to `u8`, `usize`
  and `bool` (#306), with an order-preserving single-thread fold and a
  division-free binary long division for 64-bit unsigned `/` and `%`, covered on
  the local M3 Pro across divisor classes up to `u64::MAX`.
- Add the benchmark's thirteenth task, `iterative-repair-workflow-v1`, for the
  "Agent workflow" category (#298): two sequentially masked defects and a
  preserved sibling behaviour, ported to every runnable lane. The maintainer
  directed a dedicated task over orthogonal orchestrator coverage.
- Admit an owned `Bytes` local carried across a loop-embedded resumable
  yield when it is defined outside every enclosing `while` and never touched
  inside it (#296), on the existing v4 envelope. The per-slot check walks
  every nested expression and statement exhaustively and refuses otherwise;
  reassignment inside the loop stays refused (SPX-T252).
- Prove the composed registry path over a real loopback socket (#304): ten
  acceptance cases drive mirror fetch, held commit, signed cache and
  Resolver-v2/Lock-v3 replay through a 127.0.0.1 listener, covering clean
  reproduction, swapped artifact, tampered metadata, stale timestamp,
  rollback, publisher reassignment, yanked package, connection refusal and
  timeout, each leaving the held store unchanged. Plain HTTP test transport
  only; the mirror-flow spec now records its trust decisions and scope.
- Bind resumable `requires`/`ensures` obligations for control-dependent
  (v3/v4) functions, which previously failed obligation generation (#296).
  The Agent lifecycle migration stays open; the continuation spec records
  why no existing Agent example fits the admitted yield profile.
- Restore ordinary and migration-seeded durable Agent checkpoints across
  interpreter, native -O0 and Core Wasm in test-only routes (#293).
  Checkpoint identity no longer binds the executing backend; a mismatched
  Wasm stage source is refused explicitly. Production routes stay
  interpreter-selected.
- Project declared session protocols into the Package Semantic Graph
  (`semaprax.package-semantic-graph.v2` for declaring packages only;
  protocol-free graphs stay v1 byte-identical), the help shape catalog and
  the agent quick reference, and report protocols whose `via` targets a
  changed declaration in semantic impact/review (#297).
- Admit a resumable function whose later top-level yield follows an if/else
  when no owned value is live: the branch-join refusal (SPX-H006) now applies
  only to a genuine owned-`Bytes` join (#296).
- Serve the Reference Service Host over TLS on loopback when the operator
  holds certificate and key material (`--tls-certificate-secret`,
  `--tls-private-key-secret`) (#303). TLS 1.2+ only, no plaintext fallback;
  a request for TLS without held material is refused before bind. The full
  login/CRUD/job/restart flow and wrong-issuer, wrong-hostname, expired and
  plaintext-client cases run against a test CA. Local evidence only.
- Generate C++17 and Rust calling consumers for the
  `authenticated-native-moves-nested.v1` profile and drive them through the
  same O0/O2 positive controls and seven hostile recipes as the other
  authenticated profiles (#288). The native hostile corpus and positive
  controls for all four profiles now also run under local Clang
  AddressSanitizer and UndefinedBehaviorSanitizer on macOS arm64 with zero
  reports; LeakSanitizer is unsupported there and the live-allocation
  counters remain the leak oracle. Not hosted or Linux evidence.
- Check `.spx` endpoint typestate (#297): a function that declares
  `follows session protocol "<id>"` must call the protocol's `via` functions
  in a legal order along every straight-line and if/else path, ending in a
  terminal state (`SPX-K107`-`SPX-K109`). Loops, recursion, closures,
  indirect calls and branching `choice` continuations that reach a `via` call
  are refused rather than approximated. The clause is erased before codegen.
  The project semantic cache tag is now
  `semaprax.project-checked-module-hir.v3`. Legal order grants no authority.
- Refuse a record or variant `yields` request/response type with the
  dedicated `SPX-T307` ("aggregate yield channel not yet admitted") instead of
  the generic scalar refusal, and record the bounded aggregate shape and the
  runtime work it still needs (#296).
- Project `follows session protocol` bindings (function `@id` to protocol
  `@id`, typestate checked) into the per-source graph (`semaprax.graph.v49`,
  only for programs that use the clause), `context`, the Workspace and
  Package Semantic Graphs (`.v3`) and the Assurance Manifest as a
  `compiler_proved` call-order obligation (#297). `semaprax doc` shows the
  binding on the function and the protocol, and `semaprax query` finds it
  through the existing entry facts. A `follows` clause on a class method is
  refused (`SPX-K109`) instead of being accepted unchecked.
- Run a bounded, flat record or variant of Copy scalars (at most 8 fields,
  or 8 cases of at most 8 fields) as a `yields` request/response channel for
  top-level yields on the interpreter, the source-checkpoint driver (new
  signature-bound v5 envelope; v1-v4 unchanged) and the durable journal
  driver (#296). A `yield` inside `if`/`while` and any aggregate with a
  `Bytes` leaf still refuse with `SPX-T307`. Journal lock acquisition now
  retries briefly so a descriptor held across a concurrent fork no longer
  reports a spurious `JournalBusy`.

## 0.6.0 — 2026-09-24

- Keep the frozen private Component v7 WIT identity at `0.5.0` while the crate
  advances to `0.6.0`, and repin the version-bound public-generic Component
  known answers against independently emitted success and contract-failure
  fixtures. The four exact Component CI contract tests pass locally; hosted
  release evidence remains pending.

- Pin the Wavect GmbH release verifier to GitHub's immutable owner/repository
  OIDC subject and require matching subject and ID extensions in the verified
  Fulcio certificate. This is local offline verification, not hosted signature
  evidence until the authorized v0.6.0 tag gate publishes immutable assets.

- Observe Core Wasm record-`Bytes` copy-out only after the generated Node
  facade returns owned bytes from its settled JS arena, with strict transport
  refusal controls. Physical Wasm free, instruction-fuel parity and hosted
  target acceptance remain open.

- Project a frozen malformed-result carrier recipe through generated TypeScript
  against the compiler-produced checked Wasm provider, alongside exact
  descriptor/binding and once-only result-release controls. This is local
  compiled-provider evidence, not the full hostile or hosted R06 matrix.

- Bridge explicit held signed root/leaf generations into the existing resolver
  subject cache after fresh lock-bound artifact reads. CLI lock-bound fetch and
  the bridge share the extracted held cache writer; copied subjects carry no
  persistent signature/freshness authority and failures retain uncertain prefixes.

- Add explicit offline artifact reads from a held signed Registry-v3 generation,
  bound to exact Lock-v3 and independently admitted manifests. Reads replay
  trusted-time freshness and recheck ACTIVE before returning immutable bytes;
  no reusable bearer token, ambient path read or execution authority is added.

- Add an explicit local Registry-v3 generation store coordinating signed trust,
  full root/leaf Lock-v3 selection and exact core artifacts, with one-way v1
  migration and exact interrupted-commit recovery. Receipts remain evidence;
  no fetch/read/execution capability or hosted registry support is added.

- Add pure offline signed metadata-v2 verification for producer-backed
  Registry-v3 linked roots and leaves, exact lock/artifact checks, and a one-way
  Checkpoint-v2 protocol floor preserving prior version/digest high-water marks.
  Candidates remain non-authoritative; managed-host/fetch integration is separate.

- Add independently verified dependency-free Build-v1 leaf manifests and an
  additive producer-backed Registry-v3. A real linked root/leaf catalog now
  reproduces Lock-v3 bytes and checks exact source/report/dependency closure;
  focused tamper, yank, missing-leaf and API-claim controls pass locally.
  Existing profiles remain unchanged; trusted v3 distribution is separate.

- Add a separate private authenticated-native-allocating.v1 handoff for a
  closed checked Bytes body/callee subset. An explicit-context reservation,
  canonical lease settlement and all-leaf result preflight preserve sticky
  failure through generated C11/C++17 callers. Focused controls cover real
  allocating callees, reservation/body/postcondition refusals, oversized
  results and missing-drop/dispatch controls; the actual legacy runtime
  emitter retains its frozen bytes. General-body, cross-backend, hosted and
  public acceptance remain open.

- Add a separate private authenticated-native-moves.v1 handoff that executes
  checked flat-`Bytes` record movement bodies through generated C11/C++17
  callers. Focused physical controls cover both branches, malformed/legacy
  refusals, identity-body omission, and postcondition-failure settlement;
  allocating/status-producing bodies and public acceptance remain open.

- Add an explicit local registry trust host with held owner-private storage,
  independently pinned bootstrap, immutable signed-evidence/checkpoint and
  selected-artifact generations, one durable `ACTIVE` pivot, and exact
  fail-stop recovery. Focused local crash-point and hostile-state tests pass;
  this adds no fetch/network authority or physical power-loss claim.

- Correct catalog-normalizer JSON control escapes at `\\u0010`–`\\u001f`
  and exercise ten oracle-frozen controls across interpreter, native C and
  Core Wasm. The maximal 65,536-byte response still exhausts the unchanged
  100M-step fuel bound, so the catalog acceptance milestone remains open.
- Add a TUF-style local registry verifier with independently installed roots,
  namespace-delegated Ed25519 thresholds, dual-threshold root rotation, exact
  registry/manifest bindings, freshness, rollback and yank checks. Results are
  non-authoritative checkpoint candidates; the managed durable host above is
  separate, and trusted distribution remains open.
- Compact catalog-normalizer scalar projection helpers and avoid a repeated
  label walk when summing accepted record quantities. The 18-case focused
  interpreter/native C O0/O2/Core Wasm oracle selector passes, but the exact
  65,536-byte/256-record plain response still exhausts 100M fuel; enriched
  maximal output and the full owning gate remain unverified (#286 open).

- Add a dispatch-only Windows confinement runtime gate that requires nonzero
  execution of restricted-token child launch, job limit/membership, scratch
  DACL, descendant refusal and test-owned descendant timeout, normal/nonzero
  settlement, timeout cancellation, and filesystem-stage refusal with
  handle-count cleanup. The gate uses
  test-key-signed capsule fixture bytes (not a release trust anchor), requires
  successful `taskkill /T` and direct Cargo PID absence on
  timeout, and checks exact marker/scratch cleanup. Descendant quiescence is
  not independently enumerated. The original two-test slice passed on exact
  checkout `c6bf9902`; the historical five-test selector passed in hosted
  Windows run `35988348061` at `3d4220b6`. Current source uses the shared
  signed-capsule verifier and capsule-v1 architecture codes 3/4 for Windows,
  with a historical nine-test selector (six runtime cases plus three admission refusals).
  That selector passed on exact checkout `c608b8d8` in hosted Windows Server
  2025 run `35992373373` (9 passed, 0 failed, 0 ignored). Artifact-byte binding and production
  support remain unverified. A tenth selected Windows case now exercises a
  real inheritable broad ACE on a private parent and requires the created
  scratch DACL to stay protected with only its intended explicit ACE; the
  expanded selector passed at `f4d3291f` in hosted Windows Server 2025 run
  `35993882814` (10 passed, 0 failed, 0 ignored).

- Harden additive lock-bound offline fetch with held-directory authority,
  bounded retained inputs, private staging and no-replace cache publication.
  Failures retain stages or a published prefix for explicit reconciliation,
  without pathname rollback or a misleading success receipt; unsupported
  hosts refuse before cache effects.

- Re-pin exact Semantic Workspace Change and Operations artifact/evidence/receipt
  KATs to the expanded Project graph and serialized limits while retaining
  domain, reference, API/CLI parity, tamper, replay, budget, and stale/no-write
  assertions.

- Keep the standalone compiler archive independent of unpublished crates by
  moving the private OCI emitter and all hostile tests into one internal
  compiler module. Preserve the typed input boundary, exact artifact bytes,
  credential refusal, and unchanged no-signing/no-registry-publication scope.

- Keep the private public-generic Component runtime inside its ambient-authority
  source contract: acquire a checked-in canonical project explicitly, replay
  against pinned identities, and authenticate exact Component bytes before
  typed execution. This does not widen public Component support.

- Generate canonical descriptor-bound TypeScript/Wasm carrier frames and run
  the generated package against the compiler-owned provider lifecycle. Add the
  private `semaprax.authenticated-native-identity.v1` C profile, which rejects
  malformed or drifted frame metadata before physical work and invokes one
  compiler-checked flat owned-`Bytes` identity endpoint across C, C++, and Rust.
  These are local, unpublished profiles; broader shapes, shared-corpus and
  hosted acceptance remain open.

- Settle borrowed arguments and returned `Bytes` at the native Agent stage
  boundary, retaining sticky failure and strict post-drop receipts. Local
  controls cover success, contract failure, cancellation, omitted drops,
  malformed receipts, and duplicate calls; native instruction fuel, complete
  finalizer accounting, compound cleanup failures, and Wasm parity remain open.

- Emit the internal `public-generic-wasm-provider.v1` endpoint as a
  deterministic zero-import Core Wasm module with exact descriptor/binding
  replay, normalized artifact binding, canonical carrier SHA-256 validation,
  module-owned scratch and opaque lifecycle handles, checked HIR invocation,
  two-pass result export, and explicit release/close operations. The generated
  TypeScript runtime now delegates provider lifecycle to those exports. The
  subsequent canonical carrier migration makes that package interoperable;
  #229 and the broader #162 matrix remain open for their larger acceptance
  scope.

- Add the internal `public-generic-wasm-provider.v1` Project profile as the
  first compiler-owned target foundation for #229. Package Manifest v1 now
  selects exactly one concrete checked generic owned-record endpoint, derives
  its Public Generic Descriptor v1, independently replays it against the exact
  linked program and project revision, and binds the verified digest into
  Project Lock v1. Web, npm, native, and Agent Transport artifact routes remain
  fail-closed until the Core Wasm provider emitter exists. The #162 native
  generated-caller settlement gate now shares this compiler-derived descriptor,
  binding, instance, cleanup, and leaf identity across C, C++, Rust, and the
  executed reference provider; the endpoint body remains the explicit reversal
  fixture, so neither issue is closed by this phase.

- Make the push-driven CI and Docs workflows latest-ref only: a newer run now
  cancels its in-progress predecessor instead of spending hosted runner minutes
  completing already-superseded matrices or documentation builds.

- Extend the bounded resumable-effect source profile from one site to one to
  eight direct sequential Copy-scalar `yield` sites. The deterministic plan now
  carries ordered per-site states and yield-free resume projections; the public
  interpreter uses an opaque in-memory request/answer history, while private
  native `-O0`/`-O2` and Core Wasm runners replay the same projections. Every
  historical request is checked, and bindings commit exact arguments plus
  prior answer bits. This remains pure replay, not live-frame/liveness
  lowering: control-dependent yields, owned state, durability, scheduling and
  public target ABIs remain open. Distinct request/response assignment sites
  fail closed with `SPX-T299`; `let` and tail sites retain distinct types
  (#204). The original one-site `ResumablePlan`, exhaustive `ResumableStep`
  and start/resume functions remain source-compatible; sequential lowering and
  execution use additive plan, step and start/resume surfaces.

- Add the initial deterministic compiler-owned three-state HIR plan for the
  single-top-level, Copy-scalar `yield` slice (subsequently widened above).
  Resume state now binds the exact
  checked program, yield site, and bit-exact original arguments. Closed
  projections now isolate disconnected yielding functions while retaining the
  selected and authored-entrypoint direct-call closures; retained non-scalar,
  effectful, owned-cleanup, generic and function-reference surfaces, all
  authored nominal/authority surfaces, reachable yielding callees, retained
  incoming callers, forged projections,
  and stale bindings fail closed. The interpreter consumes the plan identities,
  while `cfg(test)`-only
  native `-O0`/`-O2` and Core Wasm runners execute independently validated
  yield-free projections, preserving exact normalized prefix/suffix arithmetic
  and pre/postcondition failures. Ordinary native/Wasm emitters still refuse
  `yields`; arbitrary NaN-payload preservation across the JavaScript Wasm test
  adapter, public continuation ABI, external-await runtime seam, durable source
  checkpoint, Agent migration, and general live-frame/control-dependent yield
  lowering are not claimed. The reference v1 journal additionally completes
  an already-observed partial turn without redispatch and never repeats cleanup for an in-memory
  replayed terminal; its unchanged wire has no durable append or cleanup
  settlement, so decoded terminal cleanup and crash recovery remain ambiguous
  and unclaimed (#204).

- Add a deterministic, non-executing cross-language benchmark reproduction
  capsule that binds exact task and adapter inventories, equivalence files,
  public and hidden trees (including empty directories), and per-language
  adapter policy. Stable descriptor-backed reads reject path swaps, and a
  matching capsule says only that scoring inputs match, never that a model or
  toolchain ran (#211).

- Compose the task-service reference application and generated service
  scaffold with `std.tracing`'s pure trace-context and secret-classification
  policy now that reachability pruning admits the dependency closure. Valid,
  malformed, and caller-classified-secret cases join the existing backend
  parity gate; no logging, span emission/export, or host authority is added
  (#194).

- Record the first hosted Windows compilation evidence for the production
  provisioner confinement module. The successful Windows Server 2025 job
  compiled the `cfg(windows)` code at the exact recorded revision but selected
  no confinement test function, so runtime confinement evidence remains open
  (#236).

- Add an offline, unavailable-only admission gate for future external coding-
  agent baselines. It binds the owner-pinned task inventory bytes and Zero
  source revision to closed toolchain, interface, model, and reviewed-port
  provenance without running a model or treating provenance as execution
  evidence (#107).

- Carry exact empty `Bytes` arguments through source-native Core Wasm Agent
  stages using the existing named slice/range/copy ownership path, with
  interpreter, native `-O0`/`-O2`, and Core Wasm parity plus a retained
  malformed-carrier refusal (#143).

- Harden generated package preview verification around a flat physical-file
  inventory and private verified snapshots before optional npm or Cargo dry-
  runs. Package publication, signing, registry credentials, and support-policy
  promotion remain outside this tool (#145).

- Harden the paired-agent pilot's stale-recovery metric so only an exact,
  well-formed conditional write to the drifted source can count as recovery,
  and only the gateway's exact stale-precondition refusal can count as a
  rejected stale write. Reads, unrelated paths, malformed commands, and other
  failures now fail closed instead of producing optimistic evidence. Fresh
  cohorts now have a digest-bound reviewer packet and exact 18-tuple audit:
  direct treatment labels are withheld, task content remains visible, and
  hostile or drifted evidence fails closed without backfilling the historical
  cohort (#105).

- Preserve `i64::MIN` when source-native Agent stage arguments are synthesized
  for Core Wasm and native C11 execution. A four-leg regression now exercises
  the value through the interpreter, native `-O0`, native `-O2`, and Core Wasm,
  while empty byte literals retain their stable refusal (#182).

- Add a binding-first Lean-kernel certificate recheck that re-derives the
  source, exact obligation selector, Lean document, and Wasm artifact before
  consulting caller-supplied kernel authority, then requires exact recorded
  axiom results. Kernel-confirmed evidence can now be associated with one exact
  retained Project `ProgramRoot` and appended to its assurance manifest through
  an opaque verified token; sibling projects, altered source, subset
  certificates, and replayed revisions fail before attachment. No process,
  filesystem, network, or tool-discovery authority is added to the compiler
  (#186).

- Preserve every failing real-distribution role in the provisioned Linux
  doctor diagnostics instead of stopping at Node's first failure. Hosted run
  35472257722 remains red (12/13 in both suites): Clang passed, Node received
  `SIGSEGV`, and Rust's exact termination awaits the next instrumented run;
  confinement policy and WP-05 status are unchanged (#61).

- Track AArch64 Linux doctor confinement separately with a dispatch-only native
  Arm runner and an exact 24-case plan. The committed evidence is limited to a
  historical local Docker Desktop Arm VM run (24/26); the two real-distribution
  fixtures remain excluded for missing selector/bundle preconditions, and no
  hosted, current-head, or physical-device support claim is made (#279).

- Compose `std.tracing` trace-context field admission with the existing
  `std.log.redact` six-flag caller classification, preserving
  malformed-context refusal and left-to-right lazy evaluation. It does not
  inspect bytes or tracestate and remains a pure policy layer with no span
  generator, exporter, sink, or transport authority (#193).

- Version and digest the public-generic hostile corpus, pinning 17 shared case
  outcomes plus exact bytes for 9 structured-descriptor and 6
  malformed-trusted cases in one deterministic manifest while correcting
  stale evidence counts. Persistent compiled source mutants now prove that
  five previously untested descriptor-envelope refusals are individually live
  in the generated Rust, shared C11/C++17, and TypeScript consumers, and that
  weakening each branch reaches the provider before clean settlement.
  Exact-current-head hosted evidence, carrier-side consumer hostility, and real
  generated endpoints remain outstanding (#173).

- Drive the private frozen iterative Agent loop through the existing sealed
  interpreter, native C11 `-O0`/`-O2`, and Core Wasm stage backends. The local
  parity gate covers proposal admission, fresh consumed grants, injected binary
  reads, continued and terminal reductions, cancellation, malformed proposals,
  lifecycle ceilings, and semantic evidence settlement while leaving production
  wrappers interpreter-only. It also fixes canonical lexical selection of ten-
  plus synthesized Wasm projection exports without reordering driver, decode, or
  cleanup plans. Native/Wasm interpreter-fuel and hosted evidence remain open
  (#182).

- Extend the source-live repair preview with an explicitly selected OpenCode
  Provider-Adapter route, durable V2 receipts, a restart-stable absolute
  deadline, and checkpoint identity bound to the chosen executable and
  scratch path. Terminal recovery now replays recorded provider bytes without
  pre-deriving fixture diagnostics or redispatching, binds corrective turns to
  the actual canonical prior effect, and rejects tampered settled responses.
  A public embedding seam can now inject one opaque, host-selected,
  fixed-buffer candidate-test observer: its canonical result is bound to the
  exact candidate/base/source/capability, settled as typed feedback for a later
  provider turn, and replayed without redispatch. Executable bytes and metadata
  are bound, run/export scratch state is cleaned before reuse, and foreign or
  tainted observations fail closed. The ordinary CLI still grants no test or
  publication authority; the scripted V1 seam stays frozen for offline
  regression coverage (#116).

- Add whole-line UTF-8 validation and checked nonnegative `i64` total helpers
  to the catalog-normalizer example, with malformed-scalar, boundary-total,
  backend-parity, and mutation-control regressions. This is a
  bounded foundation tranche; the complete record parser, canonical writer,
  duplicate handling, and independent oracle remain open (#124).

- Have tag release jobs produce pinned GitHub build-provenance attestations
  for each platform archive and keylessly sign the final aggregate provenance
  with pinned cosign tooling. Release publication now carries those bundles
  beside the manifest and provenance, while policy and tests distinguish the
  GitHub OIDC `sub` claim from the Fulcio workflow-URL certificate identity.
  A bounded offline verifier now closes the Sigstore v0.3 framing, GitHub
  workflow-v1 predicate structure, exact archive inventory, and aggregate
  manifest/provenance/claim bindings before invoking an explicit verifier
  capability. `SigstoreOfflineVerifier` supplies the standalone CLI's default
  pure implementation, checking certificate-chain and pinned identity,
  DSSE/message signatures, signed time, and transparency-log evidence against
  exact caller-supplied historical trusted-root bytes. An embedding host can
  still inject another capability. Verification performs no network or root
  refresh and does not establish current revocation state, publication,
  reproducibility, or support. No signed hosted release is claimed yet (#168).

- Stop Universal Semantic Transaction v1 from refusing every project with a
  commented bundled dependency (#274). `ProjectCandidate::apply`'s
  `materialize` step re-derived *every* source in the revision through the
  comment-dropping canonical formatter, so the comment-free precondition had
  to span the complete workspace -- including compiler-bundled dependency
  source (`std.auth` carries 253 comment lines, `std.jobs` 34) that no project
  can edit, making `SPX-G525` unsatisfiable by construction rather than by
  authoring. `materialize` now preserves an untouched program's exact base
  bytes, and the new `src/project/semantic_transaction/canonical_sources.rs`
  enforces comment-free canonical source differentially, of exactly the
  sources a transaction rewrites or drops. A comment in a rewritten source is
  still refused with `SPX-G525`, and the `SPX-G525` regression that proves it
  is unchanged.

- Run a real Lean kernel against the `proof_export` obligation export for the
  first time (#186). The module shipped with no `LeanKernel` implementation and
  no evidence Lean accepts its generated proofs -- every test replayed
  synthesized output. `scripts/lean-export-gate.py` is that implementation,
  deliberately outside the crate so the compiler gains no ambient process
  authority: it confirms the host runs the pinned `leanprover/lean4:v4.34.0`
  (the same pin `proofs/kernel0-lean` uses), checks the committed golden
  document plus two seeded variants, and compares each result byte-for-byte
  against transcripts committed under `src/proof_export/testdata/`, so recorded
  evidence cannot silently go stale. Results: `omega` discharges both the
  checked-range obligation and the postcondition, axiom-clean and
  byte-reproducible across runs; a seeded `sorry` is refused; and a vacuously
  weakened conclusion is *accepted* by the kernel with an axiom set cleaner
  than the honest proof's -- recorded as data, because it is precisely why a
  certificate binds `lean_source_sha256` and `verify_certificate_against_source`
  re-renders the document from source instead of trusting the embedded bytes.
  Fixes one real fail-open the real kernel exposed: Lean 4.34.0 prints
  ``declaration uses `sorry` `` with backticks, so both single-quoted spellings
  `kernel_report::parse` was written against (from synthesized fixtures) were
  dead against the very toolchain the module pins, leaving only the `sorryAx`
  clause load-bearing; quoting is now normalized. All kernel evidence is
  **local-host only** -- hosted CI provisions no Lean toolchain, the gate is not
  in `scripts/quality.sh` and not in `release-gate`'s blocker set, and every
  certificate now carries that as an explicit nonclaim.

- Narrow `ProjectFrontendCache`'s AST-level invalidation (`src/project/incremental.rs`):
  a provider module's own changed/added/removed source still invalidates its
  frontend cache entry, but an unrelated consumer that only imports from that
  provider no longer loses its entry through the old transitive reverse-import
  closure. Parsing and canonicalizing one file is a pure function of that
  file's own bytes, so a reused entry is bit-identical to a fresh reparse
  regardless of what any provider did, and every cross-module check (import
  stub validation, the checked-HIR cache's own exact `synthetic`-equality
  gate) still reruns unconditionally against the current build's sources, so
  a provider's exported-surface change is still caught -- narrowing this set
  only decides which unaffected files skip a redundant reparse. On
  `examples/calculator-project`, a provider body edit went from 0 modules
  cloned / all 3 reparsed (80 AST nodes) to 2 modules cloned / 1 reparsed
  (32 AST nodes), matching the existing local-body-edit case instead of being
  its expensive opposite (#130, #131).

- Add `scripts/generated-package-release.py` (`prepare`/`check`), a
  release-preparation and dry-run-only layer around the existing Project v8
  `owned-data-api.v1` generated npm/Rust packages: closed-inventory,
  secret/local-path, and no-private-dependency admission; deterministic
  README/LICENSE/checksum-manifest wrapping; and a `check` step that only
  ever runs `npm pack --dry-run`/`cargo publish --dry-run` (never
  `--publish`, never near a live registry credential). Prepares (but does not
  make) the maintainer publication decision drafted in
  `docs/GENERATED-PACKAGE-PUBLICATION-DECISION-DRAFT-V1.md`; nothing is
  published by this change (#145).

- Refuse a bundled dependency member that names an authored type at the Useful
  Data workspace linker boundary, by name, rather than admitting it into a
  declaration set that deliberately holds no authored type and letting it
  surface much later as `inline-array slot references an unknown type` inside
  inline-array capacity analysis. Drop such a member from the retained
  dependency inventory when nothing reaches it, so a bundled package may still
  declare a generic record. This restores `semaprax new --template service`,
  which the `record Secret<T>` added to the bundled `std.auth` had broken for
  every scaffolded project (#268).

- Execute the unchanged native reference provider inside freestanding Core Wasm
  at O0/O2 under both V8 tiers, with in-module allocation, ownership registries,
  multi-call copy-in/export/release and no host imports. Add a bounded private
  transport, exact native/corpus comparison, allocator self-tests, hostile-range
  and lifecycle tests, deterministic artifacts, canonical replay, and compiled
  semantic mutation controls for #162. This is a C11-reference fixture, not a
  Semaprax-generated generic endpoint, public Wasm ABI, PG-7 completion or hosted
  promotion. Actual Rust-renderer equality remains a separately selected gate.

- Enforce single-owner, non-reentrant native reference-provider admission with
  one atomic owner/entry word; retain ownership until the last provider closes,
  and isolate failure injection, traces and sticky diagnostics per caller thread.
  Reject misuse without touching caller output/owning aliases or reporting false
  zero-resource counters. Extend #162 with deterministic pthread misuse/handoff,
  exact/+1 thread-identity admission, sanitizer, replay and mutation gates. This
  enforces the existing synchronous restriction, not concurrent execution,
  compiled generic-provider support, PG-7 completion or hosted promotion.

- Harden the host-owned TypeScript/Wasm reference caller: authenticate immutable
  module-byte snapshots, reject unverifiable precompiled modules, isolate private
  descriptor/binding authority, enforce one in-flight owner and exact framed
  payload bounds, preflight complete result frames, and propagate primary plus
  secondary cleanup failures. Extend #162 with 108 settlement cases, 32 host
  regression groups, 13 authenticated module subjects, two V8 Wasm execution
  tiers, fresh C/C++ semantic comparison, strict replay and twelve type-checked
  behavioral mutants. Add actual-generator byte-equality gates without claiming
  those Rust gates have run, compiled-provider support, PG-7 completion or hosted
  promotion. No existing native ABI or public rejection profile is widened.

- Propagate explicit native release failures through C11/C++17 calling consumers
  without exposing a decoded success or overwriting earlier failures. Add
  checked close with retained ownership, reverse caller rollback, bounded
  encoding/export/decode, and per-invocation injection isolation. Implement
  corresponding Rust settlement and fallible codecs, with separate Cargo
  regressions. Extend #162 by 112 shared consumer cases, independent caller
  counters, replay evidence and eleven compiled semantic negative controls;
  actual generator/Rust execution remains a distinct gate, and full PG-7,
  compiled Wasm and hosted promotion are not claimed.

- Return real native input/result release failures without overwriting an earlier
  call's settlement. Extend #162 with actual per-leaf result allocation/copy and
  export preflight failures, pre-rollback byte checks, exact 16 MiB success,
  compound reverse cleanup, and 72 pinned physical-phase cases with a third
  independently replayed evidence artifact. Legacy logical trace bytes and
  public ABI declarations remain unchanged; full PG-7 and generated-consumer
  failure propagation are not claimed.

- Prevent stale native public-generic handles from reviving when heap addresses
  are reused; validate provider identities before access/close and pin bounded,
  non-recycled identities plus exact/+1 live-resource admission. Isolate
  settlement between sibling prepared inputs so an earlier success cannot mask
  a later failure as success-without-result. Extend #162 with lifecycle/recreation,
  identity-exhaustion, 8,192-call stress and paired replay evidence; public ABI
  signatures and unsupported/unpublished status remain unchanged.

- Share one bounded, digest-pinned public-generic settlement manifest across the
  existing model/native harnesses; preserve primary failures before cleanup and
  reverse every native result rollback. Add per-case native observations, real
  allocation/compound-failure regressions, retained trace expectations, and
  portable sanitizer/replay evidence. This advances the fixture subset of #162;
  it does not close PG-7 or widen public ownership support.

## 0.5.0 — 2026-09-14

- Bind effect-free retained source job handlers to persisted deployment
  descriptors before claim, using the existing durable job runtime and
  checked interpreter; refuse stale roots and handler substitutions (#192).

- Complete the ten-row feature-composition inventory, exact ownership-profile
  refusal regression, and provisioned strict differential campaign route
  with explicit CI selections and nonzero-case enforcement (#103).

- Add exact SDK-envelope byte reservations to durable retries with frozen V2
  journal preservation, canonical V3 recovery, and post-poll cancellation
  checks (#179). Tighten provider conformance around request admission,
  completion, final bytes, and usage regressions with corpus V2 (#181).

- Add a checked two-call offline repair loop and private CLI demo with
  bounded candidate edits, diagnostic feedback, read-only review evidence,
  and terminal journal replay (#116). Extend imported owned cursor failure
  composition with exact Wasm cleanup-order and sticky-status controls (#103).

- Account compact workspace validation clones before allocation and schedule
  the final uncached graph phase by temporary HIR overhead without raising
  its cap (#124). Add decoded ID bounds and allocation-free token equality
  to the catalog helper application with cross-backend oracle checks.

- Add generic durable retry/failover with acknowledged attempt journals,
  exact retained execution/schema/model bindings, non-widening source and
  deployment limits, request-seed checks, and conservative recovery (#179).
  This is local host composition; checkpoints do not prove provider identity
  or billing.

- Add V6 durable source-model quote accounting with nonrefundable observed and
  unknown usage, absolute deadlines, cumulative migration carry, and optional
  request/response byte ceilings (#113). Retain observed quote overages in
  ordinary source-model admission as well.

- Retain exact generic model request/response reservations in the additive
  priced I/O envelope, cross-bind successor carry, and reject noncanonical
  recovery requests (#113). Add store-backed typed source-model execution with
  acknowledged intents, exact raw settlements, and no uncertain redispatch
  (#177). Release full sequential workspace HIR after compact validation facts
  and selected output carriers are extracted (#124).

- Pair generic live work reservations with durable monetary accounting (#113),
  and enforce opt-in source-model ceilings before adapter construction (#177,
  #179). Add a final uncached graph retry that charges retained output vectors
  while preserving earlier successful budget receipts (#124).

- Bind typed live model operations to deployment selection and commit their
  redacted attempt evidence in an additive execution root (#177). Propagate
  remaining host deadlines and distinguish reserved, observed and unknown
  provider charges in a separate Runtime v1 receipt (#113).

- Add counterbalanced pilot scheduling, isolated MCP tools for both comparison
  lanes, retained candidate source bytes and exact transport archives (#105).
  Trial capture remains separate from eligible observations and review.

- Preserve pre-dispatch OpenCode cancellation as a zero-call cancellation
  failure (#113). A changed journal or claimed dispatch without a receipt
  remains a model failure; unresolved attempts cannot become clean refusals.

- Add direct owned String variant payloads (#216), with canonical String
  lifecycle replay, own/borrow matching and backend cleanup. Scalar-match guard
  and arm temporaries settle through exact cleanup regions. Generic String
  substitutions and nested owned-record variant payloads remain restricted.

- Add explicit Rust-host Argon2id password hashing, authenticated sessions and
  signup/login/logout composition (#191). Persist job cancellation and recurring
  schedule advancement with checked arithmetic and replay evidence (#192).

- Add checked-source HTTPS POST across explicit provider, native C11 and
  Core-Wasm/npm fixture paths (#193), with bounded body/response bytes, explicit
  destination authorization and no automatic retry or redirect for POST.

- Add an explicit native HTTPS transport for provider adapters (#181), with
  injected credentials, bounded buffered responses and conservative dispatch
  uncertainty. Extend compact task context with ordered seeds, revision binding
  and selectable token accounting (#197). Add a host-driven single-job
  checkpoint runtime and evidence-based recovery (#192).

- Drive bounded retries and ordered failover through injected provider adapters
  (#179), preserving charged attempts and stopping on uncertain outcomes.
  Add host-transport protocol adapters for Responses and Messages (#181).
  Recheck cancellation and deadlines when streaming settlement returns.
  Add an eighth cross-language task family exercising owned byte mapping and
  hidden-oracle rejection in Rust, TypeScript and SEMAPRAX (#106).

- Import bounded provider invoice evidence through explicit verifiers and retain
  reconciliation results (#180). Enforce source usage consistency and complete
  audit-view disclosure, payload association and truthful privacy claims; add
  canonical audit replay and direct receipt emission from live run evidence.

- Decode canonical model receipts with strict bounds and enrich actual generic
  and source attempt journals using retained root, request and host metadata (#180).
  Join explicit adapter observations and provider usage without inventing
  missing measurements; preserve failure and unresolved lifecycle evidence.

- Capture ordered provider adapter attempts and replay retained chunks against
  actual generic/source runtime schemas (#178/#180). Bind generic settlements
  to validated journal requests and responses; compare provider token and cost
  observations independently during invoice reconciliation.

- Validate streamed nested Proposal fields, variant cases, exact scalars and
  text/byte bounds from compiled type tables before final decode (#178).
  Expose read-only grammar states and bounded work counters; extend the
  generated TypeScript/Python/Rust client harness with adversarial chunking.

- Add versioned selective-dictionary model-text projections to CLI, retained
  service and compatibility negotiation (#201). Connect streaming proposals to
  Direct Runtime v2 typed effects and reject mismatched compiled schema envelopes
  while streaming (#178); nested semantic admission remains in the full decoder.

- Expose compact projections through CLI replay and retained service/MCP routes,
  with explicit format/profile negotiation and offline model-token measurement
  tooling (#201). Introduce Rust embedding API v2 for mandatory analysis/execution input caps, add
  cooperative request cancellation, and verify opaque session release (#203).

- Add authoritative task-context, Project API, candidate-diff, and Agent graph
  compact profiles with regeneration-bound replay (#201). Extend Rust embedding
  negotiation, cancellation, and the external consumer (#203). Connect the
  source Proposal grammar to incremental decoding and an explicit per-attempt
  provider adapter factory with bounded iterative context (#178).

- Connect the streaming Proposal decoder to the provider adapter and generic
  live-kernel seams (#178), and compose token/cost/call policy with the live
  work-budget hook (#179). Extend the embedding facade with opaque in-memory
  Project sessions, atomic refresh, semantic query, and candidate replay (#203).

- Add journal-derived model-call receipts (#180) for generic live runs and
  authenticated source checkpoints, including exact replay and Audit Capsule
  object references. Unrecorded timing and billing stay unknown. Harden enriched
  receipt replay against contradictory response states and decode refusals.
  Extend the Rust source embedding facade (#203) with bounded context v1/v2
  queries and explicitly authorized, cancellable, fuel-bounded interpretation.

- Implement additive Project Assurance Manifest v1 (#214): a canonical,
  integrity-bound envelope bound to one retained Project, workspace
  revision, ProgramRoot, and complete ordered source inventory. The profile
  deduplicates shared entry/public/test HIR obligations, records explicit
  unselected coverage, and admits only held `forbid_reaches` architecture laws;
  the existing single-file Assurance Manifest v1 bytes remain unchanged.

- Add additive source-journal I/O v5 accounting and private CLI config/receipt
  v3 (#113). Authenticated attempt rows reserve exact prompt bytes and bounded
  response capacity cumulatively; recovery and compatible migration retain
  reservations without profile conversion. Legacy source journal and CLI
  profiles remain unchanged. Add #103's result-allocation rejection case with
  ordered input release in interpreter/Wasm and status/resource parity in
  native C11 O0/O2, including a wrong-order oracle control.

- Extend #113's priced adapter regressions with exact retained retry I/O,
  invalid quote preflight, and deadlines reached at journal acknowledgements.
  Add #103's imported `std.bytes` view-composition oracle across the Project
  interpreter, native C11 O0/O2, and Core Wasm, including temporary cleanup.

- Add an explicit priced source-journal v4 route and private CLI config/receipt
  v2 (#113). Integer currency-bound reservations remain separate from work
  quotas and provider observations; replay retains unknown exposure and refuses
  quote drift. Add the private CLI's one-hop priced-to-priced migration carry,
  preserving cumulative reservations, observations, overage, and global money
  ordinals under a non-widening compatible quote. Legacy source profiles remain
  unchanged; unsupported profile conversion is refused.

- Construct ordinary imported function stubs from signatures without cloning
  discarded bodies (#124). Preserve fitting graph receipts and add an uncached
  fallback charging retained HIR plus the peak of sequential synthetic ASTs,
  within the existing builder limit; cached frontends retain summed charges.

- Add opt-in, bounded current-thread workflow stage observations and an offline
  campaign runner; compare exact cold/warm frontend products and prepared
  traced/untraced products before timing. Measurements remain local evidence,
  separate from canonical artifacts and authority (Refs #85).

- Pin cumulative durable source reservation boundaries at zero, exact, and
  one-unit-over ceilings; terminal recovery retains accounting with zero
  new proposal, model, or effect dispatches (Refs #113).

- Exercise eight borrowed byte-view call compositions across interpreter,
  C11 O0/O2 and Core Wasm, including offset-sensitive forwarded views,
  comparator rejection and the stable escaping-view diagnostic (Refs #103).

- Validate bounded Descriptor-v1 frames and versions in generated calling
  consumers before exact pairing and provider admission; exercise canonical
  shared mutations and byte-identical malformed configured descriptors in
  Rust, C11, C++17, and TypeScript/Wasm (Refs #173).
- Add independent sensor-conjunction and stable three-job ordering benchmark
  families with candidate-preserving hidden overlays and three-port negative
  controls (Refs #106).

- Add private `semaprax-full source-live run|resume|migrate` commands
  (#113/#116), with held-directory checkpoints, exclusive writers, bounded
  explicit task/read inputs and retained-Project bindings. A migration carries
  the predecessor clock floor and nonrefundable work into one claimed
  destination. Recorded-provider tests cover run, recovery and checked migration;
  monetary pricing and the actual source repair workflow remain separate.

- Extend the catalog-normalizer source application with bounded JSONL record
  counting and line/body limits (#124). Seven application cases execute on
  the interpreter, C11 at both optimization levels and Core Wasm; a terminal
  newline counting mutation is rejected. Full record normalization remains.

- Reduce the last-resort workspace graph construction estimate (#124) by
  charging the largest sequential temporary import clone once. Imported
  stubs release their discarded contract-vector buffers. Earlier accepted
  receipts and the 18 MiB cap are preserved; core retries stay bounded.

- Add a fifth held-out cross-language benchmark family for half-open booking
  conflicts (#106). Rust, TypeScript and SEMAPRAX share candidates across
  public and hidden runs; an inclusive-end mutation passes public cases and
  fails hidden adjacency cases on each port. Actual coding-agent trials remain.

- Migrate suspended source-mode agents through checked retained-Project A→B→C
  handoffs (#115), preserving schema provenance and cumulative charged work.
  Acknowledged migration results resume at Observe; initialization and completed
  effects do not repeat. Lost acknowledgements, cancellation, deadline drift,
  and malformed recovered State fail closed under explicit host-store freshness.

- Add private filesystem v3 checked atomic writes (#228), with inspectable
  Published, NotPublished, and Uncertain outcomes and an exhaustive std.fs
  variant wrapper. Interpreter, native C11 and Core Wasm preserve the separate
  callback failure channel and legacy v2 behavior. Graph v46 binds the new
  operation; compact conformance fixtures keep the existing construction limit.

- Add a fourth cross-language benchmark family for a multi-module invoice
  calculation (#106). Candidate-preserving hidden entry modules distinguish
  whole-subtotal rounding from per-item rounding in Rust, TypeScript, and
  SEMAPRAX Project execution. This adds corpus coverage, not coding-agent trials.

- Separate native public-generic allocation accounting from the 16 MiB
  logical carrier limit (#250), allowing metadata and overlapping full input
  and result payloads. Exercise exact-byte boundaries across local native,
  interpreter, and Wasm fixtures, with bounded allocation failure and cleanup.

- Pin Cargo, rustc, and rustdoc in the generated Rust consumer's MSRV gate
  (#226). Selecting Cargo alone had allowed the ambient newer compiler to
  satisfy the check. Native allocator capacity remains tracked in #250.

- Cover drop-free nested variant payloads through interaction-schema derivation,
  canonical decoding, and hostile nested-field refusal (#216). Correct the
  proposed checked-write taxonomy to distinguish proven non-publication from
  phase-ambiguous legacy I/O errors (#228); missing-parent provider regressions
  preserve the current fail-stop operation.

- Add a separate structured-envelope validation task to the cross-language
  corpus (#106), with candidate-preserving hidden tests and a negative control
  for wrong error precedence and removed visible assertions. The additive
  SEMAPRAX Project adapter leaves the original pilot and task routes intact.

- Connect source checkpoint execution to the checked iterative driver (#113).
  Journal v2 reserves fresh fuel on replay, shares one model-budget ledger,
  persists optional usage and terminal evidence, refuses uncertain redispatch,
  and retains partial failure evidence. The OpenCode durable source borrows
  that ledger; source migration and a durable CLI remain pending.

- Exercise lazy boolean operands containing checked division failure through
  the differential corpus (#103), including interpreter, native O0/O2, and
  Core-Wasm observations with explicit lane results.

- Derive Assurance Manifest result-ownership and resource-cleanup obligations
  from independently revalidated HIR (#214), and keep candidate summaries
  aligned. Architecture-law derivation and workspace binding remain pending.

- Complete the documented-limit decision for compiler capacity (#241): name
  the distinct checked-cache ceiling in SPX-G256, pin its inclusive boundary,
  and state graph/replay limits and the source-versus-runtime byte-copy guard.

- Run TypeScript/Wasm consumer Node entry points with relative fixture paths
  to avoid Windows extended-path main-module resolution failures. Complete
  private OpenCode/source-journal documentation metadata and catalog entries.

- Include Cargo example targets in the CI unit shard, preserving exhaustive
  workspace inventory and refusal of unknown target kinds.

- Add an explicit OpenCode proposal-attempt checkpoint boundary over the same
  source journal and accounting ledger (#113). It validates bound context and
  phase before charging, acknowledges intent before transport, and persists
  the outcome before exposing response text. Full source replay remains pending.

- Add bounded source checkpoint primitives with strict causal validation,
  poisoned writes after acknowledgement loss, and restoration through the
  existing charge/deadline ledger (#113). Source runtime replay, provider
  receipt persistence and migration integration remain pending.

- Derive cached Project Agent interaction facts from retained authenticated
  source programs, fixing false SPX-G564 failures without reparsing (#85).
  Repair the embedding-example index and Clippy CI blockers, and provision
  pinned Clippy for the public-generic consumer job.

- Provision pinned TypeScript 5.8.3 for the public-generic hosted job and
  fail closed on missing consumer tools; record platform/toolchain identities
  with separate Unix and Windows preflights (#163). Fresh hosted evidence
  remains pending.

- Check the OpenCode source route's shared deadline around deterministic stages,
  proposal admission, effect dispatch and result publication (#113), preserving
  earlier selected failures. Durable source failure evidence remains pending.

- Require explicit cumulative reservations for OpenCode source attempts and
  retain their bounded usage observations across malformed retries and failures
  (#113). Check the shared absolute deadline at settlement and later kernel
  boundaries; source recovery and migration accounting remain separate work.

- Connect one explicitly configured free OpenCode provider to the existing
  source-feedback driver, preserving canonical proposal admission (#112).
  Bound Unix process output/cancellation, bind real CLI receipts, preserve
  reported usage and redact provider error categories. The fixed local live
  smoke reached Complete; broader hosted/provider support remains separate.

- Reuse exact retained source ASTs during cached Project finalization and
  prelude-bound revision replay (#85). Remove nine hidden public parser calls
  from unchanged calculator builds in both cache modes, preserving revision
  hashes and admission checks; no timing improvement is claimed.

- Add explicit untraced prepared Project execution with unchanged traced
  behavior, fuel, cancellation and revision replacement. Add matching cold
  and prepared benchmark products and truthful platform-specific memory
  observations (#85); no new performance measurements are claimed.
- Persist migrated live-kernel handoffs, state and destination journals in one
  bounded canonical checkpoint before dispatch, with recovery and store-failure
  regressions (#115). Checked source migration and cumulative-chain integration
  remain open.
- Add a non-editing OpenCode availability smoke and bind archived event streams
  to the matching exported session and frozen prompt (#105/#112). This is
  provider availability evidence, not a coding-agent trial or live-driver adapter.

- Correct the Workspace Semantic Graph and Context/Impact/Review workspace
  limit projections to report the enforced 18 MiB builder ceiling from one
  renderer (#248). The 16 MiB analysis/cache ceilings remain separate. Re-pin
  exact artifact hashes after verifying that restoring only the old limit
  and dependent digests reproduces every previous known answer.
- Repair standard-library conformance registration for guarded logging and
  `std.metrics`, and synchronize the generated auth/TOML catalogs (#102).
- Exercise frozen execution evidence around a live fixture invocation and
  clarify that terminal journal replay preserves its case and carrier digest,
  not the original carrier payload (#108).
- Add a standalone Rust consumer for the public check/format/graph embedding
  facade, with its own offline lockfile and explicit checkout-only scope (#203).

- Rewrite the `SPX-H006` cleanup-replay path-budget diagnostic's message to
  name the actual cost driver instead of only the budget it exceeded. The
  previous wording ("cleanup replay path bound exceeds the global path
  budget") told an author nothing about *why*: the real driver is
  combinatorial multiplication of independently-combined branch outcomes
  within one function (2^N terminal paths for N such branches), not raw
  branch count, so the natural fix an author reaches for on reading the old
  message - splitting into helper functions - does not help unless it breaks
  the combination. The new message states the measured path count and budget,
  names the combinatorial driver, and names an actionable remedy (make the
  branches mutually exclusive, or combine their results across separate
  calls). The diagnostic code is unchanged; per issue #241, neither
  `SPX-G171`'s workspace-graph byte budget nor `SPX-H006`'s path budget was
  raised, because no session has evidence that a higher value keeps the
  workspace graph or the semantic cache finite - both remain documented,
  regression-pinned limits in the completion matrix rather than raised
  ceilings. A boundary fixture pinning the exact measured terminal-path count
  at the crossover (98,300 paths for 15 independent branch terms, not the
  naive `2^15 = 32,768` estimate the previous fixture comment assumed without
  checking) replaces the earlier code-only assertion, plus a dedicated
  regression that fails if the message regresses to the old cause-free
  wording.

- Freeze the Public Generic Boundary Profile, Descriptor and Carrier v1, and
  add a reference codec for the descriptor and carrier wire formats. The same
  callable generic boundary had been described three times by three
  overlapping issue packs, with a real scope conflict between a minimal
  one-owned-`Bytes` slice and a contract admitting nested finite records. One
  admission profile now settles it with an explicit in, deferred and excluded
  table, so downstream implementation work has a single contract to build
  against rather than three. Two classifications - owned generic variants and
  public generic templates - are recorded as contested and awaiting review
  rather than silently decided.

- Specify and implement the Live Invocation Contract v1: invocation identity
  that survives retry, resume and recovery, a causal journal with
  table-driven validation, and a provider-independent `model.invoke` effect
  with an explicit capability requirement, a closed failure domain and
  cancellation checkpoints. Replay makes zero dispatches, and an unrecorded
  result can never be reconstructed by hashing because the journal carries
  response bytes rather than only a digest. Fixture transport only: no
  provider binding, no deployment wiring and no live model call.

- Introduce Assurance Manifest v1, a deterministic per-obligation manifest
  bound to exact source bytes that fails closed on drift. Obligation identity
  keys to a declaration's persistent stable id rather than a byte offset, so
  it survives a pure formatting change, and the assurance lattice is a
  genuine partial order rather than a single ranking - compiler-proved,
  SMT-proved and model-checked are deliberately incomparable. External
  records let later formal-method backends contribute without this module
  changing, so a simple candidate summary never waits on formal proof.

- Freeze the catalog-normalizer acceptance application and an independent
  oracle: 25 requirement ids, 51 known-answer cases split into published and
  hidden, and six runnable negative controls that each provably diverge from
  the correct output. The hidden-case boundary is a review policy rather than
  cryptographic isolation, and the specification says so plainly instead of
  implying a guarantee the repository cannot enforce.

- Preserve comments and unrelated bytes in the v2 `ReplaceExpression` route.
  The transaction previously rejected any workspace containing a comment
  before it even selected an expression, because the shared candidate rebuild
  always reprinted through the comment-oblivious canonical formatter. The
  edited file may now carry comments, preserved by a span-scoped splice that
  is independently reparsed and required to match byte for byte; a comment
  overlapping the edited span is refused rather than silently relocated.
  Every other source keeps the exact comment-free requirement.

- Resolve `core.option` in the `useful-text-consumer.v1` linker, which never
  seeded the compiler prelude its Useful Data sibling relies on, so any
  `match byte_get(...)` in a Project-linked text package failed validation.
  The profile's public signature restrictions are unchanged and pinned by a
  test.

- Bind release publication to the exact-tag gate explicitly, and add a
  reconciliation check for release claims. This caught a live defect: the
  README claimed v0.4.1 was the published tag while citing v0.4.0's date,
  commit and anchor.

- Connect an external coding-agent runner to the existing comparison ledger,
  reusing its plan, trial, ledger, observation and audit schemas unmodified.
  A candidate cannot escape its sandbox, write the finalized ledger, or claim
  its own acceptance: a backend that reports every criterion passed while
  leaving the work undone is still scored as failed. Offline fixture backend
  only; the paid paired pilot needs an approved model budget.

- Correct a stale claim in the doctor provisioner specification, which stated
  the provisioned gate had never executed when nine real runs exist, the most
  recent of which failed.

- Give the MSRV shards the same time budget as the identical `verify-tests`
  command. Both run `scripts/ci-msrv.py --shard`, but the MSRV job had 40
  minutes against that job's 90 while compiling the same workspace on an
  older toolchain. The `integration-1` shard was cut off mid-test on two
  runs while finishing in about 35 minutes on others, so its result reported
  the runner's speed rather than the shard's outcome - and a cancelled
  blocker fails the release gate exactly like a real failure. The coverage
  guarantees are unchanged: the contract still forbids `continue-on-error`,
  `--no-fail-fast`, `--exclude`, `--skip` and caching, and still requires
  the full check and every shard.

## 0.4.1 — 2026-09-11

- Record cross-platform hosted evidence for the public generic ownership
  milestone. The `public-generic-ownership-milestone` job is green on
  `ubuntu-latest`, `macos-latest` and `windows-latest` for implementation
  commit `2ef043ba1b989f49b256e456f71fb6e89068bf33` in [run 34594793245](https://github.com/wavect/semaprax/actions/runs/34594793245), with each leg's log showing all four consumer
  toolchains exercised rather than skipped. Gate PG-8 and the four gates
  whose corpus that job runs - the type grammar, template and ordered
  argument identities, the compatibility rules and the candidate delta -
  move to `Hosted green`. PG-5, PG-6 and PG-7 stay open because the corpus
  contains none of what they ask for, and PG-9, the support and publication
  decision, stays open: public generic ownership remains unsupported and
  unpublished.

- Fix a temporary-path collision between two copies of the same owned-data
  native test helper. `owned_vec_bytes_runtime/native.rs` is
  `#[path]`-included by two modules of one test binary, so it is compiled
  twice and each copy owns a separate case counter starting at zero - while
  both named their scratch files from the process id and that counter alone.
  Two tests in the same process therefore shared a `.c` path and a binary
  path, which is exactly what the hosted shard reported twice: one run could
  not execute a binary a concurrent `clang` still held open (`ETXTBSY`), the
  next could not read a `.c` file the other copy's cleanup had already
  removed. The name now includes the module path, so the two copies cannot
  collide. The generated public generic consumer gate, which also compiles
  and then executes, retries a launch refused with `ETXTBSY` rather than
  adding another way for a foreign fork to redden an unrelated shard.

- Make the generated C and C++ public generic consumers build on Windows.
  The hosted leg found two things a Unix-only run could not: the UCRT marks
  the standard `fopen` deprecated in favour of its own `fopen_s`, which a
  `-Werror` build turns into an error, and a compiled consumer needs the
  host's executable name because Windows resolves a bare `consumer` by
  looking for `consumer.exe`. The generated sources now opt out of that
  deprecation, and the gate names the executable per host.
  The C++ consumer also drops `std::span`, which it used only to carry a
  pointer and a length together: a pointer and a size are the same
  information, so the generated artifact no longer needs a C++20 library
  header and builds under C++17. The compile check now fails on a warning
  or an error in the toolchain's output rather than on any output at all,
  because "compiles warning-free" is the claim; a linker note about
  something else is not evidence about the generated code.

- Make generated public generic consumers independent of the checkout that
  produced them. The fixed part of each consumer is an included template,
  and a Windows checkout delivers `.txt` with CRLF, so every placeholder
  whose match included its newline silently stopped substituting: the
  generated files kept their literal placeholders and lost both their type
  declarations and their embedded metadata. Templates are now normalized at
  generation time, `.gitattributes` pins `.txt` to LF like every other
  embedded text asset, and the generator itself asserts that no generated
  file carries a carriage return or a surviving placeholder — so this class
  fails where it happens rather than as a downstream expectation on one
  platform. A generator that only worked because of a checkout setting was
  not the deterministic generator the milestone claims.

- Guard the Windows checkout of the public generic ownership milestone job.
  Its first hosted run failed on `windows-latest` before any gate executed:
  the checkout itself cannot write this repository's retained evidence paths
  without `core.longpaths`, which every other Windows job already sets. The
  cross-platform leg was therefore reporting a checkout limit, not a
  milestone result.

- Add Public Generic Candidate Delta v1, milestone gate PG-4: a
  candidate-bound delta that describes the selected exports of an immutable
  Project candidate's base and final revisions over the public generic
  grammar, classifies the pair with the PG-3 rules, and binds the candidate
  digest, both Project and workspace revisions, both graph digests and a
  domain-separated facts digest. Inclusion is grammar-strict, so an entry in
  the delta is exactly a candidate public generic signature: no admitted
  export has one today, which makes the generic fixture all-excluded with
  the closed reason `borrowed_byte_view` - and the gate asserts its rendered
  bytes carry no template identity, instance term, record identity, or even
  the grammar's instance sigil. The substantive evidence rides on a Project
  v9 record-returning export, where a real `add_record_field` change is
  `breaking` with the finding on the record that changed and ordered
  arguments, substituted fields and owned leaves retained across mutation,
  recovery-capsule restoration and byte-exact independent replay
  (`SPX-PG301`-`SPX-PG303`).
  The grammar now also exposes `Rejection::ALL` and `Rejection::of`, so a
  consumer recovers a typed reason from the owning artifact instead of
  re-spelling its message, and the compatibility report exposes its digest.

- Add Public Generic Settlement Obligations v1: for one owned admitted
  instance parameter, which owned leaves a boundary is accountable for, in
  which order, how each is discharged, and what is released when a transfer
  fails part way - each fact bound to the compiler's own cleanup facts
  rather than derived beside them. The grammar's owned-leaf paths must equal
  the inventory's structural leaf order; each obligation is paired with its
  liveness flag in flag order and carries that flag's checked drop
  lifecycle, because an obligation whose flag does not match it has no
  stated way to be discharged; and the transfer unit is the cleanup plan's
  single whole live owned place, since reading leaves out of the plan would
  invent a per-leaf transfer the compiler never performs. Release order is
  the exact reverse of the canonical order, and every disagreement is a
  refusal (`SPX-PG501`, `SPX-PG502`) rather than a sort or a repair.
  This is the specification half of milestone gate PG-7, which stays open:
  nothing here allocates, transfers, releases or observes a runtime, and
  there is no public generic boundary to exercise on any engine.

- Wire the public generic ownership milestone corpus into CI as the
  `public-generic-ownership-milestone` job on `ubuntu-latest`,
  `macos-latest` and `windows-latest`, and declare it a release blocker so
  it cannot be satisfied vacuously. It runs the grammar, template-identity,
  compatibility and metadata-consumer projections, the separation gate, the
  frozen Project v9/v11 descriptor refusals of a selected generic result,
  and the four-language consumer gate, and it resolves and prints the
  consumer toolchains each host actually has - a language whose toolchain is
  absent is skipped, which is a narrower run rather than a pass.
  Milestone gate PG-8 stays open: the harness exists, the hosted evidence
  does not, and the gate moves only when the owning document records a run
  and job for an exact implementation commit.

- Add Public Generic Metadata Consumers v1: a Rust, TypeScript/Wasm, C11
  and C++ consumer generated from a candidate public generic surface, plus
  the length-framed canonical metadata format they read. Before a foreign
  toolchain can call a public generic export, several of them have to agree
  on what its types are and refuse everything else - and that is
  falsifiable without a calling convention. All four consumers are compiled
  warning-free and run for real against nine hostile documents, and each
  must report the same closed refusal (`malformed`, `term`, `mismatch`) as
  the others and as the Rust reference reader; the gate fails when no
  toolchain was available rather than passing silently. Identifiers come
  from term bytes rather than display names, nested instances are declared
  before their holders so C and C++ never see an incomplete type, and
  regeneration is byte-identical.
  This closes the grammar half of milestone gates PG-5 and PG-6; both stay
  open for their descriptor half, because no public generic descriptor,
  carrier or calling convention exists. No generated consumer receives a
  SEMAPRAX value, allocates one, frees one, or links against anything, and
  every generated file says so in its own banner.

- Add Public Generic Compatibility v1, gate PG-3 of the public generic
  ownership milestone: candidate surfaces over the type grammar, and a
  closed thirteen-reason classification of one ordered pair of them. The
  rules are deliberately stricter than source compatibility, because a
  foreign consumer reads the whole substituted field tree and owned-leaf
  shape of what it receives: adding a Copy field to a nested reachable
  record is breaking even though no canonical term, parameter position or
  owned-leaf path moves, and it is reported once on the record that changed
  rather than on every position mentioning it. Presentation is never
  compatibility - renaming records, type parameters, fields, exports and
  parameters yields `unchanged` with an identical surface digest - and a
  parameter's value identity is excluded for the same reason the repository
  excludes it elsewhere: a revision-scoped fact must not move a verdict.
  A signature position that is not a data type gets its own closed
  `view:` vocabulary instead of widening the grammar. Both artifacts are
  canonical JSON with directional byte-exact replay
  (`SPX-PG201`-`SPX-PG204`), and both record that no semantic-version,
  support, publication or runtime conclusion follows from a verdict.
  A candidate surface is a description, not an admission: no public generic
  signature is admitted, and local evidence is the only evidence.

- Add Public Generic Type Grammar v1, gates PG-1 and PG-2 of the public
  generic ownership milestone: a versioned, target-neutral term for the
  types a public generic surface could name, plus the explicit template and
  ordered argument identities derived from it. Identities are
  length-prefixed in bytes, so an identity holding the grammar's own
  punctuation still round trips and two distinct types can never render
  alike; digests are computed over persistent identities, declared arity and
  ordered parameter positions, so a record, parameter or field display
  rename changes nothing while argument permutation, duplication or
  substitution changes the instance identity and omission is an
  `arity_mismatch` refusal. The vocabulary is closed to the eight Copy
  scalars, direct `Bytes` and fully concrete authored records; the other
  twelve reasons reject, bounds refuse instead of truncating, and replay is
  byte-exact against an independent recomputation. It is deliberately not
  the compiler's internal, unversioned `identity_key` spelling.
  Local evidence only: no hosted run, no descriptor, carrier, package or
  consumer selects the grammar, and public generic ownership remains
  unsupported and unpublished.

- Make public generic ownership a separate milestone instead of a side
  effect of the internal generic closure. The new
  [Public Generic Ownership milestone](docs/PUBLIC-GENERIC-OWNERSHIP-MILESTONE-V1.md)
  owns nine prerequisite gates - a versioned target-neutral type grammar,
  explicit template and ordered argument identities, semantic compatibility
  rules, candidate ABI-delta evidence, generated Rust/TypeScript-Wasm/C/C++
  consumers, hostile metadata replay, owned allocation and failure
  settlement, cross-platform hosted evidence, and the explicit support and
  publication decision - plus separation invariants and an executable
  separation gate. The gate selects a generic template, a concrete
  generic-instance result and an owned generic parameter through the
  canonical ABI report, C header emission and the public scalar Wasm export
  edge, and pins each closed refusal, so an internal admission that starts
  producing a public generic surface reddens the build rather than becoming
  a silent public claim. Public generic ownership remains unsupported and
  unpublished; no grammar, descriptor, carrier or consumer is added here.

- Add effect-free listing cursors to `std.fs`, so the canonical
  immediate-name listing `list` already returns can be walked without a
  provider or any further authority: entry counting, per-entry span offsets,
  and an entry-name validity predicate rejecting an empty name, an embedded
  separator or NUL byte, and the two traversal names. No function gained an
  effect and the module's capability list is unchanged; recursive traversal,
  streaming and richer metadata remain Missing.

- Add the bundled `std.env.policy` package: a portable environment-variable
  name predicate, a value predicate, and a `NAME=VALUE` assignment cursor, all
  effect-free offset computations over borrowed bytes. It is a sibling package
  rather than more of `std.env` because the completion gate requires every
  `std.env` function to declare `process.environment.read`, and these functions
  read no environment - declaring that effect to satisfy a gate would claim a
  capability they never exercise.

- Add effect-free settlement and argument policy to `std.process`:
  classification of an existing settlement value as a normal exit or a signal
  termination - the only two kinds the termination encoding defines, per the
  `low2-kind-0-exit-u32-or-1-signal` graph fact - exit-code extraction defined
  only where the process exited normally, and argument-vector admissibility
  over borrowed bytes. A deadline expiry is deliberately not a settlement
  class: it is a call-level failure that prevents an output from existing, so
  classifying an unused bit pattern as one would invent a value no provider
  emits. Only `std.process.run` still carries `process.execute`; the new
  functions perform nothing and grant nothing, and broader physical-provider
  and general process support remain open.

- Add a checked lifecycle policy to `std.agent`: an admitted stage-transition
  predicate total over the lifecycle vocabulary, a terminality predicate
  consistent with it, and a deterministic bounded retry policy whose backoff is
  a pure function of the attempt count. These describe checked meaning only:
  no clock is read, no stage is executed, and the package gains no capability,
  effect or permit. Native and Wasm execution of these ordinary library
  functions still does not execute Agent stages.

- Add quoted-key validation and value cursors to `std.data.toml`, closing the
  key half of its recorded gap. `basic_quoted_key_end` admits the TOML
  basic-string escapes and rejects an unterminated string, a raw control byte
  and any other escape; `literal_quoted_key_end` admits `'...'` with no escapes;
  `key_end` dispatches the bare, basic-quoted and literal-quoted forms; and
  `value_start`, `value_content_end` and `value_end` bound a value quote-aware,
  so a `#` inside quotes does not open a comment and trailing spaces and tabs
  are excluded. Every scanner is an allocation-free offset computation and
  reports failure through the `byte_len + 1 + offset` sentinel the
  `std.data.json` family already uses for arbitrary-start scanners. Values stay
  uninterpreted bytes; tables, decoding, typed values and encoding remain
  Missing. Bare-key admission walks bytes directly instead of testing a growing
  `byte_range` sub-slice: that shape is admitted by the checker and executes on
  the interpreter and native C11, but emits a corrupt slice carrier on the Core
  Wasm lane, filed as issue #100 with a single-variable reproduction.

- Add `decoded_token_eq` to `std.data.json.dec`: two JSON string tokens in one
  input compared by their decoded bytes through the existing pull surface, with
  no buffer, so `"a\u0062"` and `"ab"` are equal keys and `"\n"` equals
  `"\u000a"`. Tokens of different decoded length are unequal without decoding
  either fully. Duplicate-key detection over a whole document still needs the
  object walk in `std.data.json.doc` and remains Missing.

- Add the bundled `std.encoding.base64` package,
  [Base64 v1](docs/BASE64-V1.md): pull-based padded standard Base64 encoding
  over a borrowed byte view. `len` gives the padded output length and `byte`
  gives its byte at one index, both computed from the input alone with no
  buffer, so a caller writes the digits into capacity it already owns. It is a
  sibling package because `std.encoding` sits on the default Project v1 route,
  which admits only Copy scalar boundaries and rejects a borrowed view.
  Decoding of padded input, streaming, and URL-safe or unpadded alphabets
  remain Missing.

- Add `wrapping_mul` to `std.num.overflow`, closing the wrapping-multiplication
  gap its own required scope recorded as Missing. The result is exact
  two's-complement wrapping for every operand pair, including `i64::MIN * -1`,
  `i64::MIN * i64::MIN` and `i64::MAX * 2`, and it never evaluates an
  overflowing intermediate under the language's checked arithmetic.

- Add a failure-mask discipline to `std.test`, so a nonzero test result names
  the failing check instead of merely being nonzero: `bit_for` is the bit an
  indexed case owns, `bit_is_set` reports membership, `record_failure`
  accumulates one case's verdict, and `first_failure` and `failure_count`
  report the lowest failing index and the number of failures. Indexes run 0 to
  62, `record_failure` refuses a bit another case already claimed, and the
  accumulated mask is monotonic, so two cases cannot silently share a bit and
  hide one another. The package's own conformance and examples modules now use
  the discipline they document.

- Add quote-aware field cursors to `std.data.csv`: `field_end` stops at the
  first comma outside quotes, `field_start` opens the next field,
  `field_is_quoted` reports the quoted form, and `content_start` and
  `content_end` bound a field's content excluding its surrounding quotes. A
  `""` inside a quoted field is one escaped quote that never ends the field and
  stays in the content bytes, so decoding remains the caller's step. Empty
  records, empty quoted fields and consecutive commas yield exact offsets, and
  a walk terminates because the last field's `field_start` is the record
  length. The offsets compose with the `std.io.lines` record content and the
  `std.bytes` trimming offsets, and the package conformance adds a `cursors`
  bit to its failure mask on the interpreter, native C11 `-O0`/`-O2` and Core
  Wasm. Typed fields, decoded content, dialects, streaming and writing remain
  Missing.

- Add explicit level filtering to `std.log` under the existing
  [Log Writer v1](docs/LOG-WRITER-V1.md) contract: `level_enabled` compares a
  level against a threshold on the existing 0-5 scale, `event_admitted` is the
  borrowed observer that is true only when the event both passes the threshold
  and fits the writer's live capacity, `discard_event` is the named drop path
  that consumes the event and returns the Writer untouched, and
  `append_event_if` writes a passing event exactly as `append_event` does.
  Capacity is required only for an event that is actually written, so a small
  buffer with a high threshold is a valid composition rather than a contract
  failure, and a filtered event releases its name and message bytes through
  ordinary lexical cleanup instead of being buffered. Three named cases join
  the logger corpus as individual bounded projects on the interpreter, native
  C11 `-O0`/`-O2` and repeated Core Wasm. No sink, queue, timestamp source,
  redaction or concurrency is added.

- Add span cursors to `std.bytes`: `is_space`, `trim_start`, `trim_end` and
  `is_blank` for ASCII whitespace, and `field_end`, `field_start` and
  `field_count` for delimiter-separated fields. Field walking preserves empty
  fields, so `a,,b` is three fields and a trailing delimiter opens one final
  empty field, and every operation is a borrowed-view offset computation with
  no allocation and no copy. The offsets compose directly with the
  `std.io.lines` line content, so a bounded caller can walk a delimited record
  and trim each field without a buffer. Whitespace is exactly space, tab,
  carriage return and line feed; no Unicode whitespace class, quoting or
  escaping policy is implied.

- Add field padding to `std.format` under the existing
  [Format Writer v1](docs/FORMAT-WRITER-V1.md) contract: `pad_len` is the field
  width actually written (never narrower than the content), `append_fill`
  writes one repeated byte, `append_str_left` writes left-aligned text and
  `append_usize_right` right-aligned decimals. Each padded operation
  preflights the whole field rather than only its content, so a buffer that
  could hold the content but not its padding fails before any byte is written,
  and content longer than the field is written in full rather than truncated.
  Five named cases join the existing corpus as individual bounded projects on
  the interpreter, native C11 `-O0`/`-O2` and repeated Core Wasm, and four
  further short or forged-output cases reject padded writes with the exact
  `requires`-false status. Alignment is byte alignment and the fill byte
  carries no character or locale policy; general format strings, arbitrary
  alignment modes, grouping separators and floating-point rendering remain
  Missing.

- Add the bundled `std.path.normalize` package,
  [Path Normalization v1](docs/PATH-NORMALIZATION-V1.md): lexical normalization
  of the typed `Path` values `std.path.value` owns. `normalized_len` and
  `normalized_byte` give the exact normalized length and each byte of a
  borrowed view with no buffer, and `into(borrow Path, own Bytes) -> Path`
  writes the normalized form into caller-supplied capacity after an exact
  preflight while preserving the borrowed input. A separator run collapses, `.`
  vanishes, `..` cancels the nearest retained segment, an uncancelled `..` is
  kept for a relative path and dropped at an absolute root, a trailing
  separator is removed, and an empty result is `.` or `/`, so a normalized
  Path is never zero bytes. Retention is decided without a stack, as the
  clamped maximum prefix sum of a forward walk that scores `..` as `+1` and an
  ordinary segment as `-1`. Ten named cases run as individual bounded projects
  on the interpreter, native C11 `-O0`/`-O2` and repeated Core Wasm, with
  hostile cases rejecting a short buffer, a forged Path and out-of-range
  offsets, and a graph check replaying the projection and its per-shape
  cleanup-schema selection. No public export, descriptor, platform conversion
  or filesystem authority is added, and `std.path.value` stays byte-identical.

- Add the bundled `std.io.lines` package, [IO Lines v1](docs/IO-LINES-V1.md):
  bounded line processing over the unchanged `std.io` Reader and Writer
  cursors. `line_end`, `line_terminated` and
  `line_content_len` observe a borrowed byte view; `reader_line_len` and
  `reader_line_complete` observe a borrowed Reader; `reader_line_into` copies
  one line's content into caller-supplied Writer capacity after an exact
  preflight; `reader_next_line` is the consuming transition past the line and
  its terminator. One line feed terminates a line, whose content excludes that
  byte and one immediately preceding carriage return, so LF and CRLF inputs
  yield identical content and a bare carriage return stays content. Eight named
  cases run as individual bounded projects on the interpreter, native C11
  `-O0`/`-O2` and repeated Core Wasm, and nine hostile cases reject short
  capacity, forged cursors and out-of-range view offsets with the exact
  `requires`-false status. A graph check pins the selected cleanup schema per
  shape: v5 for the copy and the record observers, v2 for the pure view
  helpers, with the caller's Writer as the copy's one owned parameter. No public export, descriptor, stream, standard
  stream or host authority is added, and existing cursor signatures, contracts
  and identities are unchanged.

- Add the private owned iterator payload profile for `Iter<Bytes>` and
  `IterStep<Bytes>`. Prelude v8, Graph v45, and CleanupPlan v13 bind the exact
  detached-prefix item/rest transfer and preserve prior scalar iterator,
  vector, and cache bytes. Focused library, interpreter/native C11 `-O0`/`-O2`,
  workspace, and Core Wasm checks pass, including graph/Prelude and cache
  replay, exact failure settlement, and malformed-provider output rejection.
  Hosted promotion, public generic iterator ABI, and broader iterator scope
  remain pending. Also close the omitted Graph v44 process-profile rejection
  in frozen evidence admission without changing serialized graph bytes.

- Extend `std.test.bytes` with reusable named snapshot fixtures and Copy
  comparison results containing equality, lengths, and the relative first
  difference. Borrowed fixtures and Reader cursors remain unchanged, with no
  new allocation or filesystem authority. Focused source-package and bundled
  consumer cases pass locally across the interpreter, C11 O0/O2, and repeated
  Core Wasm, including invalid-cursor cleanup.

- Add authenticated Project-linked State migration and workspace typed binding.
  A single declared or explicitly imported migration function extends the
  checked role closure; additive migration root v3 binds its exact source
  association while legacy root v1/v2 bytes remain unchanged. Durable recovery
  reconstructs the closure without evaluating migration again, preserves
  cumulative usage, and skips destination initialization. Focused local linked
  migration, selection refusal, recovery, and workspace currentness cases pass.

- Add the private `std.agent` source package and the linked Project lifecycle
  boundary. Task, Context, Observation, and Outcome records plus checked
  lifecycle and outcome helpers compose as ordinary source data; the linked
  path derives the Proposal schema from the retained Project closure and binds
  it to the additive typed iterative runtime while preserving the existing
  scalar/public package bytes and direct Runtime v2 binder. All six linked-role
  cases pass locally, and the four standard-library testing cases pass across
  interpreter, native C11 `-O0`/`-O2`, and Core Wasm, including epoch boundary
  cases and the byte-assertion regression. Linked migration, native/Wasm
  Agent-stage execution, live providers, hosted support, and full `std.agent`
  completion remain open.

- Add the sibling private `std.test.bytes` assertion package while preserving
  the existing scalar `std.test` facade and public descriptor. Exact slice and
  Reader-suffix comparisons, cursor validation, unchanged Reader positions, and
  failure-bit wrappers use the private `useful-data.v2` profile with no exports
  and exact `std.io` plus `std.test` dependencies. Execution and invalid-cursor
  gates pass locally; richer fixtures, property tests, fuzzing, and snapshots
  remain open.

- Record the private `std.process` bounded process slice. Example, conformance,
  and bundled-consumer commands pass locally on the interpreter, native C11
  `-O0`/`-O2`, and Core Wasm. Five focused physical Darwin provider cases also
  pass, covering the registered local provider path. Linux physical-provider,
  hosted, public, and broader process support remain open; this does not promote
  the full process profile.

- Record the nested record-match entry/result phase ownership fix. The named
  `nested_record_match_entry_and_result_phases_settle_across_engines` gate now
  passes interpreter, native, and Core Wasm success and postcondition-failure
  cases while preserving canonical cleanup vectors.

- Add the private `std.env` environment snapshot package and Project
  `environment-io.v1` composition. The bounded operation vocabulary, immutable
  UTF-8 snapshot constructor, capability checks, graph facts, package metadata,
  catalogs, and source links are in place. Four focused carrier cases cover
  empty, success, failure, and malformed Wasm paths; fourteen selected library
  checks cover the snapshot and environment admission surfaces, including the
  provider constructor on Node. The named gates
  `environment_manifest_is_canonical_and_authority_is_closed` and
  `environment_package_executes_all_functions_with_injected_snapshot` pass:
  the two Project commands pass on the
  interpreter, native C11, and repeated Core Wasm, including the bundled
  consumer; five focused useful-data environment checks also pass. The package
  is local/private evidence only, with no hosted CI or public ABI claim.

- Add the private `std.log` structured JSON-lines Writer. Its owned `Event`
  carries level, sequence, name, and message fields; append preflights level,
  UTF-8, and complete caller-owned Writer capacity before emitting one exact
  line. It composes bundled JSON UTF-8, JSON writing, and IO helpers without
  hidden allocation or ambient effects. The canonical package and fifteen
  expanded fixtures pass on interpreter, C11 `-O0`/`-O2`, and repeated Core
  Wasm with exact zero-to-three live Bytes bounds. Nine invalid-event/output
  cases pass twice with exact contract status. A direct ASCII validation path
  keeps the 300-byte message within unchanged interpreter fuel; the existing
  UTF-8 package conformance passes on all three backends. Catalog, metadata,
  formatting, links, and module-size checks pass. Broader Everyday logging
  remains Partial; no public ABI or hosted support is promoted.

- Add the private `std.format` Writer append slice: `append_str`,
  `append_i64`, `append_usize`, and `append_bool` preflight exact caller-owned
  `std.io.Writer` capacity and return the advanced writer. Checked digit,
  decimal-byte, and length helpers supply deterministic output without hidden
  allocation or effects under the private `useful-data.v2` profile; the
  package has no public exports. Local verification now passes seven
  owned-function-import unit tests,
  including borrowed-`str` and ordinary owned-byte-record positives plus
  non-byte-record refusal; eight individually runnable named SPX tests pass on
  the interpreter, native C11 `-O0`/`-O2`, and repeated Core Wasm with a strict
  two-entry byte arena (the pure helper case uses zero allocation). Five
  short/forged-output preflight cases pass twice with exact `requires`-false
  status through the bundled `std.format` consumer and transitive `std.io`;
  metadata and catalog regeneration pass. Named tests run individually
  because the per-function static allocation limit is unchanged. General
  format strings and floating-point rendering remain outside this slice, with
  no hosted or production claim.

- Add allocation-free JSON cursor adapters: `decode_into` and `quoted_into`
  consume an owned `Writer` after exact capacity preflight while borrowing a
  `Reader`, and `count_into` renders a `usize` value into that writer. The
  additive Project v16 `useful-data.v2` profile keeps private owned cursor
  composition separate from the frozen Useful Data v1 byte-export boundary.
  Legacy byte-only consumers retain their public boundary while unused newer
  dependency members stay outside the linked program.
  The standalone decoder/writer corpus passes on the interpreter, native C11
  `-O0`/`-O2`, and repeated Core Wasm, including a 300-byte decoded input; six
  malformed-input, insufficient-capacity, and forged-cursor contract-rejection
  cases pass. The named Project v16 gate
  `profile_admission::project_v16_json_cursor_public_facade_replays_and_executes`
  passes deterministic npm reconstruction, replay, and Node execution.
  The named cross-package gate
  `private_json_cursor_roundtrip_executes_across_project_backends` passes the
  local interpreter entry and repeated test, native C11 `-O0`/`-O2`, and
  repeated Core Wasm with a strict two-entry arena under the unchanged 16 MiB
  budget. These are local observations and do not claim hosted or public
  support.

- Refine workspace build-memory prebounds using bounded dependency identities
  and proven AST storage facts. Earlier successful budget receipts and fixed
  limits remain unchanged; a refused production build may retry once with the
  tighter bound after discarding its partial core and staged cache entries.
  Explicit smaller limits and nested budgets keep their original single-attempt
  behavior. JSON conformance scratch directories now remain distinct when
  decoder and writer checks run concurrently.

- Extend private `std.fs` with typed metadata, canonical immediate directory
  listing, directory creation/removal, and atomic file replacement through
  explicit providers. Project v15 and Graph v42 preserve the v1 profiles.
  Typed commands run on the interpreter, C11 O0/O2 and Core Wasm; malformed
  directory results fail before owned publication. Unix providers retain a
  directory descriptor and use same-parent rename for atomic replacement,
  without a durability claim. Private owned-input calls can return checked
  Copy-only records such as FileInfo; public ABI boundaries stay unchanged.

- Add bounded filesystem reads and create-new writes through explicit providers,
  with source-authored `std.fs` composition of Path, Reader and Writer, bundled
  dependencies, Graph v41 replay, and the private Project v14 execution profile.
  Interpreter, C11 O0/O2 and Core Wasm cover typed operations, byte/operation
  limits, failure priority, repeated calls and owned-result cleanup. The Unix
  provider retains a directory descriptor and rejects symlink traversal; writes
  never overwrite and do not promise rollback of physical effects. Broader
  filesystem facilities and cross-platform promotion remain open.

- Add the source-authored `std.path.value` owned Path library with checked
  logical prefixes, lexical queries, consuming parent traversal and joins into
  caller-supplied buffers. Bundled dependency composition preserves the original
  `std.path` byte helpers and adds no filesystem authority or public nominal ABI.
  Shared-loan replay now authenticates completion of synchronous borrowed calls
  used directly as contract roots, preserving previously accepted plan bytes.

- Add source-authored `std.io` Reader/Writer cursors over caller-owned Bytes,
  checked bounds, consuming transitions and bundled dependency use. Internal
  Project calls now compose explicit owned-record signatures, and empty-export
  owned-data libraries run in both manifest layouts without a public descriptor.
  Independent cleanup replay and interpreter/native/Wasm lanes retain result
  transfers before arm cleanup. Focused tests cover binary roundtrips, contract
  failures, borrowed-owner escape, forged identities and missing transfers;
  generated catalogs now include the record declarations.

- Preserve both immutable workspace generations through typed Agent migration,
  durable recovery and chained migration using additive provenance receipts.
  Recovery rechecks compiler-owned bindings and exact receipts; current-run
  paths refuse stale destinations before host or store work. Focused local
  tests cover recovered A→B→C chains, forged receipts, stale destinations and
  preserved terminal failures after checkpoint acknowledgement loss.

- Bind acyclic, iterative, and typed Agent runtimes to exact immutable semantic
  service generations through additive workspace execution receipts. Replaying
  a receipt reselects compiler-owned state; current execution rejects drift
  before host calls while historical bindings retain their original generation.
  Join only actual producer evidence and preserve typed durable checkpoint
  replay. Twelve focused execution-root tests pass locally, including the new
  V1/V2/V3, forgery, refresh, and zero-host replay cases.
- Complete private native-builder cleanup test visitors for the additive
  iterator renewal transitions; the private test target compiles locally.

- Add private one/two-parameter generic iterator operations with ordered Copy
  substitutions, explicit argument permutation, and authored map/filter/fold.
  Conditional same-owner Vec updates inside consuming loops use additive
  CleanupPlan v12 reservation/renewal facts and Graph v40; ordinary loops keep
  v11/v39 semantics. Replay rejects missing renewal facts and schema downgrades.
  Native layout discovery now includes retained concrete function bodies.
  Focused local runtime and projection evidence is recorded in
  [Generic Iterator Operations v1](docs/GENERIC-ITERATOR-OPERATIONS-V1.md);
  public generic ABI and hosted promotion remain separate.

- Separate cross-platform Rust build validation from focused runtime evidence
  in CI, retaining both as release blockers. Run the complete MSRV check once
  across its four test shards and remove two identical generic-lane test
  repetitions. Cache the pinned mdBook tool and upload the book only for Pages
  deployment. Hosted timing and platform validation remain pending.

- Add private consuming `for own` traversal over scalar iterators, including
  generic callbacks and same-owner vector accumulation. The hidden Step
  protocol preserves exact loop ownership with additive CleanupPlan v11 and
  Graph v39. Fix native conditional owner materialization and Wasm borrowed
  remainder/aliased-move handling. Focused interpreter, C11 O0/O2, Core-Wasm,
  graph and ProgramRoot replay checks pass locally; hosted promotion is pending.

- Compose private generic iterator helpers with scalar callbacks and step
  reconstruction. Source and HIR retain scoped `Iter<T>`/`IterStep<T>` ownership;
  existing Prelude v7, CleanupPlan v10, and Graph v38 remain authoritative.
  The eight-scalar runtime corpus passes interpreter, C11 O0/O2, and Core Wasm,
  including callback contract failure and repeated settlement. Graph and
  ProgramRoot reject forged instance/scoped identities and changed source.
  Public iterator ABI and consuming loops remain separate work.
- Repair the prior head's CI failures by consolidating Closure test visitors,
  keeping production iterator/prelude helpers before test modules, and
  completing closure/iterator documentation metadata and catalog entries.

- Repair local-only iterator step construction across prelude selection, graph
  classification, cleanup case-state replay, backend runtime activation, and
  canonical owning matches. Add repeated cross-engine regressions for bound
  and direct `Done` constructors; preserve legacy graph and prelude selection.
  Retain complete iterator declaration and cleanup facts in both workspace
  linkers, restore Box's frozen prelude slice, and verify ProgramRoot replay.

- Add the private Owning Iterators v1 implementation tranche for scalar
  `Iter<T>`/`IterStep<T>` and consuming `vec_into_iter`/`iter_next`, with
  Prelude v7, CleanupPlan v10, Graph v38, and ProgramRoot binding. Local
  interpreter and C11 O0/O2 observations cover all eight scalar types, order,
  empty/exhaustion, early drop, `Done`/`Yield` reconstruction, contracts,
  private returns, and forged native cursors. The same corpus passes Core Wasm with exact scope settlement; hosted promotion and the
  broader iterator, owning-payload, lazy-adapter, and public-ABI work remain
  pending.

- Repair Closure exhaustiveness in projection and semantic test traversals and
  native-builder mutable AST traversal, plus narrowly mechanical `-D warnings`
  hygiene exposed by the cancelled CI run. Hosted revalidation remains pending.

- Add scalar closure construction inside generic collection functions and bounded
  loops, with concrete instance identity remapping, independent scoped HIR
  validation, and source-only template body facts in Graph v37/ProgramRoot.
  Preserve per-iteration snapshots and collection settlement across interpreter,
  native C11, and Core Wasm; extend native Rust builder accounting while keeping
  its public callable boundary closed.

- Add private scalar snapshot Closures v1: exact AST/HIR cache carriers,
  Graph v37 and SemanticProgram v5/ProgramRoot replay, and local interpreter,
  C11 O0/O2, and Core-Wasm evidence for snapshot timing and captured generic
  Vec map/filter/fold composition. Owning captures, public callable ABI, and
  hosted promotion remain pending.

- Add private noncapturing Function Values v1 with checked declaration-identity
  references and indirect invocation, Graph v36 projection, and retained
  SemanticProgram v3 callable closures. Public ABI and hosted promotion remain
  outside this additive profile.

- Add the private generic-collection callback profile for Function Values v2;
  focused collection execution and ownership checks remain pending.

- Extend argument inference through nested omitted calls and generic callers, retaining scoped symbolic forwarding identities, independent bounded evidence, exact graph/root replay and ordinary evaluation-once ownership settlement.

- Extend private generic argument inference to complete ordered vectors and bounded expression type evidence, with independent source/HIR derivation and unchanged concrete instance, ownership and cleanup admission.

- Add durable Agent migration handoffs, trusted-store destination recovery and repeated revision chains with cumulative call, byte, stage and fuel accounting; preserve frozen operation checkpoint v2 bytes and bind additive migrated evidence to the handoff.

- Add private `Vec<Bytes>` push, replacement, reserve, clear and lexical cleanup across checked source/HIR, interpreter, C11 and Core Wasm. Mutations stage vector and payload owners together and fail before transfer; successful replacement drops the old payload once. Prelude v6 and explicit v2 host imports bind the new meaning, including graph and ProgramRoot replay. Scalar storage and prior prelude contracts remain frozen; focused local evidence is separate from hosted and public promotion.

- Add private owned `Box<Bytes>` allocation and consuming extraction across source/HIR, interpreter, native C11 and Core Wasm. Prelude v5 binds the additive contract; v2 Wasm imports prevent a legacy scalar host from silently leaking the payload. Allocation refusal keeps the staged Bytes owner live until ordinary cleanup, independently replayed before lowering. Focused local probes cover success, contract failure, allocation refusal, repeated settlement and frozen scalar compatibility; hosted and public promotion remain pending.

- Added exact argument-directed generic inference at monomorphic call sites,
  preserving explicit concrete HIR instances and ownership transfer boundaries.
  Seven language checks, private ProgramRoot replay and all-eight-scalar runtime
  success/failure settlement pass locally.
- Added consuming State migration from actual durable Suspend evidence into a
  differently rooted retained Agent, through a pure checked function replayed
  twice. Destination execution skips initialize, binds fresh authorizations and
  retains prior call, byte, stage and fuel charges, including failed migration
  fuel reservations. Focused unit and joined-runtime checks pass locally.
- Fixed YAML interpretation of unquoted Rust test-prefix selectors in CI run
  steps; GitHub had rejected the workflow before creating jobs. Added focused
  inference and migration selectors. Hosted execution remains unobserved.

- Added trusted-store checkpoints around each typed iterative effect, with
  persisted stage fuel reservations, intent/observation/transition generations,
  exact call and byte accounting, fresh-authorized recovery, and fail-closed
  uncertain delivery. Terminal failure survives a lost final store acknowledgement.
  Four execution and eight hostile decoder checks pass locally.

- Added private authored generic variants with one owned Bytes case and all
  eight Copy substitutions, including owning match/branch/call composition.
  Native selected-case destructuring now precedes arm construction, with
  outgoing ownership transferred only after the result exists. The 18-profile
  runtime corpus passes on interpreter, native O0/O2 and Core Wasm.
  Exact private variant/collection signatures now survive HIR linking; attempted
  public owning results reach the unchanged Scalar Export Profile and reject
  with its SPX-W115 diagnostic instead of the earlier private-linker SPX-H006.

- Added a deployed typed scalar operation registry with exact argument/result
  contracts, per-turn authorization, and call/byte ceilings. Direct Runtime v2
  compiles retained Agent source into this iterative product and joins its actual
  execution to deployment, instance and evidence roots. Five registry checks and
  the three-turn/two-operation Runtime integration pass locally.

- Added private generic Box/Vec functions over all eight Copy scalars, with
  exact source/HIR materialization, graph and ProgramRoot replay, and runtime
  success/failure settlement on interpreter, native O0/O2 and Core Wasm.
  Native intrinsic arguments now stage through the canonical transfer boundary;
  owned collection parameters reference their live cleanup slots. Interpreter
  report replay recognizes only the finite existing Box/Vec status tables.
- Added bounded iterative Agent Step execution with fresh per-turn authorization,
  cancellation and budget ceilings, exact source-Agent binding, and immutable
  invocation-bound evidence. Joined roots associate retained ProgramRoot v1-v3,
  deployment, invocation and actual one-pass or iterative execution. Iterative
  execution obeys both deployed turn and call ceilings. Copy-only Observation
  results use a narrow retained-call extension. Focused local checks pass;
  typed multi-effect checkpoints and migration remain follow-on work.
- Made the generated Proposal-client execution gate portable across Linux,
  macOS and Windows with exact UTF-8/LF output and provisioned TypeScript JS
  execution through Node. All three clients compile and execute locally on
  macOS; the added blocking CI matrix awaits exact-head hosted evidence.

- Added structural nested generic record composition and multiple owning
  parameters, with explicit reconstruction into different nominal result types.
  Source and HIR validate substituted fields, recursive patterns and complete
  ownership; nested update construction and replay select cleanup v9 after
  concrete substitution. Native owning branches now emit their canonical join
  and staged-call transfers. Focused all-eight-scalar runtime corpora pass on
  interpreter, C11 O0/O2 and Core Wasm, including both branches, nested owner
  replacement, contract and second-argument failure, repeated execution,
  allocation settlement and no additional aggregate memory.copy.

- Added explicit generic argument permutations, repetition and concrete
  substitutions with independent source/HIR proof, cycle rejection and the
  existing 256-instance closure bound. Additive Graph v35 binds symbolic
  caller-parameter/concrete mappings by authenticated expression paths;
  identity-only programs retain v34 bytes. ProgramRoot and bounded context
  expose the same mappings. Focused source, hostile graph, workspace replay
  and interpreter/native O0/O2/Core-Wasm checks pass.

- Extended generic Result propagation to `Result<T, Bytes>` for all eight Copy
  success types. Cleanup consumes the conditional owner without inventing a
  success cleanup slot; interpreter, native and Wasm preserve scalar Ok values
  and owned Err settlement. Forty focused cross-engine success/failure profiles
  pass, with forged empty-case flags and missing residual transitions rejected.

- Added generic `Result<Bytes, E>` relay, explicit forwarding and postfix `?`
  for every Copy error scalar plus `Bytes`. Independent HIR proofs validate
  unused substitutions without requiring a discovered call instance. Existing
  conditional cleanup handles empty scalar-error ownership paths; native
  residual return now preserves those scalar values before publishing the tag.
  Graph v34 and ProgramRoot bind concrete variant and residual facts across
  private function boundaries. Focused local runtime evidence covers 45
  success/failure profiles on interpreter, C O0/O2 and Core-Wasm; public generic
  descriptors remain closed. This begins GEN-06, not the end of the full goal.

- Completed Graph-v34 type facts for concrete generic instance signatures and
  bodies, including template-only context selection. Frozen legacy graph
  collection remains unchanged. Added focused hosted compatibility selectors
  for existing Component byte known answers and closed public mappings.

- Added Graph v34 concrete generic-instance ownership, revision-bound semantic
  identities, forwarding facts and exact source replay, with independently
  selected cleanup schemas preserving existing CleanupPlan bytes. An additive
  SemanticProgram v2 node binds linked generic closures into ProgramRoot;
  frozen graph consumers and public ABI descriptors retain their prior
  contracts. The independent `GEN-05B generic instance semantic closure` Linux
  job combines the eight-scalar flat and
  nested corpus, graph/schema hostility, expression composition and scalar
  cross-package execution. Focused graph and workspace replay checks pass;
  the bounded GEN-05B/GEN-05C Linux tranche passed for implementation commit
  `c27d06f0cf74749804237a43cc71c248b319cfe0` in
  [CI run 34058787739, job 101555489228](https://github.com/wavect/semaprax/actions/runs/34058787739/job/101555489228).
  This documentation-only successor records that implementation result and
  does not claim a new test run, full-CI passage, or a public generic ABI.
  Semantic instance identities survive
  comment-only edits while ProgramRoot still binds exact source. Preserved
  existing workspace known answers and ownership/range diagnostics.

- Added a source-native Agent-to-Lifecycle v1 bridge and executable generated
  Proposal-client evidence. One checked `.spx` Agent is selected by stable
  identity, lowered through the frozen AgentDefinition-v1 compiler, and bound
  to the existing one-pass lifecycle; replay now requires both exact lifecycle
  bytes and the semantic source revision, so role-body drift fails closed.
  Focused regressions cover completion, refusal, injected-effect failure,
  missing-Agent/incompatible-role cases, stale source, and fail-first oversized or
  malformed replay selectors. A named Linux step also materializes generated
  record and variant clients in isolated temporary projects, strict-compiles
  TypeScript 5.8.3, byte-compiles Python, builds Rust offline with a private
  target, executes all three, and submits their exact integer/UTF-8/case output
  through the canonical decoder. This changes no frozen Agent or Runtime wire
  and adds no provider, tool, filesystem, publication, or ambient authority.

- Extended Exact Program Context v2 with candidate-safe ProgramRoot-v3 refresh.
  A host-authenticated successor context is independently replayed against a
  separately compiler-admitted candidate Project; successor external facts are
  freshly supplied and replayed rather than implicitly copied from the current
  generation. The persistent service selects the active
  workspace/v3 root first, stages the complete candidate generation, cache,
  indexes, unchanged refresh-v1 receipt, and history entry, then adopts them
  together. Stale selectors, cross-paired facts, invalid source, or replay
  failure preserve the active generation and history; old snapshots remain
  exact. This adds no wire, filesystem acquisition, execution, commit, or
  publication authority.

## 0.4.0 — 2026-09-06

- Added Universal Semantic Transaction v2 for one exact, authority-free
  `ReplaceExpression` over an authenticated revision-scoped body-expression
  identity, including explicit monomorphic `main`. Validation rebuilds the
  complete Project Candidate, preserves exact source bytes outside the selected
  span, and emits deterministic separately versioned result/evidence. The
  persistent service adds ordinary and ProgramRoot-v2/v3 validation/replay,
  with exact selection before parsing/history and no replay history append;
  `change preview ... replace-expression` returns exact core output or the
  Candidate structural diff without writes. V1 transaction and CLI bytes are
  unchanged; contract/implicit/generic/synthetic/imported editing, composition,
  commit, publication, and authority remain unavailable.

- Added the product/package contract for Owned Bounded Box v1 and the
  alloc-tier `std.mem` package. Compiler-owned `Box<T>` is limited to the eight
  explicit Copy scalars with `new`, synchronous `get`, consuming `into_inner`,
  one unique non-Copy owner, a 4,096-live-allocation bound, and sticky
  allocation refusal. Additive prelude v4 is Box-selected while v1-v3 and
  authored inline `record Box<T>` programs remain frozen. `std.mem` contains
  exactly three authenticated aliases, explicit 3-by-8 conformance,
  scalar-only example/test results, and no public exports. Focused local
  package, catalog, interpreter, native C11, Core-Wasm, cleanup-replay, and
  hostile-carrier evidence passes; contract-failure cleanup, owned payloads,
  allocator interfaces, public generic ABI, regions, arenas, ARC/shared ownership,
  Iterator integration, hosted evidence, and production support remain open.

- Specified Owned Bounded Vec For Traversal v1: the source form
  `for item in values { body }` accepts one simple immutable `Vec<T>` binding
  over the existing eight Copy scalars, snapshots its length once, visits
  indices in ascending order, freezes the source, and discards each body
  result. Resolver lowering reuses the existing len/get/while HIR, so this adds
  no stable identity, schema, prelude or backend operation, standard-library
  declaration, or public ABI. Focused local language and all-engine runtime
  selectors pass; hosted evidence remains required before promotion. The
  lowering has no origin marker, so ordinary HIR-node validation applies
  instead of a traversal-specific canonical-shape rule. This is not Iterator
  support: objects, `next`,
  adapters, closures, associated types, lifetime inference, consuming
  traversal, owned elements, and `std.iter` remain open.

- Added bounded acyclic generic-to-generic forwarding between already-admitted
  templates. A direct call must pass the callee exactly the caller-owned type-
  parameter vector in declaration order; each concrete caller instance derives
  the deterministic transitive callee-instance closure, bounded at 256 entries. The existing
  direct-scalar and one-owner-identical-result relay profiles, Graph v14, and
  CleanupPlan v2/v5/v7 remain the limits. Focused evidence covers
  chained source/HIR identities in authored FIFO order,
  interpreter/native C11 `-O0`/`-O2`/Core-Wasm settlement, concrete
  non-identity/permutation/cycle rejection, and missing/reordered/forged HIR
  instance rejection.
  This adds no inference, constraints, construction, projection, variants,
  resources, effects, package signature, or public generic ABI.

- Added the exact flat generic owned-record expression-composition tranche.
  One owning parameter returns the identical record while all eight explicit
  Copy substitutions exercise Copy-field projection, top-level immutable
  update, `match borrow` returning a bound Copy field, and `match own`
  reconstructing the same owner. Focused local evidence covers update and
  reconstruction failure settlement, hostile HIR/backend mutation replay,
  repeated interpreter, native C11 `-O0`/`-O2`, and Core-Wasm execution, and
  no added aggregate `memory.copy` against the direct-relay baseline. Generic
  variants, nested expression-result composition, standalone constructors,
  consuming projections, public generic ABI, and Graph/schema widening remain
  closed or unclaimed.

- Added a dedicated Linux CI step for the additive nested generic-owned relay
  and identity-forwarding tranche. It names the exact source/HIR boundary,
  transitive-instance hostility, all-engine settlement, and scalar-only Project
  dependency selectors, and removes their duplicate invocations from the
  adjacent generic-owned step. New locally passing hostility regressions cover
  all eight Copy scalars through a three-template nested relay, forged HIR
  carrier and cleanup vectors, source vector changes and cycles, and the exact
  256/+1 instance-closure bound. The named step is hosted green in CI run
  34048713967, Ubuntu job 101528399406; the older run 34031917437 remains the
  evidence for the pre-nested-relay corpus.

- Re-derived the offline doctor carrier ceiling from measured distributions.
  `DOCTOR_OFFLINE_INPUT_MAX_BYTES` was 536,870,912 bytes, and on a hosted
  `ubuntu-24.04` runner the loader closures of Node v22.23.2 and Rust 1.88.0
  alone encode to 462,424,370 of them, 86% of the ceiling, leaving 74,446,542
  bytes for a whole Clang role. No official LLVM release that runs on 24.04 is
  that small: clang 9.0.1 reaches a 568,339,434-byte carrier, 14.0.0 reaches
  618,411,514 and 17.0.6 reaches 652,142,493, and Ubuntu's own clang-18 closure
  is about 713,000,000. Since `render_rows` admits only Node 22 or newer and
  Rust 1.88 or newer, the two non-Clang roles cannot shrink, so the two
  real-distribution lifecycle fixtures could not be satisfied by any current
  real distribution set. The ceiling is now 1,073,741,824 bytes: 1.65 times the
  measured clang-17 three-role carrier, 1.51 times Ubuntu's clang-18 closure,
  and still 6.25% of a hosted runner's 16 GB. It stays a hard bound and remains
  a resource bound rather than an authority boundary, since seals, digests, the
  release signature, the ELF contract and the closed inventory decide admission
  and none of them depend on size. The delegated cgroup-v2 scope's `memory.max`
  moves with it, from 2 GiB to 4 GiB, and is now derived rather than
  coincidental: an admitted carrier of N bytes costs 2N of unswappable
  residency inside that scope -- the worker's whole-carrier snapshot, which the
  root plan borrows and so cannot release before the tool children run, plus
  the page-rounded tmpfs root written out of it -- while `memory.swap.max` is 0
  and `memory.oom.group` is 1, so an overshoot kills the whole scope instead of
  refusing cleanly. The signed capsule's `MAX_ARTIFACT_BYTES`, the release
  directory's `MAX_ARTIFACT_BYTES` and the signed store's `MAX_FILE_BYTES` are
  held equal to the new ceiling because they bound the same bundle and request
  bytes and the smallest of them is always the effective limit. The derivation
  is recorded beside the constant and in Doctor Sealed Input v1.

- Fixed the offline doctor collector retaining its whole-carrier snapshot
  across the blocking collect. Every fact the collector keeps is already an
  owned copy by that point, and the launcher and provisioner both release
  theirs before creating a child, so the omission left three whole carriers
  resident in the confined scope at once instead of two.

- Fixed the provisioned Linux doctor gate failing before any lifecycle fixture
  ran, with `input permissions or link count are unsafe`. Cargo uplifts each
  binary out of `deps/` as a hard link, so the artifact in the target root has
  link count 2, and `semaprax-doctor-release` refuses an input a second name
  can still reach. The workflow now copies the four images to private
  single-link files and asserts the link count; the packager's check is
  unchanged. The gate also carries all three real roles again, which the
  re-derived ceiling admits.

- Added `std.data.json.dec`, the seventh JSON sibling package, which expands
  JSON string escapes. All eight simple escapes, `\uXXXX`, and surrogate pairs
  decode to their exact UTF-8 bytes; a lone or unpaired surrogate, an unknown
  escape letter, a raw control byte, and an unterminated string are rejected at
  the offset of the backslash or byte that opened them, in the family's
  `usize` result encoding. `decoded_len`/`decoded_size` size the output,
  `token_end`/`emit_len`/`emit_at` stream the decoded bytes with no allocation,
  and `decoded_eq` fills one owned bounded byte buffer of a fixed 256-byte
  capacity through the loop-carried same-owner replacement and compares it to a
  caller-supplied view. The conformance module runs on the interpreter, clang
  C11 `-O0`/`-O2`, and Core Wasm, where the standard-library closure now
  supplies the `env.spx_bytes_zeroed`/`env.spx_bytes_set` host-arena imports and
  asserts that the package's module reaches them, that the arena holds at most
  one live entry, and that it is empty after each of four re-entries. Three
  admission facts were measured rather than assumed and are recorded in the
  specifications: `owned-data-api.v1` is the only project profile that admits
  both a borrowed byte view and the buffer, the buffer must stay out of the
  entry program because a public web build containing it is `SPX-W115`, and a
  `Bytes` value does not cross a module boundary (`SPX-G172`), so a
  caller-provided output buffer is not expressible. The package is committed at
  17,620 B against a measured 18,480 B admitted / 18,653 B first `SPX-G171`;
  `decoded_at` and `decoded_same` were written, measured over that bound, and
  cut.

- Added the bounded ScalarV1 internal flat generic-owned body path. Admission is
  based on the exact reachable ResolvedProgram rather than source or dependency
  provenance; callable and selected-public signatures remain value-scalar. One
  exact project-local Subject-v3 dependency provides cross-package evidence by
  retaining the concrete generic owned-byte record composition internally while
  exposing exactly one no-argument `i64` function. Focused local evidence covers
  exact Report-v2/Subject-v3 resolution, linked-HIR identity and
  cleanup, Project check and repeated entry/test, native C11 `-O0`/`-O2`,
  Core-Wasm, the unchanged scalar Web build, `SPX-W115` public-selection escape
  and `SPX-J123` dependency tamper. This evidence is unhosted. Manifest, report,
  Project, public descriptor, Wasm and package-evidence schemas remain frozen;
  no generic record, owner or aggregate signature crosses a call, package or public
  boundary, and no acquisition, publication or production support follows.

- Extended the bounded concrete generic owned-record relay from its flat
  carrier to any acyclic authored-record template tree within the existing
  64-level, 256-owned-leaf, and 4,096-field work limits. Each template has one
  `own` parameter and an identical return type, requires explicit Copy-scalar
  arguments, and preserves exact template/instance identity and recursive
  ownership through source verification and independent HIR validation.
  Focused local evidence exercises `Box<Pair<Bytes, T>>` and
  `Pair<Box<Bytes>, T>` across all eight scalars in source/HIR, including
  representative source and forged-HIR rejection. The representative
  `bool`/`i64` runtime instances cover success plus
  requires/ensures/staged-call failure settlement on the interpreter, native
  C11 `-O0`/`-O2`, and Core-Wasm.
  Graph v14 and CleanupPlan v7 remain unchanged. The pre-nested-relay
  generic-owned corpus is hosted green in CI run 34031917437, Ubuntu job
  101482963175; this additive nested-relay evidence remains local until its own
  pushed run. Nested-nonflat multiple-owner or non-identical-return
  composition, Project/package/public ABI exposure, and production support
  remain closed; the legacy flat generic-function admission is unchanged.

- Admitted the loop-carried owned byte buffer fill. `bytes_set` gains one
  same-owner replacement shape, `buffer = bytes_set(buffer, index, value)`,
  whose assignment target and buffer operand are the same `let mut` binding:
  the call moves the single owner out and the assignment publishes the returned
  owner back, so exactly one generation is live at every point. It is the only
  `bytes_set` a bounded `while` body admits, so a loop can fill a buffer it did
  not allocate; `bytes_zeroed` stays outside the loop and is still rejected
  there by both the byte-family rule (`SPX-T252`) and the owned byte allocation
  rule (`SPX-T267`). Every other named buffer operand remains `SPX-T271`, a
  borrowed view live across the replacement remains `SPX-T265`, and independent
  HIR validation re-derives the same fact so hostile HIR that swaps two
  replacements' targets fails closed with `SPX-H006`. The fill and a store one
  element past the capacity execute on the reference interpreter, native C11,
  and Core Wasm under Node against a one-entry owned-byte arena across four
  re-entries with no linear-memory copy or growth, and the out-of-range store
  selects the identical `semaprax.byte-buffer.v1` code 1 status on all three
  engines before the owner transfer commits. Capacity growth stays out of
  scope: the allocation capacity is still a literal.

- Added the bounded AGENT-04 generated Proposal-to-Runtime v1 compatibility
  adapter. One exact checked Proposal record or Copy-scalar variant now passes
  the existing decoder before its complete canonical bytes, including the
  terminal LF, become the escaped message of the frozen Runtime v1 final
  action. The adapter performs no case or field translation, reaches no host,
  and cannot select a Runtime tool; `SPX-G578` rejects cross-pair and complete
  escaped-action-bound failures while Proposal `SPX-G550`/`SPX-G551` remain
  unchanged. AgentDefinition, AgentGraph, Proposal Schema, and every Runtime v1
  schema, API, digest and known answer remain frozen. Direct provider Proposal
  input, Runtime tool-action/schema generation, broader Proposal, public ABI,
  and Runtime v2 support remain open.

- Added authority-free Exact Program Context v2, which independently replays
  exact context v1, Contracts and Tests Facts v1, and ProgramRoot v3 before
  requiring the enriched workspace and v3-root selectors across typed query,
  transaction, service, and history paths. The same appended facts descriptor
  is retained in memory; query/result, transaction/evidence, history, service
  receipt, exact-context-v1, and ProgramRoot wires remain unchanged. Exact
  transaction history keeps the authenticated default base workspace identity,
  selector and replay failures append nothing, and exact service refresh plus
  candidate ProgramRoot v3 remain unavailable.

- Added the authority-free Contracts and Tests Facts v1 association and
  ProgramRoot v3. The standalone fact bundle binds one admitted Project,
  semantic Graph, and legacy workspace revision to stable-ID-sorted function
  and function-template rows with ordered checked `requires`/`ensures` facts,
  plus only the declared test `main` and ordinary executable named tests. Its
  closed document explicitly denies coverage, execution, result, and source
  authority claims. ProgramRoot v3 freshly retains all eleven ProgramRoot-v2
  descriptors and three unbound relationships, then appends only the fact
  schema/digest/byte-count descriptor. Canonical Semantic Workspace v1 and
  ProgramRoot v1/v2 identities and bytes remain unchanged. This is inventory
  and association only: contract proof, coverage, test execution, runtime
  roots and authority remain absent; the separate Exact Program Context v2
  entry above records the later typed selector integration.

- Extended the additive Exact Program Context v1 lifecycle through exact query
  replay, transaction replay, and persistent-service history selection. Every
  exact route requires both the enriched workspace revision and ProgramRoot-v2
  digest, retains the selected `ProgramRootV2` only on typed in-memory results,
  and fails closed on stale, reminted, cross-paired, or mutated inputs. Exact
  transaction history records the authenticated default Project-derived base
  workspace identity; read-only replay appends no entry. Universal Semantic
  Query v1, Universal Semantic Transaction v1, service-history v1, receipt,
  ProgramRoot v1/v2, canonical-workspace v1, and other legacy wire bytes remain
  unchanged. Candidate ProgramRoot-v2 derivation and exact refresh remain
  unavailable pending candidate-safe Project Lock replay.

- Corrected the cleanup-plan storage ownership rule so the Owned Bounded Vec
  v1 loop-carried fill is reachable from source, and added
  `examples/vector-stats-project`, the first example that accumulates a
  **variable** number of scalar values and filters them. A storage now belongs
  to the cleanup region that first introduced it. It was previously re-homed
  into whichever region asked for it second, so `values = vec_push<T>(values,
  value)` inside a bounded `while` moved the enclosing binding's slot into the
  loop body's own region: the body's scope exit finalized the vector on every
  iteration, one linearized body pass no longer preserved owned liveness, and
  every such program fail-closed with `SPX-H006` even though source
  verification, HIR validation and independent cleanup replay all admitted it.
  The example initializes one `Vec<i64>` outside a bounded loop whose body
  pushes a computed number of readings, then walks it back through `vec_len`
  and `vec_get` summing only the readings over a threshold. Its gate drives the
  accumulating function at seven element counts and three thresholds and runs
  both the entry and the conformance module on the interpreter, native C11 at
  `-O0` and `-O2`, and Core Wasm under Node against a one-generation host
  arena; the owned-data harness carries the same shape as a focused language
  regression.

- Admitted a computed `usize` element index for the Owned Bounded Byte Buffer
  v1 `bytes_set` store, so a value can be written at an offset a scan
  discovers. The allocation capacity is still one literal at the
  `bytes_zeroed` site (`SPX-T271`), and a literal index at or above that
  capacity, or any index into an empty buffer, stays `SPX-T272`; only what the
  compiler cannot decide moved to run time. `bytes_set` therefore became the
  first fallible compiler-owned byte operation: it carries an ordinary
  `PropagatedCall` status source whose failure is selected **before** the owner
  transfer commits, so an out-of-range store writes nothing, is not a backend
  accident, and leaves the buffer in the canonical call-argument slot that the
  exit's single `core.bytes.drop` finalizer already owns. Independent replay
  re-derives the same ordering. The reference interpreter, native C11 through
  the new `spx_bytes_set_check_v1`, and internal Core-Wasm through a generated
  comparison against the carrier's byte length all select the identical
  `semaprax.byte-buffer.v1` code 1 adapter status; the Web wrapper reserves
  internal value 16 for it. The deferred-owner-commit decision the bounded Vec
  lane introduced for `vec_push` now lives in one `cleanup_plan::deferred_commit`
  module that both operations share. The Core-Wasm host import keeps its own gate, now
  unreachable from admitted source. Local focused evidence covers a computed
  in-range fill and a computed out-of-range store on all three engines,
  including a one-entry Core-Wasm arena that still balances across four failing
  invocations. Elements wider than one byte, a loop-driven fill, a computed
  capacity, and a public FFI layout stay open and unclaimed.

- Restored the cross-platform CI gates after the owned algebra expansion by
  refreshing the checked Core-Wasm, component, artifact-DAG, browser project
  graph, and macOS provider symbol KATs; aligning Project admission regressions
  with the newly supported generic and byte-bearing shapes; and keeping the
  POSIX native network fixtures Unix-only. The TCP deadline regression now
  constrains the client send buffer so it cannot spuriously complete before the
  peer-side timeout is exercised, and newly enabled strict Clippy lints are
  clean.

- Executed the VS Code Extension Host execution evidence v2 gate for the first
  time, on exact subject `3fccd30b861d48c9d404eb2698fa2eff510569af` in a locally
  provisioned Visual Studio Code 1.136.1 on Darwin arm64 with Node v24.3.0. The
  97 standalone controller cases and the single Extension Host scenario passed,
  producing bundle
  `29660fc88dac4d3bd11098f7facfe1bd05fda23b378d519d9590f028a3fdc7dd`, whose
  envelope and four artifacts are archived under `docs/evidence/`. The run found
  two defects the mock-backed suites could not: `runCandidateTests` and
  `suggestHoleFill` awaited non-modal notifications that resolve only when a
  human dismisses the toast, hanging the command and holding the busy latch;
  and the host assertion for a cleared diagnostic expected `undefined` from
  `DiagnosticCollection.get`, which the real host never returns for an absent
  URI. Those commands now fire the notices without awaiting, and absence is
  observed through `has`. This is one local product on one platform; VSIX or
  Marketplace packaging, manual UI, accessibility, minimum-version, remote,
  hosted and cross-platform evidence remain open, and the run covers its exact
  subject rather than any later head.

- Added internal Owned Bounded Vec v1 across source, HIR, Graph, cleanup-plan
  replay, the interpreter, native C11, and Core Wasm. `Vec<T>` and eight explicit
  generic intrinsics admit exactly the eight Copy scalars, any `usize` capacity
  expression with a hard runtime maximum of 8192 and sticky code 3 on dynamic
  overflow/allocation failure, consuming push, deterministic exact reserve,
  indexed set, capacity-retaining clear, borrowed length/capacity/get, exact
  same-owner reopening, and deterministic settlement on all three engines.
  Reserve uses `max(old_capacity, len + additional)`, set reuses bounds status
  code 2, and all three new mutators consume and return the one owner. Additive
  compiler prelude v3 is selected only when one of those operations is used;
  frozen prelude v1/v2 contract bytes remain unchanged, and collision-free
  legacy Vec programs keep selecting their prior bindings. The three new
  intrinsic names and core identities are now reserved language vocabulary. The
  alloc-tier `std.collections` package now authors the exact eight
  authenticated aliases, an explicit eight-scalar conformance module, bundled
  dependency metadata, generated catalogs, focused local Project/package
  evidence, and no public exports. Owned/aggregate elements, inference,
  iterators, public generic ABI, hosted support, and broader collections remain
  closed.

- Admitted the exact internal Owned Bounded Byte Buffer v1 write-once profile
  on Core-Wasm. The frozen host-arena imports allocate a literal-bounded zeroed
  `Bytes` value and mutate the same opaque token at literal indices; focused
  local Node evidence covers deterministic valid modules, three writes and
  reads, repeated success and contract-failure settlement/re-entry at one live
  arena entry, and absence of `memory.copy` and `memory.grow`. Source/HIR and
  cleanup hostiles preserve exact capacity, callee, transfer and call-commit
  authority. The public byte adapter remains rejected with `SPX-W115`; this
  adds no loops, growth, wider elements, Project/public ABI, `std.*`, browser,
  hosted, or cross-platform support.

- Added one exact cross-file Project product gate for an internal concrete
  generic owned record. The retained Project keeps `Pair<Bytes, bool>` inside
  its linked closure while its frozen v8 descriptor remains scalar-only; the
  gate repeatedly executes Project entry and test functions, generated native
  C11 at `-O0`/`-O2`, and an external Node consumer calling the generated
  npm/Core-Wasm scalar API for empty and nonempty inputs. This does not expose
  a generic record, widen v8/v9/v11, or add a public generic ABI or Project v14.

- Added `agent_lifecycle::durable`, the Agent Checkpoint v1 revision-bound
  durable slice over Agent Lifecycle v1. `bind_durable_agent` anchors one
  checked module, one AgentDeployment v1 bound product and one caller-supplied
  policy epoch, and every checkpoint generation binds nine recomputed facts -
  the policy epoch, the semantic definition, deployment and bound-product
  digests, the State role identity, the proposal-grammar digest, the lifecycle
  digest, the exact module source digest and the caller's task digest - so
  definition, deployment, source or state-schema drift and a revoked epoch each
  reject a stale checkpoint by its own reason, re-running no stage and writing
  no generation. A durable run splits the lifecycle at its single external
  boundary: it commits an intent before crossing it and a settled observation
  after it, so a crash between the two leaves delivery uncertain. An uncertain
  operation is never retried automatically - it ends in a terminal `unknown`
  state, or the host reconciles it with a settled observation or an
  abandonment - and a read that reports failure is treated as uncertain too,
  because a reported failure is not evidence of non-occurrence. Neither budget
  ledger is refunded: the effect grant is consumed at the intent whatever the
  operation's fate, and re-executing the deterministic prefix on a resume spends
  interpreter fuel from the same remaining total.
- A resumed run cannot forge an authorization. A checkpoint carries no
  `Authorized`, no grant seal and no state carrier, only digests, and there is
  no decoder from checkpoint bytes back to a retained value; a resume recomputes
  the state from the caller's task and mints a fresh grant through the crate's
  single mint site before comparing the derived operation identity against the
  journal. Checkpoint bytes are self-verifying - closed key set, strictly
  advancing journal ranks, recomputed chain link, program counter agreeing with
  the journal, and exact canonical re-rendering - so a partially written
  generation fails closed with `SPX-G573` rather than being adopted, and
  atomicity itself stays the caller's `CheckpointStore` contract. Caller inputs
  are retained as digests only; the settled observation is the sole retained
  external datum, and `Retention::ObservationDigestOnly` redacts that too. The
  checkpoint is deliberately unauthenticated and republishes that dependence in
  its own nonclaims, alongside the standing provider-billing and
  external-exactly-once nonclaims. The `agent_runtime_v1` harness gains
  `agent_checkpoint_v1` covering crash injection at all five boundaries with
  their recoveries and total boundary-crossing counts, the drift and
  caller-input rejections, seven malformed-document rejections, the redaction
  sentinels, and an atomic write-and-rename store against a contract-violating
  torn one; the crate-internal gate additionally proves that an internally
  consistent rechained journal forgery still mints nothing. No CLI surface was
  added: `semaprax agent` still refuses `resume` and `reconcile`.

- Added `agent_lifecycle`, the Agent Lifecycle v1 compiler and runner: it binds
  an AgentDefinition's four deterministic operation identities - `initialize`,
  `observe`, `authorize`, `reduce` - to actual verified `.spx` functions in the
  same HIR ordinary execution uses, and executes one acyclic lifecycle over
  them through `interpreter::retained_call`. Binding validates each stage's
  parameter count, parameter ownership modes against the AgentGraph v1
  relationships, declared effects, role types, the derived two-case
  grant/refusal decision variant, and the acyclic and uniquely ordered stage
  graph, and it rejects an unresolved identity, an incompatible signature, an
  incorrect ownership mode, a declared effect on a deterministic stage, an
  unadmitted proposal field representation, and an unadmitted decision shape
  with an `SPX-G570` diagnostic naming the exact failing field - all before any
  host work is reachable. The authorizing transition mints `Authorized`, an
  opaque one-use value bound to the exact lifecycle policy digest, the
  identity-keyed encoding of the state carrier, the exact proposal document
  bytes, the grant case identity, and the seal the program itself constructed.
  Its fields are private to one module, it derives nothing and has no public
  constructor, it is consumed by move at the effect boundary, and the crate's
  single mint site is reachable only from the function that runs the validated
  authorize stage - which requires an `AuthorizeStage` only the stage binder
  builds, requires the retained product to name that exact validated function,
  and mints only on the validated grant case. A proposal, an observation and a
  reduction therefore have no route to one. Spending an authorization
  independently recomputes its binding from the state and proposal presented,
  so a substituted state or proposal is `SPX-G571` before the injected read
  operation is called. `propose` is a scripted offline document admitted only
  through Proposal Schema v1, and `execute` is one explicitly injected
  `AgentReadOperation` and nothing else. The six terminal conditions -
  `completed`, `rejected`, `model_failed`, `effect_failed`, `cancelled`,
  `budget_exhausted` - each produce a canonical
  `semaprax.agent-lifecycle-evidence.v1` document carrying identities, outcomes
  and cleanup-event counts but no payload bytes, byte-identical on replay.
  Stage values stay inside the retained seam's closed vocabulary, so `string`
  cannot cross a stage boundary and the Proposal role crosses as its exact
  ordered scalar projection instead. The frozen AgentDefinition, AgentGraph and
  Runtime v1 profile digests are re-asserted unchanged; `AgentDefinition` gains
  two additive read-only accessors and no other change. Iterative `AgentStep`
  execution, typed language effects beyond the injected read, durable
  checkpoint/resume, and a CLI surface remain Missing.

- Re-derived the `SPX-G171` identity term. The builder pre-bound charged
  every declaration identity slot the longest identity in scope times 64, a
  factor whose enumeration of retained resolver structures overlapped the
  occurrences the slot count already enumerates, so each slot was billed for
  the whole resolver twice. Measured with a counting global allocator around
  the core build, lengthening every identity in a package by one byte raises
  the heap that build retains by 0.87 to 1.11 bytes per identity slot
  (`std.test` 460 over 416 slots, `std.core` 1,378 over 1,385, `std.bytes`
  2,080 over 2,378, `std.data.json.token` 2,409 over 2,755), so the factor is
  now 16: eight retained structures, each able to hold the identity as a map
  key and as a value. The structural factor stays 24 against a measured 3.8,
  because the sixteen it is built from is a compile-time bundle assertion
  rather than an estimate, and the string factor stays 64 because that term is
  1.2% to 2.5% of the estimate. Padding the six `std.data.json.*` packages
  until `SPX-G171` fires now admits 19.7 KB to 22.1 KB of total package source
  where the same measurement gave 12.3 KB to 14.2 KB, so `std.data.json.doc`
  has headroom again. Nothing about the retained-memory bound is relaxed: the
  pre-bound and the structures the core build actually retains are reserved
  against the same 16 MiB budget and either overflow is still `SPX-G171`.
  Whole-document KATs that embed `used_builder_bytes` were re-pinned;
  rendering the same workspace document under both factors and diffing it
  field by field shows `used_builder_bytes` and the digest over it as the only
  changes. Standard Library v1 also records two limits that were written down
  nowhere: `match` is not admitted in a `while` body (`SPX-T252`) outside a
  two-arm `Option` match on `byte_get`, and replay path counts multiply across
  sequential statements while only summing across `match` arms, so packing
  small tables into one function can trip `SPX-H006` where splitting them
  does not.

- Added `interpreter::retained_call`, the retained multi-argument call seam
  Reference Interpreter v1 was missing: `prepare_resolved_zero_arg_i64` is
  zero-argument and additionally requires `entry_id == program.entrypoint`, so
  it can run only `main`; `interpret` re-reads and re-verifies source on every
  call; `ArgumentValue` is scalar-only; and `evaluate_resolved_owned_data` is
  restricted to a borrowed `Slice<u8>` entry with bytes-shaped results.
  `prepare_retained_call` admits ONE explicitly identified function - the
  entrypoint or any other - through the interpreter's own admitted-function map
  and closure scan, restricts its signature to a closed value vocabulary, and
  retains the authority-free dispatch index; `evaluate_retained_call` then
  invokes that product repeatedly, reading no source, re-resolving nothing, and
  re-running neither `hir::validate` nor the closure scan, re-checking only
  that the retained vector positions still name the same identities and that
  the admitted signature is unchanged. Arguments and results are the
  monomorphic scalar record/variant subset of Agent Proposal Schema v1 the
  interpreter actually executes: `bool`, `i32`, `i64`, `u8`, `usize`, owned
  `Bytes`, and bounded acyclic records, classes, and owned-byte variants over
  exactly those leaves; `string`, `char`, `f32`, `f64`, borrowed carriers, and
  generic shapes fail closed with a located `SPX-F102` diagnostic in the
  existing closed reason vocabulary rather than widening the cleanup shape the
  shared machinery and the native and Wasm backends own. Execution enters
  through the same evaluator call frame, a staged owned `Bytes` argument is
  charged against the same verified byte-data capacity a `bytes_copy` consumes,
  a Copy carrier is harvested by reference while an owned one must be uniquely
  held, and result leaves settle in declared field order without being sorted
  or repaired. The frozen zero-argument entrypoint product keeps its exact
  admission and known answers; both products now share one owner for the
  retained dispatch index. `string` fields, admitted by the proposal schema but
  by no interpreter record or variant classifier, remain Missing here.

- Added `std.data.json.doc`, the structural document layer of the bounded JSON
  slice: the object and array grammar driven by six modes over a base-2
  container stack held in one `i64`, an explicit `depth_limit` clamped to 32
  open containers and rejected at the offset of the container that exceeds it,
  a closer that does not match the innermost container rejected at its own
  offset, and trailing-byte rejection that reports the first trailing
  non-whitespace byte. `document_end` scans one value, `whole_end` requires
  only whitespace after it, and `is_document` is the whole-input form; the
  RFC 8259 number grammar, the exact `true`/`false`/`null` words, and string
  framing that rejects raw `0x00`-`0x1F` and an unterminated string are scanned
  in the same pass, allocation-free, returning only scalars in the family's
  end-offset/rejection encoding. Escape-character and surrogate validity stay
  with `std.data.json`, raw UTF-8 with `std.data.json.utf8`, and duplicate keys
  are accepted rather than rejected - all three stated in
  [Bounded JSON Scanner v1](docs/BOUNDED-JSON-SCANNER-V1.md) rather than left to
  inference, because the `SPX-G171` pre-bound admits 12,216 B of this package's
  source and rejects 12,292 B. The package deliberately depends on nothing: a
  `[dependencies]` edge on `std.data.json` alone puts it over that bound, since
  vendored dependency source is charged in full against the consumer.

- Extended the bounded JSON slice from one package to five sibling packages,
  because the Workspace Semantic Graph pre-bound is charged against a whole
  package - library, examples, and conformance modules - and no single library
  module can hold the slice. `std.data.json.token` adds the RFC 8259 number
  grammar as composable integer, fraction, and exponent scanners, `true`,
  `false`, and `null` recognition, and exact `i64` decoding that refuses
  overflow and refuses a fraction or exponent rather than rounding it, so
  `-9223372036854775808` decodes exactly and no value passes through an `f64`.
  `std.data.json.utf8` adds raw-byte UTF-8 validation that rejects invalid lead
  bytes, missing or malformed continuations, overlong encodings, raw
  surrogates, and scalars above `U+10FFFF`. `std.data.json.write` and
  `std.data.json.digits` add a pull-based, buffer-free writer: the exact length
  and each byte of a quoted JSON string, and the exact decimal bytes of any
  `i64` plus the literal words. All four carry the existing scanner's `usize`
  end-offset/rejection encoding and pass interpreter, native C11 at O0 and O2,
  and Core Wasm conformance. Two new gate cases link the siblings from one
  consumer. Structural document validation - nesting limit, trailing-byte
  rejection, and duplicate-key policy - decoded strings, an owned document
  tree, and an output buffer remain Missing.

- Extended concrete generic owned-`Bytes` records across the complete direct
  Copy-scalar set: `i64`, `i32`, `u8`, `usize`, `char`, `f32`, `f64`, and
  `bool`. Source verification, resolved HIR, cleanup inventory/replay,
  Native64/Wasm32 layout and native/Core-Wasm lowering retain the exact
  owner-and-index substitution. Concrete generic immutable updates now retain
  unchanged fields, replace owned fields left to right, and settle both partial
  construction and partial update failures without replacing the selected
  status. Focused local interpreter, Clang O0/O2 and Node/Core-Wasm evidence
  covers borrow-then-own execution, update execution, both partial failures,
  repeated entry, one-live-owner capacity, and hostile plan mutation. Explicitly
  instantiated generic functions can now consume and return the admitted flat
  owned-record template, with exact instance dispatch and failure settlement in
  the interpreter, native C11, and Core-Wasm. Real cross-file Project linking,
  semantic-recipe replay, candidate rename/recovery, and ABI-delta replay retain
  the internal generic identity while frozen public descriptors stay closed.
  Bounded acyclic concrete nesting now composes those records as
  `Box<Pair<Bytes, bool>>`, `Pair<Box<Bytes>, i64>`, and a two-owned-leaf
  instance. One global worklist authenticates depth, owned-leaf, and field-work
  limits; recursive cleanup retains complete stable field paths; Native64 and
  Wasm32 layouts independently replay complete concrete identities; and local
  interpreter, native C11, and Core-Wasm evidence covers whole moves, exact
  owner capacity, partial-prefix settlement, and repeated recovery. Generic
  variants, classes, resources, general nested storage, public generic ABIs,
  and hosted execution remain unchanged or unclaimed; the required Linux steps
  are authored but have not yet produced hosted evidence.

- Added a bounded authored generic owned-variant path for exact
  `Either<Bytes, i64>` and `Either<i64, Bytes>`-equivalent instances. Source,
  HIR, conditional cleanup, layout, interpreter, native C11, and Core-Wasm
  retain owner/index substitution and one authenticated owned case. Local
  evidence covers opposite live-case vectors, inactive cases, borrow then own,
  partial construction, owned-arm failure, exact semantic status, repeated
  recovery, zero native leaks, and rejection of shallow native/Wasm copies. A
  partial-construction fix now stores each completed Wasm field before
  evaluating the next initializer and still publishes the tag last. Hostile
  index/type layout drift is rejected. The compiler-owned two-sided `Result`
  is handled by a separate exact profile; nested/resource variants, public
  ABIs, and hosted promotion remain closed or unclaimed.

- Proved an exact authored two-owned-branch generic variant shape with two
  parameters, `[Bytes, Bytes]` arguments, and two owned cases. Existing
  conditional cleanup represents both case-qualified owners without a schema
  change. Local interpreter, C11 `-O0`/`-O2`, and Core-Wasm evidence covers
  both constructors, borrow/own matching, dynamic parameter/result/call
  transfer, branch-specific partial construction and arm failure, precondition
  settlement, repeated recovery, tight capacity, zero native leaks, invalid
  carriers/tags, and native/Wasm shallow-copy rejection. Hostile replay changes
  inactive liveness, case authentication, and guarded finalizers in both
  directions. Compiler-owned `Result<Bytes, Bytes>` is admitted separately
  below; broader multi-case generic sums, Project/public ABIs, and hosted
  promotion remain closed or unclaimed.

- Admitted the exact compiler-owned `Result<Bytes, Bytes>` instance for
  ordinary internal construction, explicit own/borrow matching, parameters,
  results, and calls. Its authenticated prelude identities reuse the proven
  conditional two-branch cleanup machinery. Focused local interpreter, native
  C11 `-O0`/`-O2`, and Core-Wasm evidence covers both active branches,
  dynamic forwarding, staged-call and arm-failure settlement, capacity-one
  execution, hostile cleanup-plan mutation, invalid tags, tag-last result
  publication, and native/Wasm shallow-copy rejection. The same exact internal
  instance now supports `Result<Bytes, Bytes> -> Result<Bytes, Bytes>` postfix
  `?`: the operand evaluates once, Ok moves its selected payload, Err transfers
  the complete residual, and ownership-only replay joins preserve shared
  postconditions, sticky failure, and both guarded finalizers. Focused local
  interpreter, native C11 `-O0`/`-O2`, and Core-Wasm evidence covers both
  branches and re-entry. Mixed/general/nested and generic-function owned
  propagation, Project/public ABIs, and hosted promotion remain closed or
  unclaimed.

- Bounded native C11 name resolution by the same aggregate operation deadline
  as the rest of the operation. A numeric endpoint is answered under
  `AI_NUMERICHOST` with no name service, no budget and no worker; a name is
  resolved on a POSIX-thread worker the emitted translation unit owns, waits
  only for what is left of the deadline, and leaves an abandoned worker
  registered, joined and freed by the next reap or by settlement rather than
  detached — the same model as the Rust `SystemResolver`, and the same
  non-claim: this bounds waiting, not `getaddrinfo`, which POSIX cannot cancel.
  A host may now select a shorter native deadline by defining
  `SPX_NETWORK_OPERATION_DEADLINE_MILLIS_V1`, clamped to the fixed maximum.
  Four executed native gates drive an injected 300 ms name service, a spent
  budget, an always-`EINTR` read and an interrupted-then-successful read
  through the emitted text in milliseconds, over loopback and an `AF_UNIX`
  socket pair with no outbound traffic; an always-interrupted whole program
  still selects `semaprax.network.v1` code 5 under a 250 ms deadline. The
  `_WIN32` branch is now cross-compiled where a Windows toolchain exists and
  keeps the inline resolver; Windows execution is explicitly scoped out rather
  than claimed.

- Added deterministic grammar-driven differential compiler tests with shrinking
  as a module of the existing `scalar_status_backend_equivalence` harness. A
  seed names one module in the admitted scalar subset — nested operands,
  parameterized helper calls, branches, bounded loops, mutation, contracts,
  checked failure and lazy evaluation — and every lane answers in one closed
  vocabulary: canonical parse-format-parse stability, graph identity,
  verifier/HIR agreement, the reference interpreter, native C11 at O0 and O2,
  and Core-Wasm on Node. Sixteen fixed seeds run in PR CI; a larger bounded
  campaign runs separately. A disagreement is classified, minimized by a
  structure-preserving shrinker, and rendered with the seed, source, compiler
  commit, toolchain identities, exact commands, expected and observed outcomes
  and the minimized module. Unsupported profiles and absent provisioned tools
  are explicit `Unavailable` outcomes, never parity passes, and failure
  injection proves the checker notices a wrong backend value, an incorrect
  failure selection and an abort. Generated modules declare no effects and no
  `unsafe`, so no fuzzer-generated file executes with ambient network,
  filesystem, process or signing authority. Owned cleanup and task schedules
  remain out of this first tranche.

- Added the bounded AGENT-04 interaction-contract slice. Source-owned Agents
  now derive exact Proposal and Observation grammars from checked same-module
  record or variant declarations, including closed bounded decoders and a
  deterministic provider-neutral JSON Schema/TypeScript/Python/Rust Proposal
  client bundle. Project revisions retain independently replayed contract facts
  and expose them through the existing AgentDefinitions node, ProgramRoot,
  typed query, and semantic service without changing closed transport schemas
  or legacy agent-free and explicit-association bytes. Generated client source
  is structurally verified but is not claimed as compiled, packaged, or run;
  cross-module role resolution remains follow-up work.

- Fixed `semaprax run` refusing bounded Copy record construction that `check`
  verifies and that the native C11 and Core-Wasm backends execute (#75). The
  single-file interpreter route was the only route asking
  `record_construction_is_admitted` for the narrower owned-byte answer, so
  reading `p.x` was admitted while building the `p` it reads from was not. The
  admission predicate is now the single bounded acyclic classifier every route
  already shared, and the parameter that split them is gone. Field Mutation v1
  stores now replace one direct scalar field instead of the whole binding —
  the previous store left a later projected read failing closed on `SPX-F105`
  — and a shared Copy carrier is copied before the store, so a sibling binding
  keeps the value the other two backends give it. Record shapes still outside
  the profile keep their exact closed reason at admission: a record-typed
  callee signature is `unsupported_callee`, and `with` over a Copy record is
  `record_update`.

- Added the bounded AGENT-03 language-native source Agent slice. A closed
  `.spx` declaration with explicit identities and fixed deterministic/model/
  effect roles now parses, round-trips canonically, lowers through the unchanged
  AgentDefinition v1 compiler, and retains byte-identical AgentDefinition,
  AgentGraph, and Runtime Profile products on the admitted Project revision.
  Default canonical workspace derivation populates its existing
  AgentDefinitions segment, with the same node selected through ProgramRoot,
  exact context, a typed in-memory query, and the persistent service. The three
  focused compatibility/hostile/integration cases pass locally; role execution,
  provider authority, opaque authorization, and durability remain absent.

- Fixed the Workspace Semantic Graph `builder_bytes` pre-bound charging every
  imported function's contract and body as resolved structure in the importing
  module. The synthetic projection retains an import as a stub — rewritten
  signature, no contract, default body — so a conformance module that imports
  everything its library exports was costing a second complete copy of that
  library, expanded by the structural factor. Imports are now charged as the
  stub they become, plus the largest single transient provider clone at the raw
  AST rate. `SPX-G171` still refuses before mutation and the estimate remains an
  upper bound of resolver memory. Documented the practical authoring limits,
  including the `SPX-H006` cleanup-replay path budget, in
  [Standard Library v1](docs/STANDARD-LIBRARY-V1.md).
- Added ProgramRoot v2 and Exact Program Context v1. The versioned root retains
  the enriched canonical workspace's nine v1 segments, appends exact interface/
  artifact and Project Lock association descriptors, and explicitly binds the
  distinct default Project root. Additive service, query, transaction, and
  structural-diff entry points select the same dual-keyed v2 root in memory
  without changing legacy wire bytes. Exact candidate-root derivation and
  refresh remain fail-closed pending candidate-safe lock replay.

- Added locally exercised SEG-02 input bundles for exact source-interface and
  pathless generated-artifact facts plus exact Project Lock v1 association.
  Both freshly replay their existing owning compiler artifacts, retain bounded
  content identities without authority, and preserve ProgramRoot v1 and every
  legacy Project/Image/Graph/lock byte. Versioned exact-root integration remains
  explicit follow-up work.
- Added the provisioned Linux offline doctor lifecycle gate: one dispatch-only
  workflow, `scripts/doctor-provisioned-linux-gate.py`, and
  [Provisioned Linux gate v1](docs/DOCTOR-PROVISIONED-LINUX-GATE-V1.md). The
  gate asserts host, kernel, delegated cgroup-v2, held-image, release and
  trust-anchor preconditions before any test runs, selects the twenty-six
  existing ignored lifecycle fixtures exactly and serially, binds commit,
  platform, tools, fixture identity, bounded capture and final cgroup
  emptiness into one evidence document, and keeps failure selection sticky
  over cleanup. Absent provisioning is a failure, never a skip: unmet or
  unobservable preconditions, still-ignored tests, an unmatched filter and a
  narrowed selection are each rejected, and `--self-test` drives that logic
  with synthetic inputs on any host. **The gate itself has never been
  executed**; no provisioned Linux x86-64 host exists, no completion row
  moves, and the private provisioner stays out of every ordinary CLI route.

- Added the SEG-02 explicit AgentDefinition association bridge. A bounded,
  stable-ID-ordered set of exact compiler-admitted definition/graph/profile
  bundles can populate the existing Canonical Workspace AgentDefinitions node
  for one exact Project revision and flows into ProgramRoot automatically.
  Default empty derivation remains byte-compatible; the new route explicitly
  does not claim `.spx` Agent syntax, intrinsic Project ownership, execution,
  or authority. Its three focused Workspace-harness cases pass locally.

- Added the SEG-02 ProgramRoot v1 foundation as a small segmented,
  content-addressed projection of Canonical Semantic Workspace Revision v1.
  Nine independently digested descriptors bind the existing typed node bytes,
  while DeploymentRoot, InstanceRoot, and EvidenceRoot remain typed unbound
  placeholders. Existing canonical workspace, Project, Image, and Graph bytes
  and identities are unchanged. The 33-case combined focused gate and strict
  all-target clippy pass locally.

- Added the Project-v13 native C11 HTTPS lane. Generated commands link through
  a narrow libcurl route, embed a pinned 146-certificate Mozilla trust bundle,
  require hostname/certificate validation with TLS 1.2 or 1.3, negotiate
  HTTP/2 with HTTP/1.1 fallback, bound redirects/connections/headers/body and
  time, suppress ambient proxies, canonicalize the complete response, and
  settle before publication. A real encrypted loopback gate and an opt-in
  public-PKI smoke exercise the generated executable.

- Added a locked Project-v13 HTTPS browser fixture and provisioned Chromium CI
  gate. It executes the real generated npm/Wasm package, verifies exact
  fixture-v3 output, one-shot invocation and tampered-Wasm rejection, and
  proves every browser request stays on the loopback harness origin.

- Added a descriptor-derived safe C++17 adapter for Project-v9 flat owned
  records. Its thread-bound noncopyable client preflights borrowed inputs,
  authenticates private carrier values, copies and settles the sole byte
  handle, closes the provider context, and only then returns a value-only C++
  record. A real separately compiled C11 provider and C++17 consumer execute at
  O0/O2. The C header now preserves its C11 static-array minimum while using
  C++-legal syntax when included from C++.

- Added `std.data.json`, the first JSON facility a SEMAPRAX program can call.
  [Bounded JSON Scanner v1](docs/BOUNDED-JSON-SCANNER-V1.md) specifies a pure,
  allocation-free JSON string-token scanner over `borrow Slice<u8>`:
  whitespace skipping, escape classification, `\uXXXX` code-unit decoding,
  strict surrogate-pair rules that reject a lone or unpaired surrogate, RFC
  8259 control-byte rejection, and the byte offset of the first rejection
  carried in the same `usize` result. Number and literal tokens, structural
  document validation, UTF-8 validation, decoded strings, an owned document
  tree, and a writer stay Missing: the `SPX-G171` workspace-graph pre-bound
  admits roughly 4.7 KiB of library source for a package of this density, and
  rejects a consumer that links two such packages, so the remaining scope
  needs that bound raised rather than more library code.

- Added invocation-owned HTTPS work to the bounded structured-task runtime.
  Providers now settle exactly once across success, HTTP failure,
  cancellation, panic, deadline expiry, and registration rejection; results
  publish only after settlement, while started blocking I/O drains and late
  responses are discarded.

- Added authored Universal Semantic Query v1 checked-fact projections for one
  expression's ownership/loan facts and for direct retained-HIR declaration
  consumers. Both are exact revision-bound canonical requests with replay,
  paging/walk/output bounds, and explicit static-analysis and export-visibility
  nonclaims; the focused evidence passes locally.

- Extended Universal Semantic Transaction v1 with typed `AddDeclaration`.
  It authenticates the exact anchor-module path, source digest, and ordered
  declaration identities, rejects Project-wide identity reuse, delegates the
  closed function/record/variant constructor to Project Candidate, and proves
  one source insertion with unrelated bytes preserved. The read-only
  `change preview add-declaration` adapter and focused regression evidence pass
  locally.

- Added the Project-v13 HTTPS Core-Wasm and npm lanes. The new replayable
  `semaprax.project-npm-build.v12` package authenticates one
  `spx_https_get_v1` import, a distinct HTTP status marker, owned response
  carriers, fixture-v3 authority, and success-only output; the generated
  package executes the committed HTTPS project under Node without sockets.

- Added frozen Project Manifest v13 with the exact `https-command-io.v1`
  profile and `network.http` authority. Its authenticated `network-run` route
  replays fixture v3, while Project v12 and all prior manifest bytes remain
  unchanged.

- Repaired the VS Code Extension Host inventory and widened its scenario. The
  host test asserted exactly 28 contributed commands while the manifest
  contributes 37, so a provisioned run failed before its workflow. The
  assertion is now the exact 37-command inventory in manifest order, every
  contributed command must be registered, no registered `semaprax.` command may
  be undeclared, and the forbidden authority-bearing list is checked against
  both contribution and registration. The scenario additionally covers
  check-on-save positions past a supplementary character, retention of previous
  diagnostics across an unclassifiable run, project-routed navigation across all
  three calculator sources, and the dirty-buffer and project-rename refusals.
  The provisioned runner's node-controller inventory, recorded inputs, and
  command count were updated to match. The Extension Host gate itself was not
  run for this change: no Visual Studio Code product is installed here.

- Routed VS Code declaration navigation, callers, code lenses, and ownership
  through the project that owns the saved file, resolved exactly as
  check-on-save resolves its subject. A module with `use` imports has no
  standalone meaning (`SPX-G172`), so those commands previously failed on every
  importing file, including the shipped calculator project. The
  `semaprax.project-query.v1` result is parsed with its per-match `path` and
  `source_revision`, matches outside the project root are dropped, and a
  selection opens the authenticated file the match was found in. Safe rename
  reports that a project-owned file belongs to the saved-source session's
  replay-checked typed intent rather than to a standalone patch, and the
  module-only `doc` and `graph` routes name their boundary.

- Made VS Code MCP frame assembly linear in received bytes. The receive path
  concatenated the whole retained response with every incoming chunk and
  rescanned it from byte zero, so a legal response fragmented into 1 KiB pieces
  copied about 2.1 GB for 2 MiB received. Retained fragments are now counted for
  the cap check and copied once into the frame they complete. The byte cap,
  strict UTF-8, CR rejection, response-identity validation, serial request
  semantics and terminal failure are unchanged.

- Fixed VS Code editor ranges mixing three coordinate systems. The compiler's
  UTF-8 byte spans are now translated against the exact saved source into
  zero-based UTF-16 positions that may cross lines, through one mapper
  (`editors/vscode/positions.js`) shared by diagnostics, declaration
  navigation, and code lenses. Torn, reversed, and out-of-range offsets fall
  back to the reported line and column instead of underlining the wrong text,
  and a document changed while the compiler ran receives no positions at all.

- Fixed the VS Code check-on-save adapter reporting a clean project from
  output it could not read. `check --json` output is now classified into
  diagnostics, the verified record, and malformed lines, and the exit status is
  validated against them; a killed child, a foreign status, an unparsed line, an
  error with status 0, or a verified record with status 1 is a check failure
  that retains the previously published diagnostics instead of clearing them.
- Made the `Release gate` CI aggregate fail closed. It ran under
  `if: ${{ success() }}`, which skips the job whenever a blocker did not
  succeed, and GitHub scores a skipped check run as a satisfied required status
  check. It now always runs and asserts every `needs` result through
  `scripts/ci-required-checks.py`, rejecting failed, skipped, cancelled,
  malformed, vacuously empty, and foreign-commit inputs; a local test drives
  those cases and a second derives the blocker inventory from the workflow so a
  new job cannot escape the aggregate. Added
  [Required CI checks v1](docs/CI-REQUIRED-CHECKS-V1.md) recording the observed
  unprotected `main`, the branch-scope, bypass and recovery policy, and the
  exact ruleset request. The ruleset is a proposal: no repository setting,
  ruleset, membership, credential or branch permission was changed, and no
  required check is in force.
- Added Persistent Semantic Workspace Service MCP v1 through
  `semaprax service <project> --mcp`. Its closed seven-tool MCP catalogue exposes
  protocol/status, universal, retained-index, and bounded history queries,
  transaction validation, and caller-owned refresh through one process-retained
  service generation.
  Startup is the only host-path boundary; MCP tools add no authority and frozen
  Project Agent Transport v5 bytes and MCP catalogue remain unchanged.
- Added Persistent Semantic Workspace Service Transport v1 and the
  `semaprax service <project>` adapter. One authenticated Project and one
  incremental semantic service remain alive across bounded JSON-RPC-lines
  universal-query, retained-index-query, transaction-validation, and
  caller-owned refresh requests; failed or stale refresh rolls back before the
  in-memory generation/cache/index CAS. Four focused Workspace-harness cases
  pass locally.
  This is a single-client local stdio process, not MCP/LSP, a socket, daemon,
  durable/shared state, source writer, execution service, or authority broker;
  frozen Project Agent Transport v5 remains separate and unchanged.
- Extended Universal Semantic Transaction v1 with typed whole-function
  `ReplaceBlock`. It binds an exact old source block, delegates the replacement
  expression to complete ProjectCandidate validation, proves byte-identical
  source outside the selected span, and exact-replays the ordinary transaction
  artifacts without commit authority. The focused transaction/composition
  selection passes 10 cases locally; nested expression replacement,
  multi-operation transactions, and ReplaceBlock composition remain open.
- Added refresh-atomic retained semantic-service indexes for tests covering a
  stable declaration and functions that can reach a named effect. Canonical,
  revision-bound query/results are bounded, deterministic, replayable, and
  available through both the service core and `workspace/index-query`.
  Persistent-core focused evidence passes five cases locally.
- Extended `semaprax review` with the closed Project form
  `review <project> <transaction.json> [--evidence]`. Default output is the
  exact concise semantic review; evidence is displayed only when requested.
  The existing source-patch form remains unchanged, no files are written, and
  the focused three-case CLI gate passes locally.

- Fixed the macOS held-Git process boundary to preseed CoreFoundation's
  user-text-encoding key with the process UID and fixed encoding fields. This
  prevents CoreFoundation from reading the user-home encoding file or rewriting
  the child environment, while the exact environment assertion remains closed.

- Added Signed Minimum Literals v1: `-9223372036854775808` and
  `-2147483648i32` are ordinary literals in expressions and match patterns, so
  boundary constants no longer need a `-MAX - 1` workaround. The magnitude
  survives tokenization as its own token and is claimed only by a directly
  applied unary `-`, so tokenization stays context-free and subtraction is
  unchanged; the bare magnitude, a parenthesized one, and `MIN - 1` all keep
  the stable located `SPX-P003` rejection. `-MIN` and `MIN / -1` still select
  checked arithmetic failures, and the native C11 backend now spells both
  signed minimums as a negated maximum less one so no C literal names an
  unrepresentable magnitude.
- Fixed `run <file> --json` publishing human diagnostics on stderr when its
  preliminary load or verification failed. Parse errors, unreadable inputs, and
  type/effect/ownership failures now emit the same diagnostic records on stdout
  that `check --json` does, including for the bounded stdout profile. Human
  mode and every execution envelope are unchanged.

- Added `semaprax.network-fixture.v3` as an ordered, bounded HTTPS
  request/response replay carrier. V1 and v2 reject the new member, URL or
  response mismatches do not consume queue entries, and hosted `https_get`
  conformance now uses the serialized carrier shared with generated lanes.
- Added Installed Fix Plan v1. `semaprax fix --plan` returns the exact bounded,
  version-bound one-operation installed catalog, while `semaprax fix <file>
  assign-function-id <automatic-function-id> --plan` wraps the existing
  source-authenticated `SPX-S103` Diagnostic Repair discovery in a canonical,
  replayable plan. Five focused semantic-harness cases pass locally. Planning
  does not select a persistent ID, instantiate or apply a patch, write source,
  rank repairs, or grant host/publication
  authority; existing `repairs`, `repair`, and Diagnostic Repair bytes remain
  unchanged.

- Admitted a bounded internal concrete generic owned-byte record slice. Exact
  authored instances such as `Pair<Bytes, bool>` now substitute fields through
  source verification, HIR facts, cleanup inventory and replay, interpreter,
  Native64 C11, and Wasm32 lowering. Focused local evidence covers borrow then
  own, repeated success, and failure after owner creation across interpreter,
  C11 `-O0`/`-O2`, and Node/Core-Wasm; stable diagnostics keep nested generic,
  class, variant, and non-Copy record shapes closed. This record slice does not
  authorize prelude carriers; exact `Result<Bytes, Bytes>` support was added
  later under the owned-variant contract. It does not expose a Project, C,
  Rust, WIT, Component, or package ABI.
- Named the exact `Option<Bytes>` and `Result<Bytes, i64>` tags in the public
  Project-v8 C11 header. A separately compiled C consumer now executes all four
  cases at O0/O2, proves inactive cases grant no handle authority, and copies,
  drops, and stale-rejects each active byte handle before context closure.
- Exposed the shared descriptor-derived C11 provider header for Project-v10
  owned UTF-8. A separately compiled consumer links against the actual provider
  at O0/O2 and copies, drops, and closes an exact-length result containing both
  embedded NUL and multibyte UTF-8, without exposing native String layout.
- Added Installed Diagnostics v1: an offline build-time scan embeds the exact
  static `SPX-*` token inventory from compiler and workspace-member Rust
  sources while separately reporting unresolved dynamic diagnostic
  constructor sites. Authority-free library constructors expose bounded,
  canonical, compiler-version-bound catalogue and per-code explanation
  artifacts with exact replay; `semaprax explain` prints the exact concise or
  JSON explanation. Five focused projections-harness cases pass locally.
  Static presence is not runtime reachability, message or repair inference,
  binary attestation, or a stable cross-version
  registry, and legacy diagnostic bytes remain unchanged.
- Added a descriptor-derived C11 header for the Project-v11 nested
  owned-record provider. Its fixed-width leaf carrier preserves full
  descriptor occurrence order without exposing native record layout. A
  separate C consumer links and runs at O0/O2, copies and settles two distinct
  byte owners, rejects both duplicate drops, and closes their shared context.
- Added a descriptor-derived low-level C11 header for the Project-v9 flat
  owned-record provider. It publishes fixed-width carrier field counts,
  ordinals and kinds without exposing native record layout. A separate C
  consumer compiles, links and runs with the actual provider at O0/O2 while
  checking poison preservation, scalar decoding, byte copy/drop, stale-handle
  rejection, and context closure.
- Added source-level `https_get` through an explicit `network.http` capability,
  a closed `semaprax.http.v1` status domain, canonical bytes consumable by
  `std.http`, and a reusable authenticated HTTP/1.1/2 host provider; added
  `net_tls_accept` for source-controlled server-side TLS without changing the
  existing network status domains or prior HIR cache tags.
- Added a pure C11 consumer gate for the authenticated Project-v8 owned-data
  package. The generated provider and a translation unit using only the public
  C header compile separately, link, and execute at O0/O2 while checking
  invalid-bool output poison, owned-byte copy/drop, stale-handle rejection, and
  context closure. This establishes a local linkable C ABI slice without
  promoting Objective-C, cross-platform support, distribution, or compatibility.
- Added the locally exercised Universal Semantic Transaction Composition v1
  core. It derives a bounded canonical workspace structural diff, rebases one
  validated display rename onto an exact independently admitted revision, and
  merges two distinct-target sibling renames in an explicit order through the
  existing Project Candidate conflict and replay machinery. The five focused
  integration cases pass locally. Four focused Workspace-harness cases also
  prove that the read-only CLI forms print the exact core structural-diff,
  rebase, and merge reports; no general multi-operation
  transaction, behavioral equivalence, source commit, transport, or authority
  is claimed, and all Semantic Transaction v1 bytes remain unchanged.
- Added Installed Agent Guidance v1: six deterministic, version-matched,
  authority-free skill documents are available through `skills get`, and
  `query --capabilities` reports the exact installed five-operation Universal
  Semantic Query catalogue with no host grants. Core and CLI return identical
  canonical, bounded, digest-bound artifacts assembled only from embedded
  compiler resources. The focused projections integration gate passes 5/5;
  no binary attestation, live discovery, skill execution,
  host authority, registry, network, MCP/LSP, or legacy-query change is claimed.
- Added exact `semaprax help diagnostic <SPX-code>` lookup and the bounded
  `semaprax help diagnostic codes` inventory. A generated JSON companion keeps
  the CLI response identical in meaning to the compiler-checked quick
  reference's correction table, and the documentation gate now requires every
  marked failing example to have indexed help. The guarded `SPX-T208` answer
  is 111 bytes and 32 lexical units versus 2,513 bytes and 916 units for the
  complete diagnostic index.
- Added the locally exercised Universal Semantic Workflow CLI v1 read-only
  adapter. Five Project-only `query` subcommands print exact
  Universal Semantic Query results, while `change preview rename-display-name`
  prints the exact Universal Semantic Transaction result or evidence. Each
  one-shot invocation retains and finally rechecks one authenticated Project;
  no source write, commit, persistent transport, or MCP/LSP route is added, and
  frozen Project Agent Transport v5 remains unchanged. The five focused
  integration cases pass locally.
- Added the authority-free, transport-neutral Universal Semantic Query v1
  core. Five exact canonical, workspace-revision-bound operations cover bounded
  declaration paging, symbol, context, impact, and truthful transaction
  eligibility; results bind Project, image, canonical component, payload, and
  request identities and support fresh exact replay. The six focused integration
  regressions pass locally. No wire, CLI, MCP, LSP, mutation,
  publication, or frozen Project Agent Transport v5 change is claimed.
- Added exact `semaprax help language <topic>` lookup and the bounded
  `semaprax help language topics` selector list. An installed compiler can now
  return one compiler-checked section of the agent quick reference without
  transferring the whole card; every topic is guarded at more than five times
  smaller in both bytes and repository lexical units. The `scalars` result is
  793 bytes and 296 units versus 26,140 bytes and 7,418 units for the full card.
- Added a hosted Network Services v1 extension with Rustls-authenticated TLS
  clients, explicit listener/accept lifecycle, deterministic fixture v2, five
  effect-gated source operations, and a bounded real structured-task runtime.
- Restored the frozen legacy Project-v3 Wasm byte projection by keeping the
  data-export profile's unused `spx_contract_fail` import at its historical
  void signature. Data exports continue to publish typed arithmetic, contract,
  and byte-range failures through status globals; the ordinary entry wrapper
  retains its status-carrying failure import. The byte-capacity unit module now
  names its test submodule path explicitly so both its library owner and the
  consolidated cleanup harness remain resolvable by `cargo fmt --all`.
- Added an explicit reusable native-host HTTPS client with bounded redirects,
  keep-alive pooling, HTTP/1.1 and HTTP/2 negotiation, stable typed responses,
  body limits, and an opt-in public-PKI smoke; the TCP provider can now accept
  server-side TLS with caller-installed Rustls certificate policy.
- Added the developer-preview `network-command-io.v1` Project v12 profile,
  native and deterministic fixture-only npm/Web build lanes, the bounded
  `semaprax network-run --fixture` command, and a committed HTTP Project
  fixture. Browser and npm packages receive no ambient or real socket
  authority.
- Added Graph v32/v33 for exact composition of owned-variant conditional
  cleanup with unprojected or stable-field-projected Shared Loan Plan facts.
  Semantic Workspace now preserves those source schemas, unknown spellings and
  evidence flows remain closed, and the formerly ignored checked-HIR cache
  regression executes cold/warm Graph v32 accounting and replay.
- Added scoped `semaprax help shapes <kind|stable-id|path#stable-id>` backed by
  a generated JSON companion to the unchanged Markdown catalog. Exact IDs can
  be source-disambiguated, and a kind returns its smallest canonical exemplar
  instead of every declaration. The guarded `calculator.add` result is 114
  bytes and 33 lexical units versus 22,888 bytes and 7,571 units for the full
  catalog, while every kind exemplar stays within 512 bytes and 128 units.
- Added the authority-free, transport-neutral Persistent Incremental Semantic
  Workspace Service v1 core. A process can retain one immutable Project,
  Canonical Semantic Workspace Revision, Semantic Workspace Image, and semantic
  cache generation; serve revision-bound bounded snapshot queries; stage a
  complete source-exact incremental successor; and install it through one
  expected-current in-memory generation/cache compare-and-swap. Transaction
  validation returns Universal Semantic Transaction artifacts without adopting
  their candidate. The three focused lifecycle regressions pass locally; no
  wire, CLI, MCP, LSP, disk persistence, build, execution, commit, publication,
  or broad operation-algebra claim is added.
- Corrected the pathless public C-artifact projection after entry and public
  target closures were separated: native inspection now emits the independently
  admitted entry-plus-export program, so unsupported owned exports remain
  explicit header exclusions instead of failing because they are absent from
  the executable entry-only closure. Native useful-data, language-I/O, and
  line-I/O command products likewise emit that public closure so the
  manifest-selected command and its exact permits remain present. Entry
  execution semantics remain unchanged.
- Admitted explicit nongeneric resource-free record and variant type imports
  containing owned `Bytes` in owned Project profiles. Stable-ID HIR and cleanup
  plans now survive that module boundary, and an owning nominal function can
  move with one exact type import; imported callables exposing owned nominal
  arguments, borrowed storage, resources, generics, cycles, runtime execution,
  and public carrier widening remain closed. Promoted the focused cleanup
  dependency image/transport corpus into the ordinary suite.
- Promoted the focused nominal record/variant rename regressions into the
  ordinary candidate suite after correcting an invalid shadowed pattern
  fixture; the corpus now executes owning and generic nominal renames, stable
  member identities, immutable rejection, recovery, conservative rebase, and
  the existing transport surface; runtime and hosted gates remain unrun.
- Hardened `std.http.status_code` so an HTTP/1.x status code is accepted only
  when the required space before the reason phrase is present; truncated lines
  such as `HTTP/1.1 299` now return `-1` consistently on the interpreter,
  native C11, and Core Wasm lanes.
- Added `semaprax help shapes`, which prints a generated language shapes
  catalog: every declaration of every committed example with its `@id` and
  canonical header, rendered through the `semaprax doc` model and pinned by
  the projections harness, so the bundled reference of admitted shapes is
  derived from the graph rather than hand-written.
- The VS Code adapter adds `Safe Rename by Stable ID` (authors the semantic
  rename patch, shows `impact`, applies through the replay-checked `patch`
  route), `Show Cleanup Plan` (the module graph's canonical cleanup plan for a
  function), and `Run Agent Transcript` (trace, evidence, or receipt of a
  scripted `agent run`), all bounded like check-on-save.
- `semaprax doctor` is now admitted by the standalone compiler: the pure
  offline-profile admission and version-policy module moved from the private
  toolchain into the root crate (`src/doctor.rs`), so both binaries print the
  same report and the guided help pages are identical; only the settled
  provisioner-observation renderer remains in the toolchain, and only
  `build --target rust` still needs the private host.
- Added exact offline `semaprax help library <module|name|stable-id>` lookup,
  returning only the generated dependency row, required profile, signature,
  effects, and contracts while preserving the full catalog bytes. The guarded
  `std.core.compare` lookup stays within 512 bytes and 128 lexical units and is
  more than 50 times smaller than the 22,076-byte, 6,662-unit catalog in both
  measures.
- The VS Code adapter adds `Show Ownership, Contracts, and Effects` (the
  compiler's bounded `context` facets for a chosen callable) and `Inspect Agent
  Definition` (`agent inspect` over the saved AgentDefinition v1 file), both
  bounded like check-on-save and covered by `test/navigation.test.js`.
- Added `semaprax agent run <definition.json> <task.json> <transcript.json>
  [--evidence|--trace]` and `semaprax agent replay ... <evidence.json>`: a
  scripted transcript of provider responses and tool results drives the
  bounded Agent Runtime v1 through the definition's derived profile with no
  transport, clock, or tool authority, so runs are deterministic and a replay
  proves an evidence capsule byte for byte (`SPX-V221` malformed transcript,
  `SPX-V222` replay mismatch). `resume` and `reconcile` stay unadmitted.
- Added the bounded, authority-free Universal Semantic Transaction v1 kernel
  over Canonical Semantic Workspace Revision v1, with one typed
  `RenameDisplayName` operation, exact base/old-name preconditions,
  deterministic intent/impact/review/result/evidence, fresh exact replay, and
  a locally passed focused Project-candidate gate. The additive slice does not
  alter legacy Project, workspace, Image, Semantic Change, or Candidate bytes.
- The bundled standard-library catalog (`semaprax help library`,
  `std/catalog.json`) is now rendered from the `semaprax doc` documentation
  model, with every signature cross-checked against the source text and each
  declaration's leading comments carried as its description.
- Added `semaprax add <dir>|semaprax.toml <package> <range>`, which appends
  one byte-sorted `[dependencies]` row to a Package Manifest v1 table manifest
  and rewrites it canonically only after the result re-parses (`SPX-J127` for
  frozen layouts and duplicates), and `semaprax fetch <cache-dir>
  <subject.json>...`, which replays Subject-v3 envelopes and files them into
  the resolver's content-addressed cache by digest with one receipt line
  (`SPX-J128` on tampering or collisions), with no registry or network access.
- The VS Code adapter navigates by meaning: `Go to Declaration by Stable ID`,
  `Show Callers of a Declaration`, and `Show Module Documentation` run the
  selected compiler's read-only `query --json` and `doc` over the saved active
  file, and code lenses show each declaration's `@id`, effects, and contract
  counts (`semaprax.codeLens`). The `doc` and `query` JSON projections now
  carry each declaration's and member's `location`.
- Fixed Project owned-API target preparation to retain a distinct,
  already-admitted entry-plus-export HIR closure without changing entry-only
  execution or cleanup semantics, and updated both typed-expression schema
  gates for the two newly admitted numeric-to-String operation alternatives.
- Updated cleanup and protocol regression fixtures for aggregate-equality
  rejection, stable-ID native contract details, and the precise scalar-profile
  signature diagnostic while preserving owned-result and lazy-temporary
  cleanup coverage.
- Kept the freestanding C profile libc-free after native contract details
  gained argument rendering by replacing hosted formatting with a bounded
  byte copy and eliding per-call formatting, refreshed the affected native
  known answers, and made the depth-512 HIR oracle independent of the parser's
  depth-128 source admission boundary.
- Added the locally exercised Canonical Semantic Workspace Revision v1
  foundation: one immutable authority-free object derived from an admitted
  Project, with nine typed node projections, distinct semantic, source
  projection, manifest, and dependency-closure digests, one composite revision,
  and exact fresh replay. Existing Project, managed Workspace, and Semantic
  Workspace Image v1 schemas, bytes, and revision identities remain unchanged;
  universal transactions, full semantic coverage, persistent service, `.spx`
  agent syntax, and publication authority remain separate work.
- Added Bounded Language Network I/O v1: six compiler-owned, effect-gated TCP
  client operations (`net_connect`, `net_send`, owned `net_recv`,
  transcript-streaming `net_stream_stdout`, bounded-readiness `net_wait`,
  `net_close`) with the closed `semaprax.network.v1` status domain, a
  `NetworkV1` operation profile, invocation-scoped handles, a deterministic
  `semaprax.network-fixture.v1` provider, a real `TcpNetworkProvider` for the
  hosted interpreter seam, native C11 POSIX/Winsock lowering, and Core Wasm
  closed `env` imports with fixture injection; plus pure `std.net`,
  `std.http`, and `std.async` helper packages and the `net_http_get` example.
- Fixed the native C11 borrowed-view context extension: the `call_depth`
  field added to `spx_context` had silently detached the text anchors that
  splice in `borrowed_str_depth`, so every native program with a
  `borrow Slice<u8>` or `borrow str` parameter failed to compile; the anchors
  now target the current struct and the emitter asserts that they matched.
- Added `semaprax query <file|project> [filters] [--json]`, a read-only
  declaration search over a checked module or every authenticated Project
  source with `--kind`, `--name`, `--id`, `--effect`, `--calls`, and
  `--called-by` filters. Project results name owning paths and exact revisions,
  and use the retained semantic graph for cross-file call predicates; unknown
  kinds or identities fail closed with `SPX-V211`/`SPX-V212`.
- `semaprax context <file|project> <stable-id>` now accepts a Project directory
  or manifest and renders a compact authenticated, bounded cross-file context
  without requiring agents to discover and reopen one source. The calculator
  gate caps it at 2 KiB, 600 lexical units, and one sixth of the full graph.
- Added the `semaprax package report|lock|resolve` namespace, each subcommand
  exactly its long-form offline package route.
- Split CLI option parsing and single-file execution/reporting out of the
  command dispatcher, bringing `src/cli_driver.rs` below the module-size limit
  while retaining the moved surfaces in the source-locked doctor contract.
- Added `semaprax verify`, one verb for every independent evidence verifier:
  the capsule's `schema` selects the owning route (semantic patch evidence
  v1/v2, workspace patch evidence, semantic workspace change, structural
  change, and operations evidence, agent graph bundles, and project images)
  and the receipt is that route's own bytes; unrecognized or unreadable
  capsules fail closed with `SPX-V201`/`SPX-V202` before any verifier runs.
- Added `semaprax agent inspect <definition.json> [--profile]`, which compiles
  a canonical AgentDefinition v1 and prints its AgentGraph v1 or its Agent
  Runtime Profile v1 projection; the other lifecycle verbs stay unadmitted.
  The guided help gains an `Agents` group and lists `verify` under `Change by
  meaning`, with shapes shortened to hold the 2048-byte bound.
- Added `semaprax doc <file> [--json]`, the documentation projection of one
  checked module: a Markdown page or one `semaprax.doc.v1` document of every
  declaration's identity, canonical signature, ownership modes, effects,
  contracts, members, and leading `//` comments, bound to the graph revision.
  The projections harness proves the page and `semaprax graph` name the same
  declarations at the same revision on every committed example. The guided
  help lists it under `Inspect meaning`; several guide summaries were
  shortened to keep both capability pages under the 2048-byte bound.
- The canonical graph-operational agent workflow now uses compact candidate
  source-review, function-summary, and impact-summary projections while full
  candidate and semantic-delta replay stays inside the verifier. Its regression
  rejects the older full-report routes and enforces aggregate protocol and
  review-material byte/lexical-unit ceilings, preventing silent context-cost
  regressions in the fixed twelve-step application change. Immutable review
  data is transferred once and reused across the expected conflict; recovery
  replay proves the candidate and source review stayed exact without two
  duplicate protocol responses.
- Project-link diagnostics now name and locate the exact entry, test, or
  provider module responsible for missing or invalid `main` declarations and
  distinguish capability exclusions from declaration-shape exclusions.
- CLI and parser diagnostic gaps now retain stable codes and actionable source
  anchors: missing `fmt` inputs use `SPX-I001`/`SPX-J102`, unknown `context`
  symbols use `SPX-G404`, bare identifier statements point at their token,
  UTF-8 BOMs name their removal, and semantic-review patch decoding shares the
  ordinary `SPX-I202` wording.
- Improved newcomer diagnostics: statement-position `if` failures now name
  the mandatory `else` and discard form, immutable parameters show the
  mutable-copy repair, and unknown bundled standard-library functions name
  their manifest dependency and offline catalog route.
- Added reserved `string_from_i64` and `string_from_usize` operations with
  canonical decimal spelling across the interpreter, native C11, and Core
  Wasm lanes, allowing computed integers to be printed without handwritten
  digit tables.
- Malformed three-token help requests now identify the unexpected extra
  operand instead of misreporting `help` as an unknown command. CLI report and
  analysis option parsers also live in a bounded driver submodule, keeping the
  shared dispatcher comfortably below its recorded module-size cap.
- Build target errors now use input- and toolchain-specific catalogs; scoped
  help and the CLI guide document the Web-compatible `wasm` alias, `-o` /
  `--output`, target and destination defaults, and structured `build --json`
  results. Profile Web collisions report Web-specific `SPX-I307`, concurrent
  project native builds have one create-new winner, and command-profile
  `run` output explains that it executes the entry while built adapters invoke
  the manifest command.
- Single-file native and Web/Wasm builds now require fresh destinations.
  Native output is reserved before compiler invocation and Web output uses an
  atomic create-new directory, so existing sources/artifacts and concurrent
  winners are never overwritten or merged; invalid parents report `SPX-I301`
  and existing destinations report `SPX-I307`.
- Native contract-failure stderr now includes the canonical clause, persistent
  function identity, and declaration-ordered observed arguments, matching the
  interpreter's human repair detail while preserving the normalized status
  and exit code.
- Reference-interpreter frames now use indexed binding slots instead of
  reverse linear scans. Interned `ValueId` handles also make executed `let`
  binding insertion allocation-free after HIR construction; scalar reads keep
  their existing by-value copy path. The runtime loop is retained in the
  Criterion interpreter benchmark as a regression gate.
- Single-file `semaprax run` now executes `app.main` through the bounded
  reference interpreter, accepts `--json`, `--max-steps`, and `--max-bytes`,
  and automatically admits the exact bounded stdout-transcript profile. The
  former generated C11 behavior remains available explicitly as `--native`.
- Generated native executables now guard the same 256-frame call-depth bound
  used by the reference interpreter. Deep and mutual recursion return the
  deterministic `semaprax.runtime.v1/1` capacity outcome with visible stderr
  and exit 73 instead of terminating through an empty-stderr stack signal.
- Web packages now preserve semantic status domains for byte-range failures
  and checked i32, u8, and usize arithmetic. Generated JavaScript exposes the
  same frozen `{schema, domain_id, code}` observation for these failures as
  the interpreter and native lanes instead of mislabeling or bare trapping.
- Native builds now accept legal scalar self-comparisons such as `x == x`
  under the generated C warning policy, including the idiomatic floating-point
  NaN test shape, while retaining `-Werror` for actionable generator warnings.
- Fixed right-nested i32 arithmetic in the scalar Core-Wasm emitter by keeping
  the outer widened operand on the Wasm value stack until the nested operand
  finishes. Nested literal and function-call expressions now match native and
  interpreter results at multiple depths.
- Fixed the scalar Core-Wasm local layout so i32, u8, and usize arithmetic
  scratch locals follow function parameters instead of aliasing parameters or
  user `let` bindings. Parameterized narrow-integer programs now validate and
  agree with the reference interpreter.
- The CLI now rejects single-file semantic-patch no-ops and read-only sources
  before staging, admits Context byte budgets only from the viable 2048-byte
  envelope floor, and refuses `fmt` source, manifest, or project-directory
  symlink/reparse aliases with `SPX-J102`.

- Cleanup replay now validates long scalar checked-status sequences through
  bounded status-source/edge/exit summaries instead of cloning every failed
  path's successful prefix, eliminating quadratic replay memory and preflight
  rejection for large straight-line functions.

- Cleanup replay now recognizes decision-only CFGs with no cleanup state and
  validates them structurally without enumerating every lazy-boolean outcome,
  so ordinary long `&&`/`||` chains no longer hit the path budget.

- Source verification now skips lazy-branch snapshots for ordinary binary
  operators, tracks whether a scope has local borrows before liveness work,
  and indexes declared record fields once, removing quadratic rescans from
  wide scalar blocks and record literals.

- Formatter capacity accounting now measures all expression-subtree lengths
  during one canonical traversal instead of re-rendering every subtree, making
  revision hashing linear in expression size while preserving exact bytes.

- Cleanup replay's preflight now accounts for every constructor-field
  continuation, so wide record and variant literals no longer exhaust an
  underestimated per-function skeleton budget.

- Corrected the installed language card: `while` repetition is controlled by
  the re-evaluated condition, while the required body tail is discarded; the
  card now names the Copy-scalar and aggregate restrictions behind `SPX-T252`.
- Misspelled variant constructors and patterns now suggest the nearest unique
  case and preserve the nominal type after a bad constructor, suppressing the
  downstream unknown-binding and incompatible-match cascade.
- String ordering now emits only `SPX-T250`, without a duplicate numeric
  `SPX-T208`; aggregate equality in contracts now fails at the clause with
  located `SPX-T207` and scalar-field/match guidance before backend lowering.

- Nominal aggregate-valued `match` arms now fail during source verification
  with a located `SPX-T258` and an `if`/scalar-extraction remedy. `check`,
  native, and Wasm agree before unsupported record/variant lowering begins.

- Added a deterministic 128-level source-nesting limit. Deep balanced or
  truncated delimiters, unary chains, and expression trees now fail with a
  located `SPX-P207` and extraction help instead of overflowing the Rust
  runtime stack in front-end commands.

- Empty function identities now fail at source verification with located
  `SPX-S102` suffix guidance, and the 4,096-function byte-data capacity limit
  uses located `SPX-T270` with the bound and a module-splitting remedy instead
  of an unlocated internal replay diagnostic.

- `semaprax check` now resolves and validates HIR, cleanup plans, and replay
  budgets after source verification, matching the verdict used by `graph`,
  `run`, and both build targets instead of accepting backend-invalid source.

- Agent Context v2 now projects `while` statements in modern byte-data
  function bodies, so every declaration in `examples/text_analytics.spx` is
  available through the bounded context route when the full graph succeeds.

- Pinned source-verifier rejection of unsuffixed `i64` literals mixed with
  `usize`, `u8`, or `i32` arithmetic. `SPX-T208` now has explicit regression
  coverage for the suffix help before HIR or a backend can observe the input.

- Rejected a trailing semicolon after a block's value with the existing
  `SPX-P106` expression-statement diagnostic. Canonical formatting no longer
  accepts and silently removes that source token.
- Offline language/library help now shows the compiler-bundled dependency
  route and each `std.*` package's required consumer profile. `semaprax new`
  writes the extensible table scaffold and the calculator demonstrates a
  stable-ID import from `src/core.spx`. Table-manifest structural diagnostics
  report independent failures together and point to both scaffold routes.

- Project command operands now accept shell-natural `.` and `..` spellings,
  including `--manifest-path`, consistently across check, run, test, lock,
  build, and new-project verification. Manifest-declared source paths retain
  their strict no-alias rule.

- Scalar Project v1 now retains module-local record declarations through HIR
  replay, while aggregate function boundaries fail at their declaration with
  actionable `SPX-G174` guidance. The language card and generated project
  agent guide now state that boundary explicitly.

- Workspace declaration replay now retains classes as `Class` rather than
  `Record`, includes their owned methods in the independent fact map, and names
  the first differing stable identity in genuine `SPX-G173` disagreements.
  Class-bearing projects can therefore reach their ordinary execution lanes.

- Source byte-data capacity verification borrows the ordinary-function index
  instead of cloning its full `BTreeMap` once per function, and rejects the
  4,096-function bound at the start of declaration verification with the first
  excess declaration's source span.

- Canonical formatting now emits comment hooks for variant cases, variant
  payload fields, resource lifecycle items, and their closing braces. Comments
  in those bodies survive exactly once and formatting is a fixed point.

- `semaprax patch` rejects every surplus positional argument or unknown option
  with usage status 2 before reading or rewriting the source, matching the
  strict `impact` and `review` command grammars.

- `fmt --check` reports the first differing line and documents compact
  single-line `match` projection; `resolve` validates its target before
  dependency availability, and `new .` now explains that an explicit project
  name is required.
- CLI success and usage surfaces are now consistent for automation: successful
  `check --json` emits a verified envelope, `fmt --check` accepts flag-first
  order, `lock`/`resolve` print one recovery hint, and bare native-callable
  output names resolve against the current directory.
- `test` treats missing operands as domain failures rather than usage errors,
  `--max-steps` uses one closed usage-error range, and failed project summaries
  distinguish `main` from their consistently counted named cases.
- Added a replayable Agent Payment Graph and unified injected-host harness that
  compiles one AgentDefinition into Runtime v1, binds an independently admitted
  Economic Agent Policy, and carries a completed canonical Payment Intent into
  the existing approval/custody/broadcast/reconciliation state machine. The
  graph binds all three semantic digests and grants no model, wallet, signing,
  network, journal, approval, custody, or publication authority.
- Added exact project dependency inputs: scalar Package Manifest projects can
  replay and link a complete project-local Subject-v3 SEMAPRAX closure across
  check, test, run, analysis, and build routes, while generated Native Rust SDK
  packages carry exact Cargo versions/features and deterministic crate
  re-exports. An offline executable consumer now proves that a non-allowlisted
  crate can implement a typed `import rust fn` adapter and return its result
  through a SEMAPRAX export. Both routes remain bounded, authenticated, and
  free of implicit registry or network authority.
- Deepened four existing standard-library packages without widening ambient
  authority: `std.time` rounds durations upward and measures elapsed
  milliseconds, `std.path`
  exposes parent and extension boundaries, `std.data.csv` validates quote
  placement in complete records, and `std.data.toml` locates assignment
  delimiters outside simple quoted keys and comments. Each addition is covered
  by the package examples and conformance cases on every standard-library
  backend.
- Added `std.data.toml` as the fourth executable `portable`-tier package, with
  allocation-free bare-key validation, blank/comment line recognition, and
  first assignment-delimiter location over borrowed bytes. Full keys, values,
  tables, decoding, validation, and encoding remain Missing.
- Added `std.path` as the third executable `portable`-tier package, with
  allocation-free inspection of canonical slash-separated path bytes for
  absoluteness, trailing separators, nonempty segment counts, and filename
  position. Typed values, normalization, traversal policy, safe joining, and
  host-platform conversion remain Missing.
- Added the second executable `portable`-tier package, `std.url`, with ASCII
  scheme and unreserved-byte classification plus percent-triplet validation
  and decoding. The package depends on `std.encoding`; a consumer that names
  only `std.url` receives both bundled sources through deterministic transitive
  closure, with no acquisition authority.
- Added the first executable `test`-tier package, `std.test`, with scalar
  equality predicates and deterministic 0/1 or caller-selected failure status
  helpers for the current Project return-code test model. It is portable and
  compiler-bundled; rich diagnostics, fixtures, property tests, fuzzing, and
  snapshots remain Missing.
- Added the first executable `portable`-tier data-format package,
  `std.data.csv`, with allocation-free single-record field counting that
  respects quoted commas and escaped quotes, plus balanced-quote validation.
  It runs on every standard-library backend and is available through the
  closed compiler-bundled dependency inventory; streaming, typed fields,
  dialects, and writing remain Missing.
- Added the eighth executable `core`-tier package, `std.time`, with
  nonnegative millisecond conversion and decomposition, deadline comparison,
  remaining-duration calculation, and saturating addition. The package is
  effect-free and portable; clock reads, sleeps, timers, and other
  authority-bearing time operations remain explicitly Missing.
- Added the seventh executable `core`-tier package, `std.random`, with a pure
  Park–Miller generator, total seed normalization, bounded deterministic
  advancement, and range sampling. Secure randomness remains unavailable
  without a future explicit capability boundary; the deterministic package
  runs on the interpreter, native C11, and Core Wasm lanes and is included in
  the closed compiler-bundled dependency inventory.
- `semaprax test` names a `test_`-prefixed function that is not a case (it
  takes parameters, does not return `i64`, or has no explicit `@id`) with a
  `note:` line on stderr instead of skipping it silently; the JSON envelope is
  unchanged. The generated `AGENTS.md` now explains the test module and named
  cases, so the scaffold capsule digests change.
- `semaprax project-scaffold --layout tables` emits a new project whose
  `semaprax.toml` uses the extensible `semaprax.manifest.v1` table layout,
  under a new additive capsule schema `semaprax.project-scaffold.v3`
  ([Public Project Scaffold Capsule v3](docs/PROJECT-SCAFFOLD-V3.md)). The
  default (`--layout frozen`) is byte-for-byte the shipped v2 capsule with the
  frozen `semaprax.project.v1` manifest, so no existing scaffold byte or digest
  moves. The calculator's table layout adds a separate core module and imports
  its exported function by stable identity; both layouts lower to the same
  Project v1 contract. `tests/project.rs::scaffold` and `::scaffold_cli` pin it.

- Added the sixth executable `core`-tier package, `std.encoding`, with bounded
  ASCII-byte classification, hexadecimal value conversion, byte-pair decoding,
  lowercase/uppercase hex digit encoding, standard Base64 digit conversion,
  and unpadded four-digit decoding to a 24-bit value. Its contracted examples and
  conformance suite run on the interpreter, native C11, and Core Wasm lanes,
  and package manifests can import the compiler-bundled module at version
  `0.1.0` without acquisition authority.
- Extended `std.bytes` with length-aware suffix matching over borrowed byte
  slices, including empty, exact, proper-suffix, prefix-only, and longer-suffix
  conformance cases on every listed backend.
- Extended `std.text` with exact, length-aware borrowed UTF-8 equality and
  direct empty, Unicode, embedded-NUL, equal, and unequal interpreter,
  native-C11, and Core-Wasm assertions.
- Project manifests can now link the closed compiler-bundled `std.*` inventory
  at version `0.1.0` without cache, network, or acquisition authority. Exact,
  tilde, and caret ranges are checked, transitive standard dependencies are
  expanded deterministically, and one Project can link multiple packages by
  stable identity; ordinary resolved-package builds remain open.
- The Useful Text workspace boundary now links exact non-escaping `borrow str`
  providers across files, enabling the new partial `std.text` package with
  byte-length, emptiness, prefix, and substring operations across interpreter,
  native C11, and Core Wasm conformance lanes.
- The full toolchain's held-parent `new` authority now admits the exact
  six-file library scaffold as well as the calculator, preserving fixed
  inventories, create-new writes, no-replace publication, and post-publication
  authentication.

- `semaprax lock` and `semaprax resolve` accept `[<dir>|semaprax.toml]`,
  resolving directory arguments to `<dir>/semaprax.toml` and defaulting to
  `./semaprax.toml` when omitted, matching `check`, `fmt`, `run`, `test`, and
  `build`. Outside a project without arguments, both commands attach the
  standard missing-manifest guidance hint. `tests/project.rs::project_lock_v1`
  and `tests/project.rs::dependency_resolution_v1` pin the ergonomics.

- Canonical project comments now remain valid inputs to Project semantic-graph
  construction and persisted frontend-cache replay, while the parsed semantic
  program remains comment-free. Project-format and install-guide fixtures use
  native path spelling on every host and explicitly create the required lock
  before executing a freshly formatted project.

- `semaprax lock` gains `--emit-interface` and `--compare-interface
  <baseline.json>`: a fine-grained per-export compatibility for Project v1
  scalar packages. `--emit-interface` prints the scalar WIT interface
  descriptor to store as a baseline; `--compare-interface` diffs the current
  project against it and names exactly which export was added or removed, or had
  its parameter or result type change, exiting nonzero on a breaking change. It
  is purely additive and does not touch the `semaprax.lock` format; the coarse
  `--compare` stays. `tests/project.rs::project_lock_v1` and the
  `scalar_wit_compare` unit tests pin it.


- The `useful-data.v1` byte-data profile admits `requires` and `ensures`
  contracts throughout its function inventory. The Core-Wasm data emitter
  walks contracts with bodies and lets a false contract publish status 9 or
  10 through the data status global, the generated facade already maps those
  to `SemapraxDataError` in the `semaprax.contract.v1` domain, and the npm
  semantic recipe renders contract lines so replay binds them byte for byte.
  Functions with effects are still rejected. `std.bytes` ships on the profile
  with byte conversion, guarded indexing, search, counting, ASCII
  classification, equality and prefix tests, and endian reads, all
  contracted and run on every lane; the catalogs are regenerated.
- `semaprax test` runs every `fn test_<name>() -> i64` of the manifest-declared
  test module as a named case after `main`, each with its own step budget, and
  names each failing case with its outcome (`failed
  calculator.tests.test_add: returned 2`) followed by `project tests failed: K
  of N in <module>` and a `help` line; a failing `main` is reported the same
  way instead of the bare `project tests failed with result N`. The
  `semaprax.project-execution.v1` test envelope gains an always-present
  additive `cases` array under the unchanged schema string and payload-digest
  domain, and `project::verify_execution_envelope` verifies it. Entry envelopes
  and the passing-test line without cases are unchanged.
  [Project Test Cases v1](docs/PROJECT-TEST-CASES-V1.md) owns the rule and
  `tests/project.rs::developer_loop` pins it.

- A violated `requires` or `ensures` under `semaprax run` or `semaprax test`
  now names the failing function's stable id, the clause kind and source text,
  and the call's argument values, both as two indented lines after the
  unchanged language-status line and as an additive `failure` member of the
  `language_failure` outcome. The interpreter records the detail at the failing
  frame (`src/interpreter/failure_detail.rs`); the status object, cleanup, and
  exit status are untouched, and the native path is unchanged. The legacy
  resolved-entry evaluator moved verbatim into `src/interpreter/resolved_case.rs`
  so a named function can be evaluated without being the entrypoint.

- `semaprax check` on a project whose `use` names a module no listed source
  declares keeps `SPX-G172` and its message and adds a `help` line: it names
  the unlisted `.spx` file that declares the module and the `sources` key in
  `semaprax.toml`, or says that no listed file declares the module. The hint is
  added by the project loader in `src/project/source_hint.rs`, so human and
  JSON diagnostics agree; [Project Manifest v1](docs/PROJECT-MANIFEST-V1.md)
  owns the rule and `tests/project_cli_v1.rs` pins it.
- `scripts/quality.sh changed` routes CLI and editor changes narrowly. Paths
  under `src/cli/` and `src/bin/`, plus `src/cli_driver.rs` and
  `src/main.rs`, classify as `cli-surface` and append a `test-cli` gate that
  runs the CLI harnesses of the standalone package and the full toolchain;
  paths under `editors/` classify as `editor-adapter` and append `test-editor`,
  which runs the extension's `node --test` suite and the documentation
  harness. Both follow the fixed `changed` gates in one order, and the
  executor rejects a repeated or reordered surface gate. Other paths route as
  before, `full`'s gate list is unchanged, and the plan schema stays
  `semaprax.quality-route.v2`; `tests/quality_routing.rs` pins the routes and
  the executor's dispatch.

- `AGENTS.md` forbids pointing a worktree's Cargo `target-dir` at another
  worktree or at any path a different checkout's tests depend on, and the
  development guide gives the private `CARGO_TARGET_DIR`,
  `CARGO_INCREMENTAL=0`, and `CARGO_PROFILE_TEST_DEBUG=0` setup with the disk
  a full gate needs.

- The VS Code extension checks on save. Saving a `.spx` file or
  `semaprax.toml` runs the user-selected `semaprax.compilerPath` binary as
  `check <nearest semaprax.toml or file> --json`, maps each JSON diagnostic to
  an editor diagnostic (`code: message` plus the help on a new line, range
  from the reported line and column), and clears entries the re-check no
  longer reports. `SEMAPRAX: Check Project` runs the same check explicitly and
  names the setting to fill when none is set; the machine setting
  `semaprax.checkOnSave` (default `true`) turns the save trigger off. The
  child is spawned without a shell, capped at 4 MiB of output and 30 seconds,
  and writes nothing. Activation adds `onLanguage:semaprax` and the new
  command; `editors/vscode/diagnostics.js` holds the pure logic and
  `test/diagnostics.test.js` covers it.
- The `SPX-J121` build rejection for a manifest with `[dependencies]` now points
  at `semaprax resolve --write` to resolve and pin the dependency graph, instead
  of claiming no resolution route exists; only a build that links resolved
  dependencies is still unimplemented. The agent quick reference gains a short
  locking-and-dependencies note covering `lock` and `resolve`.

- `semaprax resolve` gains `--write` and `--verify`: `--write` pins the
  resolution evidence to `semaprax.resolution-<target>.json` beside the
  manifest, and `--verify` re-resolves and confirms that pin still holds byte
  for byte, failing closed with `SPX-J126` when the cache no longer produces the
  recorded selection. Because resolution is deterministic the pin is a stable
  per-target dependency lockfile a CI job can check.
  `tests/project.rs::dependency_resolution_v1` pins it.

- `semaprax lock <manifest> --compare <baseline.lock>` classifies a project's
  current interface against a baseline `semaprax.lock` and prints a
  `semaprax.project-lock-compatibility.v1` verdict, exiting nonzero on a
  breaking change so a CI gate fails. A removed export, a widened required
  capability, a removed target, a changed package name or contract, or a
  changed interface descriptor digest with the same export set are breaking; an
  added export, a narrowed capability, an added target are not; a pure display
  rename or a version-only change is not. It is a coarse project-level
  counterpart to the offline Compatibility Evidence; `tests/project.rs::project_lock_v1`
  pins it.

- `semaprax resolve <manifest> --target <native64|wasm32> --cache <dir>`
  resolves a project's `[dependencies]` against a local content-addressed cache
  of Subject-v3 envelopes and prints the offline resolver's evidence
  ([Project Dependency Resolution v1](docs/PROJECT-DEPENDENCY-RESOLUTION-V1.md)).
  It selects one version per package that satisfies the manifest ranges and
  their transitive requirements, deterministically and per target, reading the
  cache as an explicit effect with no registry, acquisition, or build. Cache
  files are named by their subject digest, so a misfiled subject is rejected;
  `SPX-J126` covers missing dependencies, a target outside the matrix, and
  cache faults. Manifest dependency names are now dotted lowercase package
  identities matching the resolver, so `examples.meaning` is admitted;
  `tests/project.rs::dependency_resolution_v1` is the gate.

- Cross-platform CI now preserves the exact verifier hint while accepting
  native line endings in CLI help, and deep standalone-String Wasm planning
  uses narrow recursive walkers so the contracted nesting depth fits the
  default macOS test stack. Supply-chain command dispatch also moved into its
  audited submodule to restore the CLI driver's source-size budget.

- The help catalog test's dispatcher inventory lists the `lock` command that
  landed with the deterministic `semaprax.lock`, so the catalog and dispatcher
  closure check passes again in both executables.

- `semaprax help library` prints the generated standard-library catalog, the
  fourth `help` shape beside `help language`, so an installed compiler lists
  every `std.*` function and contract offline.
- Project-shape rejections now carry their fix: a Project v1 manifest whose six
  lines are missing, extra, or unterminated lists the exact lines in order, an
  `entry` that names a module without `main` explains the `entry` key, and an
  unknown function with no near name shows the `use function @id(…) from
  module as name;` import line. `tests/project/manifest_hints.rs` pins the
  manifest and CLI cases.
- `semaprax fmt` accepts a project directory or `semaprax.toml`, like `check`,
  `run`, `test`, and `build`: it formats every `sources` entry in manifest
  order through the comment-preserving projection, parses every file before
  writing any, and with `--check` prints one `<path> is not canonically
  formatted` line per drifting file. Previously `fmt .` failed with `cannot
  read .: Is a directory`. `tests/projections/fmt_comments.rs` and
  `tests/project_cli_v1.rs` pin it.

- `semaprax new --template library` creates the scaffold's library template
  in the standalone compiler; the success line is now `created <template>
  project <destination>`, and an unknown template is rejected with `expected
  calculator or library`. The full toolchain's `new` still publishes only the
  calculator inventory and refuses `library` with a message naming the
  standalone route. `tests/project/new_cli.rs` pins the library project's
  bytes and that it checks, tests, runs, and is canonical.

- `semaprax patch`, `patch-with-evidence`, and `patch-with-evidence-v2` keep
  the file's `//` comments: the patched candidate is parsed with its comments
  and rendered through the same projection as `fmt`, so a comment above a
  renamed function stays above it and the patched file passes `fmt --check`.
  Graph revisions and evidence digests are unchanged. [Canonical comments
  v1](docs/CANONICAL-COMMENTS-V1.md) lists the preserved routes;
  `tests/semantic/patch.rs` pins the regression.

- `semaprax lock <manifest>` renders the deterministic `semaprax.lock` beside a
  project ([Project Lock v1](docs/PROJECT-LOCK-V1.md)): the canonical manifest
  and its contract, the project revision as the program root, every source
  file's revision and digest, the retained interface descriptor digest, the
  declared target matrix, required capabilities, the compiler, and the
  resolution policy. `--write` persists it atomically and `--verify` re-renders
  and compares bytes, failing closed with `SPX-J123` when a source, manifest,
  or compiler drifts and naming the drifted fields. Like every package
  operation the lock is explicit and never touched by `check`;
  `tests/project.rs::project_lock_v1` is the gate.

- `semaprax fmt` keeps `//` comments. The lexer records each comment's
  position, and the canonical formatter prints it above the item it preceded
  or right after the item it followed, at that item's depth; formatting is
  idempotent and a comment-free file formats to the same bytes as before.
  Only `fmt` restores comments; `patch` and other rewriting transactions still
  emit comment-free text. [Canonical comments v1](docs/CANONICAL-COMMENTS-V1.md)
  owns the placement rules, `src/format/comments.rs` and
  `tests/projections/fmt_comments.rs` pin them, and the formatter's capacity
  accounting moved verbatim into `src/format/capacity.rs`.

- Every generated project now carries an `AGENTS.md`: the commands to check,
  test, run, format, and build it, and the rules that differ from other
  languages, written for coding agents and people alike. The scaffold capsule
  becomes `semaprax.project-scaffold.v2` with five files and a new digest
  domain, the generated `README.md` points at `AGENTS.md` and uses directory
  operands, and both `new` routes publish the same five files. The library
  template gains the same file. The `_v1` API names are unchanged; the schema
  string and digest domain are v2.
  [Public Project Scaffold Capsule v2](docs/PROJECT-SCAFFOLD-V2.md) owns the
  contract.

- `semaprax new <destination>` now works on the standalone compiler. It
  derives the same calculator template as the full toolchain, refuses anything
  but a fresh destination under an existing real directory, writes every file
  with create-new semantics, reads the files back, authenticates the project,
  and prints the same success line. The full toolchain keeps its held-parent
  staged publication; [Standalone project creation v1](docs/NEW-PROJECT-STANDALONE-V1.md)
  owns the bounded route and its non-claims, `tests/project/new_cli.rs` pins
  it, and the install guide, quickstart, and README no longer require the
  full toolchain to create a project.
- `semaprax.toml` gains one extensible table layout, `semaprax.manifest.v1`
  ([Package Manifest v1](docs/PACKAGE-MANIFEST-V1.md)): `[package]`,
  `[modules]`, `[exports]`, `[command]`, `[capabilities]`, `[dependencies]`,
  and `[targets]` tables lower onto the frozen Project v1-v11 profile
  contracts, so every project route, descriptor, and generated artifact is
  unchanged and only the manifest bytes differ. Reserved and unknown tables or
  keys reject with `SPX-J120`, a declared dependency fails every build closed
  with `SPX-J121`, a build target outside `[targets] matrix` rejects with
  `SPX-J122`, and a non-canonical manifest names its first differing line.
  The frozen layouts remain admitted byte-for-byte;
  `tests/project.rs::package_manifest_v1` is the gate.

- The standard-library contract and the agent quick reference explain how a
  Project consumes a `std.*` module today, by vendoring its library file and
  importing by `@id`; the gate vendors every package into a fresh project and
  runs its examples and conformance there.

- `std.num` gains checked `pow`, `isqrt`, `digit_count`, `is_power_of_two`,
  `log2_floor`, and `log10_floor`, each with contracts and conformance checks
  on every lane; the catalogs are regenerated.

- `semaprax project-scaffold --template library` prints a library package in
  the standard-library shape: `src/lib.spx` with one contracted function,
  `src/examples.spx` as the entry, and `src/tests.spx` as the conformance
  suite, all checked and tested at derivation and replayable only as the
  library template. The calculator capsule bytes are unchanged, and the
  private `new` still admits only the calculator inventory.

- Added the standard-library contract, [Standard Library v1](docs/STANDARD-LIBRARY-V1.md),
  and its first `core`-tier packages under `std/`: `std.core` (ordering as
  `-1`/`0`/`1`, extrema, clamping, range membership, `bool` conversions and
  connectives), `std.num` (sign, absolute value, parity, Euclidean division and
  remainder, greatest common divisor), and `std.num.overflow` (overflow
  predicates and wrapping and saturating arithmetic). Each package is a
  Project whose entry is its examples module and whose test module is its
  conformance suite; `tests/project.rs::standard_library` runs both on the
  interpreter, native C11 at O0/O2, and Core Wasm under Node, checks
  identities and conformance coverage, and generates the human
  [catalog](docs/STANDARD-LIBRARY-CATALOG.md) and `std/catalog.json`.

- The Workspace Semantic Graph builder pre-bound now charges structural bytes,
  string contents, and per-shape identity slots separately instead of the
  `Try` and string rates for every node. The 16 MiB budget and every reported
  field are unchanged, but `used_builder_bytes` values move, so the frozen
  known-answer digests in the workspace change, operations, structural-change,
  and analysis tests, the workspace CLI harness, and the browser fixture's
  `project_graph_digest` answers were re-pinned. Before the split a 4.9 KiB
  module of twenty scalar functions was rejected with `SPX-G171`; the `std/`
  packages are the regression.

- The workspace CLI tests that assert exact command usages now read them from
  `semaprax help all`, the exhaustive catalog, instead of the guided one-screen
  `--help` page that replaced it.
- `check`, `run`, `test`, and `build` invoked with no input outside a project
  now attach a hint to the unchanged `SPX-J102` missing-manifest diagnostic
  naming the three admitted inputs: a `.spx` file, a project directory, or
  running from inside a project. An explicitly named manifest is unchanged.

- `semaprax help language` prints the compiler-checked agent quick reference
  byte for byte from the installed binary, so an agent or developer without the
  source checkout can read the admitted shapes, the diagnostics foreign habits
  trigger, and their fixes offline. Both help harnesses pin the bytes and the
  guided page lists the form.

- The VS Code extension now contributes the `.spx` language declaratively:
  a TextMate grammar and language configuration give highlighting, `//`
  comment toggling, bracket matching, and auto-closing pairs without starting a
  session or running code. The documentation gate checks that the grammar
  names every keyword the parser recognises and every literal suffix.

- Checking one module of a multi-file project on its own now explains the
  next step: `SPX-G172` (the module imports other modules) and `SPX-T105`
  (the module has no `main`) keep their codes and messages and gain a hint
  naming `semaprax check <project-dir>`.

- `check`, `run`, `test`, and `build` accept a project directory as their
  positional operand and select the `semaprax.toml` inside it, so
  `semaprax check examples/calculator-project` and `semaprax run .` work
  without naming the manifest. Inert `.` components are removed before the
  manifest is authenticated; `--manifest-path` is still taken literally, and a
  directory without a manifest reports the ordinary `SPX-J102` for that path
  instead of an unreadable directory. Scoped help and the catalog show `<dir>`.

- A source file that does not start with its `module` line now carries a fix
  hint under the unchanged `SPX-P104` ``expected `module` `` diagnostic,
  naming the `module dotted.name;` header a pasted or truncated file is
  missing.

- `semaprax --help`, `help`, `-h`, and the empty invocation now print a guided
  one-screen overview: the commands for writing, checking, running, inspecting,
  and changing programs, grouped by task with a one-line purpose each, bounded
  to 2048 bytes and filtered by the executable's capability class. The former
  7 KB exhaustive page moved to the new `semaprax help all` form with its bytes
  otherwise unchanged; scoped help, typo guidance, and recovery hints are
  unchanged. [Guided CLI Help v4](docs/CLI-HELP-V4.md) owns the contract and
  the standalone and full-toolchain help harnesses pin it.
- A borrowed view taken directly from a string literal, an array literal, or a
  call result (`str_as_bytes("hi")`, `array_as_slice([1u8])`) now names the
  `let` binding step in its `SPX-T266` help, and the README routes coding agents
  to the agent quick reference.

- More first-attempt habits now carry their fix: `struct`/`enum`/`pub`/`const`
  declarations, a missing trailing `,` after the last field or match arm,
  `x += 1`, a missing `->` result type or a `()` unit type, an uninitialised
  `let`, `=` in an `if` condition, `a[0]` indexing, `Some(1)`/`None` shorthand,
  a method call on a `string`, byte, record, or variant value, and foreign type
  names such as `String`, `int`, `double`, `boolean`, or `Vec`. Codes and
  messages are unchanged; `tests/language/foreign_syntax_hints.rs` and
  `tests/language/verifier_hints.rs` pin each case. Type syntax parsing moved
  verbatim into `src/parser/types.rs` to keep the grammar root under budget.

- An owned `string` or byte value passed to a user function's `borrow str` or
  `borrow Slice<u8>` parameter now names the view conversion in its `SPX-T205`
  help, the parser's expression-statement hint shows the admitted `let _ = …;`
  discard, and the agent quick reference explains that a failing project test
  reports only its return value.

- Verifier diagnostics now carry fix hints for the type-level habits an agent
  brings from other languages: an unknown function names the nearest declared
  or compiler-owned function (`did you mean `string_len`?`) or, for the
  print family, the one admitted output route; a generic call or generic type
  without explicit type arguments shows the `id<i64>(…)` and
  `Option<i64>::Some { value: … }` shapes; an unsuffixed integer literal against
  a `usize`, `i32`, or `u8` operand names the suffix to write; and an owned
  `string` handed to `str_as_bytes`, a byte operation, or `stdout_write` names
  the `string_as_str`/`str_as_bytes` conversion. Codes, messages, and spans are
  unchanged, and the iterative verifier and the test-only oracle share the
  helpers in `src/source_verify/hints.rs`; `tests/language/verifier_hints.rs`
  pins each case and the no-hint baselines.
- Fixed the stale descendant expectation in
  `tests/language/generic_records.rs`. Admitting concrete generic owned
  variants made `Maybe<Bytes>` a legal standalone owned value, so the
  descendant of `own Box<Maybe<Bytes>>` stopped reporting `SPX-T268` on its
  own. The shape itself stayed closed throughout - the record carrier reports
  `SPX-T223` in source verification and resolved-HIR classification returns
  `OutsideProfile`, matching the identical case already pinned in
  `tests/owned_data/nested_generic_owned_record_frontend_hir.rs` - so no
  admission changed. The test now asserts carrier closure, pins the standalone
  variant admission that explains the descendant's silence, and adds two
  descendant cases that must still report `SPX-T268`: a variant without a
  persistent `@id` under the same carrier, and an admitted owned variant stored
  as a declared record field.

## Earlier releases

The detailed 0.3.5, 0.2.0, and 0.1.0 history is preserved in the [changelog archive](docs/CHANGELOG-ARCHIVE.md).

- R20 private actual Step successor: fixed same-hold cleanup/transfer/Transition ACKs, actual ordered release receipts and compiler-empty Complete origin; cumulative/public/terminal/recovery acceptance remains pending.

- Authored additive Wasm Text Toolkit v1 with checked pure text operations,
  borrowed String conversion, numeric conversion/comparison, owned String
  variant transport/matching, explicit file-read provider authority, and a
  digest-bound standalone Web route. Combined executable gates remain pending.

- OPT #750: remaining retained byte-helper and finite scratch proof walkers use saved borrowed cursors with actual enlarged scratch reservations; independent order/work/depth and allocator-layout regressions are authored, not yet executed.

- Source native-container flag discovery compares the exact native import result kinds directly, retaining the original owned-Type constructor as an independent control and removing its discarded temporary backing. Source-only pending focused qualification.

- Restore the originally pinned legacy scaffold guide introduction; keep current
  bounded route guidance in capsule v8. No legacy digest or limit was updated.

- Avoid repeated final-HIR lifecycle collection for successful exact zero-argument
  declarations within one function's growing effect obligations. Preserve complete
  prior receivers and generic collection; allocation-through-Drop, exact-short,
  diagnostic and repeated-call controls are authored. Application fit under the
  unchanged graph cap remains pending focused qualification.

- Avoid authored cache-key spare directory backing for imported projections on
  the actual uncached resolved-core route. Retain complete cache receiving owners
  and full old oracle assertions. Constructor/Drop and full semantic controls are
  authored; the independent recursive full-receiver funding deficit remains open.

- Replace iterative variant-match coverage tree constructors with sorted borrowed
  case backing and prepaid speculative Or checkpoints. Preserve complete old
  coverage/dispatch controls, diagnostic bytes and all limits; physical Drop,
  exact-short and full receiver controls are authored pending focused execution.

- Prepay ordinary replay DAG destruction frontiers and checked structural bounds
  before node publication, retaining the original destructor and an independent
  old receiver. Construction and release work share the existing replay budget.
  Legacy refusal destruction remains a documented compatibility boundary;
  allocation, weak-reference and cross-ledger qualification is pending.

Source-only successor: scoped Vec field reads retain their authored explicit
lookup or row-derived form so checked previous-row lookups compose with a
whole-root record traversal freeze. Row indices and source replay remain
strict; Graph v85/current checked cache v11 and focused hostile/backend owners
are authored. Qualification is pending; Catalog corpus and limits are unchanged.

- Add affine typed filesystem change/structural/operations reporting routes,
  retaining selected replay report ownership through preparation and unlock;
  preserve complete original Vec routes and unlock diagnostic precedence.

- Source-only #781 successor: carry selected-local Session entry, membership and
  profile refusals as prepaid static data while preserving complete legacy Owned
  receivers, first receipt/stage and pending full-layout/physical/work controls.

- Source-only #827 Legacy successor: preserve complete old nominal validation,
  then share explicitly unfunded immutable payloads with isolated iterative COW;
  keep paid provenance and funded mutation guards separate. Qualification pending.

- Source-only #816 successor: reuse complete independent status-source case
  proof in ordinary arithmetic receiving, preserving full direct receivers,
  exact held invocation membership and pending whole-Drop/refusal controls.

- Source-only #827 Legacy final-link successor retains exact checked case-field
  coordinates without promoting unfunded storage; complete immediate prior
  finalizer, mutation, Owned baseline and iterative Drop controls await the
  next combined qualification.

- Source-only #831 keeps singleton weighted successor targets inline, promoting
  only on a distinct second child after full payment. Complete prior receiver
  and new algebra/physical/work/authority controls await combined execution;
  no cap changes or application recovery claim.
